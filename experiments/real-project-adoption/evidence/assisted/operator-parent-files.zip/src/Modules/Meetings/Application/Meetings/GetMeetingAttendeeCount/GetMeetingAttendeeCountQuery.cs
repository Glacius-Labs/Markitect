﻿using CompanyName.MyMeetings.Modules.Meetings.Application.Contracts;

namespace CompanyName.MyMeetings.Modules.Meetings.Application.Meetings.GetMeetingAttendeeCount
{
    public class GetMeetingAttendeeCountQuery : QueryBase<int>
    {
        public GetMeetingAttendeeCountQuery(Guid meetingId)
        {
            MeetingId = meetingId;
        }

        public Guid MeetingId { get; }
    }
}
