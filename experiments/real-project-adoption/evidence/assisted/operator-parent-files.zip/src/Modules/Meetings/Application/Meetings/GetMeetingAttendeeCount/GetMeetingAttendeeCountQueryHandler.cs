﻿using CompanyName.MyMeetings.BuildingBlocks.Application.Data;
using CompanyName.MyMeetings.Modules.Meetings.Application.Configuration.Queries;
using Dapper;

namespace CompanyName.MyMeetings.Modules.Meetings.Application.Meetings.GetMeetingAttendeeCount
{
    internal class GetMeetingAttendeeCountQueryHandler : IQueryHandler<GetMeetingAttendeeCountQuery, int>
    {
        private readonly ISqlConnectionFactory _sqlConnectionFactory;

        public GetMeetingAttendeeCountQueryHandler(ISqlConnectionFactory sqlConnectionFactory)
        {
            _sqlConnectionFactory = sqlConnectionFactory;
        }

        public async Task<int> Handle(GetMeetingAttendeeCountQuery query, CancellationToken cancellationToken)
        {
            var connection = _sqlConnectionFactory.GetOpenConnection();
            const string sql = """
                                SELECT COUNT(*)
                                FROM [meetings].[v_MeetingAttendees] AS [MeetingAttendee]
                                WHERE [MeetingAttendee].[MeetingId] = @MeetingId
                                """;

            return await connection.QuerySingleAsync<int>(
                sql,
                new
                {
                    query.MeetingId
                });
        }
    }
}
