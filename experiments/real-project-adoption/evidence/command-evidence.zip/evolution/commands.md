# Captured invocation index

PowerShell working directory: `C:\Users\Consiliari\.codex\worktrees\689d\Markitect\.artifacts\adoption\evolution-final`.

```powershell
$tool = '..\public-v012\markitect-v0.12.0-windows-amd64.exe'
```

For each row, the named prefix has `.stdout.txt`, `.stderr.txt`, and `.exit.txt` files. Repeated rows ran the same command twice, as indicated by numbered prefixes.

| Command arguments | Output prefix |
| --- | --- |
| `check --repo . --revision fd94a689aab857704c3a4a45ac2abe0fc0e3185c` | `v1-check-1`, `v1-check-2` |
| `model --repo . --revision fd94a689aab857704c3a4a45ac2abe0fc0e3185c` | `v1-model` |
| `context --api-version architecture.mymeetings.example/v1alpha1 --kind UseCase --name add-meeting-attendee --namespace architecture --repo . --revision fd94a689aab857704c3a4a45ac2abe0fc0e3185c` | `v1-context-add-attendee` |
| `context --api-version architecture.mymeetings.example/v1alpha1 --kind UseCase --name cancel-meeting --namespace architecture --repo . --revision fd94a689aab857704c3a4a45ac2abe0fc0e3185c` | `v1-context-cancel-meeting` |
| `check --repo . --revision a0f89e7c0ce43a1be556c17c41cd19f8e7f32d7f` | `v2-pin-check-1`, `v2-pin-check-2` |
| `model --repo . --revision a0f89e7c0ce43a1be556c17c41cd19f8e7f32d7f` | `v2-pin-model-1`, `v2-pin-model-2` |
| `context --api-version architecture.mymeetings.example/v1alpha1 --kind UseCase --name add-meeting-attendee --namespace architecture --repo . --revision a0f89e7c0ce43a1be556c17c41cd19f8e7f32d7f` | `v2-pin-context-add-attendee` |
| `context --api-version architecture.mymeetings.example/v1alpha1 --kind UseCase --name cancel-meeting --namespace architecture --repo . --revision a0f89e7c0ce43a1be556c17c41cd19f8e7f32d7f` | `v2-pin-context-cancel-meeting` |
| `impact --base fd94a689aab857704c3a4a45ac2abe0fc0e3185c --repo . --revision a0f89e7c0ce43a1be556c17c41cd19f8e7f32d7f` | `v1-to-v2-pin-impact`, `v1-to-v2-pin-impact-direct` |
| `check --repo . --revision 3e138c146736dad1ddb11dc7c509a61d95ab4398` | `v2-first-add-attendee-check` |
| `model --repo . --revision 3e138c146736dad1ddb11dc7c509a61d95ab4398` | `v2-first-add-attendee-model` |
| `context --api-version architecture.mymeetings.example/v1alpha1 --kind UseCase --name cancel-meeting --namespace architecture --repo . --revision 3e138c146736dad1ddb11dc7c509a61d95ab4398` | `v2-first-add-attendee-context-cancel` |
| `check --repo . --revision 65c1d959e6f5d1b866effbc5188c353c82b2405d` | `v2-transition-waiver-check` |
| `context --api-version architecture.mymeetings.example/v1alpha1 --kind UseCase --name cancel-meeting --namespace architecture --repo . --revision 65c1d959e6f5d1b866effbc5188c353c82b2405d` | `v2-transition-waiver-context-cancel` |
| `context --api-version architecture.mymeetings.example/v1alpha1 --kind UseCase --name get-meeting-fees --namespace architecture --repo . --revision 65c1d959e6f5d1b866effbc5188c353c82b2405d` | `v2-transition-waiver-context-unrelated` |
| `impact --base fd94a689aab857704c3a4a45ac2abe0fc0e3185c --repo . --revision 65c1d959e6f5d1b866effbc5188c353c82b2405d` | `v1-to-v2-transition-impact` |
| `render --repo . --write` (working tree, after completing both validators and removing exception) | `v2-final-render` |
| `check --repo . --revision c507172b24da9005904422c03cc3d66a2b5efcec` | `v2-final-check-1`, `v2-final-check-2` |
| `model --repo . --revision c507172b24da9005904422c03cc3d66a2b5efcec` | `v2-final-model-1`, `v2-final-model-2` |
| `context --api-version architecture.mymeetings.example/v1alpha1 --kind UseCase --name add-meeting-attendee --namespace architecture --repo . --revision c507172b24da9005904422c03cc3d66a2b5efcec` | `v2-final-context-add-attendee` |
| `context --api-version architecture.mymeetings.example/v1alpha1 --kind UseCase --name cancel-meeting --namespace architecture --repo . --revision c507172b24da9005904422c03cc3d66a2b5efcec` | `v2-final-context-cancel-meeting` |
| `impact --base fd94a689aab857704c3a4a45ac2abe0fc0e3185c --repo . --revision c507172b24da9005904422c03cc3d66a2b5efcec` | `v1-to-v2-final-impact` |
| `impact --base c507172b24da9005904422c03cc3d66a2b5efcec --repo . --revision fdc32ac004d17e3b4e91443b7c59fe035ce0d7b3` (temporary local comment probe) | `handler-comment-impact` |

The source restore/build invocations and their three raw result files use prefixes `public-nuget-restore` and `meetings-application-build`.
