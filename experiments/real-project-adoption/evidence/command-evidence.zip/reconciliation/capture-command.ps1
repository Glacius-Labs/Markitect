param(
    [Parameter(Mandatory = $true)][string]$Adopter,
    [Parameter(Mandatory = $true)][string]$Binary,
    [Parameter(Mandatory = $true)][string]$EvidenceDirectory,
    [Parameter(Mandatory = $true)][string]$Name,
    [Parameter(Mandatory = $true)][string[]]$CliArgs
)

$ErrorActionPreference = 'Stop'
$adopterPath = (Resolve-Path -LiteralPath $Adopter).Path
$evidencePath = [System.IO.Path]::GetFullPath($EvidenceDirectory)
New-Item -ItemType Directory -Force -Path $evidencePath | Out-Null

function Get-SourceTree {
    param([string]$Root)
    $files = Get-ChildItem -LiteralPath $Root -Recurse -File -Force | Where-Object {
        $relative = [System.IO.Path]::GetRelativePath($Root, $_.FullName)
        $parts = $relative -split '[\\/]'
        -not ($parts | Where-Object { $_ -in @('.git', '.artifacts', 'bin', 'obj') })
    }
    $tree = [ordered]@{}
    foreach ($file in $files | Sort-Object { [System.IO.Path]::GetRelativePath($Root, $_.FullName) }) {
        $relative = [System.IO.Path]::GetRelativePath($Root, $file.FullName).Replace('\', '/')
        $tree[$relative] = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    }
    $json = $tree | ConvertTo-Json -Depth 5 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $sha = [Convert]::ToHexString([System.Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()
    return [pscustomobject]@{ sha256 = $sha; files = $tree }
}

$before = Get-SourceTree $adopterPath
$psi = [System.Diagnostics.ProcessStartInfo]::new()
$psi.FileName = [System.IO.Path]::GetFullPath($Binary)
$psi.WorkingDirectory = $adopterPath
$psi.UseShellExecute = $false
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
$psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
$psi.StandardErrorEncoding = [System.Text.Encoding]::UTF8
foreach ($arg in $CliArgs) { [void]$psi.ArgumentList.Add($arg) }
$process = [System.Diagnostics.Process]::new()
$process.StartInfo = $psi
[void]$process.Start()
$stdoutTask = $process.StandardOutput.ReadToEndAsync()
$stderrTask = $process.StandardError.ReadToEndAsync()
$process.WaitForExit()
$stdout = $stdoutTask.GetAwaiter().GetResult()
$stderr = $stderrTask.GetAwaiter().GetResult()
$after = Get-SourceTree $adopterPath

$record = [ordered]@{
    name = $Name
    argv = @($psi.FileName) + @($CliArgs)
    workingDirectory = $adopterPath
    exitCode = $process.ExitCode
    stdout = $stdout
    stderr = $stderr
    sourceTreeBefore = $before
    sourceTreeAfter = $after
    sourceTreeUnchanged = ($before.sha256 -eq $after.sha256 -and (ConvertTo-Json $before.files -Compress) -ceq (ConvertTo-Json $after.files -Compress))
}
$record | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath (Join-Path $evidencePath "$Name.json") -Encoding utf8
Write-Output "EXIT=$($process.ExitCode) SOURCE_TREE_UNCHANGED=$($record.sourceTreeUnchanged) TREE_BEFORE=$($before.sha256) TREE_AFTER=$($after.sha256)"
exit $process.ExitCode
