using FluentValidation;

namespace CompanyName.MyMeetings.Modules.Meetings.Application.Meetings.AddMeetingAttendee
{
    internal class AddMeetingAttendeeCommandValidator : AbstractValidator<AddMeetingAttendeeCommand>
    {
        public AddMeetingAttendeeCommandValidator()
        {
            this.RuleFor(command => command.MeetingId).NotEmpty()
                .WithMessage("Id of meeting cannot be empty.");
        }
    }
}