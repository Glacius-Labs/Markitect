using FluentValidation;

namespace CompanyName.MyMeetings.Modules.Meetings.Application.Meetings.CancelMeeting
{
    internal class CancelMeetingCommandValidator : AbstractValidator<CancelMeetingCommand>
    {
        public CancelMeetingCommandValidator()
        {
            this.RuleFor(command => command.MeetingId).NotEmpty()
                .WithMessage("Id of meeting cannot be empty.");
        }
    }
}