﻿using CompanyName.MyMeetings.BuildingBlocks.Application.Data;
using CompanyName.MyMeetings.Modules.Meetings.Application.Configuration.Queries;
using Dapper;

namespace CompanyName.MyMeetings.Modules.Meetings.Application.Meetings.GetMeetingPeopleCount
{
    internal class GetMeetingPeopleCountQueryHandler : IQueryHandler<GetMeetingPeopleCountQuery, int>
    {
        private readonly ISqlConnectionFactory _sqlConnectionFactory;

        public GetMeetingPeopleCountQueryHandler(ISqlConnectionFactory sqlConnectionFactory)
        {
            _sqlConnectionFactory = sqlConnectionFactory;
        }

        public async Task<int> Handle(GetMeetingPeopleCountQuery query, CancellationToken cancellationToken)
        {
            var connection = _sqlConnectionFactory.GetOpenConnection();
            const string sql = """
                               SELECT COALESCE(SUM(1 + COALESCE([MeetingAttendee].[GuestsNumber], 0)), 0)
                               FROM [meetings].[v_MeetingAttendees] AS [MeetingAttendee]
                               WHERE [MeetingAttendee].[MeetingId] = @MeetingId
                               """;

            return await connection.QuerySingleAsync<int>(sql, new
            {
                query.MeetingId
            });
        }
    }
}
