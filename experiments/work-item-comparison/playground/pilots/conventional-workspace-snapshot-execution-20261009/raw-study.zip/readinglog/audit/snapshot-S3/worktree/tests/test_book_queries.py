import unittest

from book_queries import filter_books


class FilterBooksTests(unittest.TestCase):
    def setUp(self):
        self.books = [
            {"id": "1", "title": "Dune", "author": "Frank Herbert", "pages": 412, "status": "unread"},
            {"id": "2", "title": "The Hobbit", "author": "J.R.R. Tolkien", "pages": 310, "status": "finished"},
            {"id": "3", "title": "Dune Messiah", "author": "Frank Herbert", "pages": 256, "status": "finished"},
            {"id": "4", "title": "Different case", "author": "frank Herbert", "pages": 100, "status": "unread"},
        ]

    def test_author_filter_trims_input_and_is_case_sensitive(self):
        self.assertEqual(
            ["1", "3"],
            [book["id"] for book in filter_books(self.books, author="  Frank Herbert  ")],
        )
        self.assertEqual(
            ["4"],
            [book["id"] for book in filter_books(self.books, author="frank Herbert")],
        )

    def test_author_and_status_filters_compose(self):
        selected = filter_books(self.books, author="Frank Herbert", status="finished")
        self.assertEqual(["3"], [book["id"] for book in selected])

    def test_unknown_author_returns_empty_list(self):
        self.assertEqual([], filter_books(self.books, author="Ursula Le Guin"))

    def test_filter_preserves_insertion_order_and_does_not_mutate_input(self):
        selected = filter_books(self.books, status="unread")
        self.assertEqual(["1", "4"], [book["id"] for book in selected])
        self.assertEqual(["1", "2", "3", "4"], [book["id"] for book in self.books])


if __name__ == "__main__":
    unittest.main()
