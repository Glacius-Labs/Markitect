"""Small Readinglog CLI for adding, listing, and finishing entries."""
import argparse
import csv
import json
from pathlib import Path
import sys

from entry_export import export_entries
from entry_queries import filter_entries


class JsonArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        raise ValueError(message)


def load_entries(path):
    entries = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
    if not isinstance(entries, list):
        raise ValueError("Invalid database shape")
    seen = set()
    for entry in entries:
        if not isinstance(entry, dict) or set(entry) != {"id", "title", "author", "pages", "status"}:
            raise ValueError("Invalid stored record")
        if any(not isinstance(entry[key], str) or not entry[key].strip() for key in ("id", "title", "author")):
            raise ValueError("Invalid stored text")
        if type(entry["pages"]) is not int or entry["pages"] <= 0 or entry["status"] not in ("unread", "finished"):
            raise ValueError("Invalid stored value")
        if entry["id"] in seen:
            raise ValueError("Duplicate stored id")
        seen.add(entry["id"])
    return entries


def save_entries(path, entries):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(entries, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def main():
    parser = JsonArgumentParser()
    parser.add_argument("--db", required=True, type=Path)
    actions = parser.add_subparsers(dest="command", required=True)
    listing = actions.add_parser("list")
    listing.add_argument("--status")
    listing.add_argument("--author")
    listing.add_argument("--legacy", action="store_true")
    add = actions.add_parser("add")
    for field in ("id", "title", "author", "pages"):
        add.add_argument("--" + field, required=True)
    finish = actions.add_parser("finish")
    finish.add_argument("--id", required=True)
    importing = actions.add_parser("import")
    importing.add_argument("--csv", required=True, type=Path)
    exporting = actions.add_parser("export")
    exporting.add_argument("--csv", required=True, type=Path)
    summary = actions.add_parser("summary")
    summary.add_argument("--author")
    summary.add_argument("--legacy", action="store_true")
    try:
        args = parser.parse_args()
        entries = load_entries(args.db)
        if args.command == "list":
            if args.status is not None and args.status not in ("unread", "finished"):
                raise ValueError("Invalid status; expected unread or finished")
            selected = filter_entries(entries, author=args.author, status=args.status)
            result = {"books" if args.legacy else "entries": selected}
        elif args.command == "finish":
            entry_id = args.id.strip()
            if not entry_id:
                raise ValueError("Entry id is required")
            result = next((entry for entry in entries if entry["id"] == entry_id), None)
            if result is None:
                raise ValueError("Entry not found")
            if result["status"] != "finished":
                result["status"] = "finished"
                save_entries(args.db, entries)
        elif args.command == "import":
            with args.csv.open("r", encoding="utf-8", newline="") as source:
                rows = csv.reader(source)
                header = next(rows, None)
                if header != ["id", "title", "author", "pages"]:
                    raise ValueError("CSV header must be id,title,author,pages")
                imported = []
                seen = {entry["id"] for entry in entries}
                for row_number, row in enumerate(rows, start=2):
                    if len(row) != 4:
                        raise ValueError(f"CSV row {row_number} must have exactly 4 columns")
                    text = {key: row[index].strip() for index, key in enumerate(("id", "title", "author"))}
                    try:
                        pages = int(row[3].strip())
                    except ValueError as error:
                        raise ValueError(f"CSV row {row_number} has invalid pages") from error
                    if not all(text.values()) or pages <= 0:
                        raise ValueError(f"CSV row {row_number} has invalid entry data")
                    if text["id"] in seen:
                        raise ValueError(f"CSV row {row_number} has duplicate id")
                    seen.add(text["id"])
                    imported.append(dict(text, pages=pages, status="unread"))
            if imported:
                entries.extend(imported)
                save_entries(args.db, entries)
            result = {"imported": len(imported)}
        elif args.command == "summary":
            authors = {}
            for entry in entries:
                if args.author is not None and entry["author"] != args.author.strip():
                    continue
                counts = authors.setdefault(
                    entry["author"], {"entries": 0, "finished": 0, "pages": 0}
                )
                counts["entries"] += 1
                counts["finished"] += entry["status"] == "finished"
                counts["pages"] += entry["pages"]
            if args.legacy:
                authors = {
                    name: {"books": counts["entries"], "finished": counts["finished"], "pages": counts["pages"]}
                    for name, counts in authors.items()
                }
            result = {"authors": [dict(author=name, **authors[name]) for name in sorted(authors)]}
        elif args.command == "export":
            same_path = args.csv.resolve() == args.db.resolve()
            if not same_path and args.csv.exists() and args.db.exists():
                same_path = args.csv.samefile(args.db)
            if same_path:
                raise ValueError("CSV export destination cannot be the database file")
            result = {"exported": export_entries(args.csv, entries)}
        else:
            text = {key: getattr(args, key).strip() for key in ("id", "title", "author")}
            pages = int(args.pages)
            if not all(text.values()) or pages <= 0 or any(entry["id"] == text["id"] for entry in entries):
                raise ValueError("Invalid or duplicate entry")
            result = dict(text, pages=pages, status="unread")
            entries.append(result)
            save_entries(args.db, entries)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except (ValueError, OSError, TypeError, KeyError, csv.Error) as error:
        print(json.dumps({"error": str(error)}))
        return 2


if __name__ == "__main__":
    sys.exit(main())
