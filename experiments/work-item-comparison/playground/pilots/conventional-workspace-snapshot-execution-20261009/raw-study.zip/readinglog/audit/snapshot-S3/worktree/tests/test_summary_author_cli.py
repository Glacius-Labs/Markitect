"""CLI regressions for author-filtered summary output."""
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


REPO = Path(__file__).resolve().parents[1]
APP = REPO / "app.py"
SCRATCH = REPO / ".scratch"


class SummaryAuthorCliContract(unittest.TestCase):
    def setUp(self):
        SCRATCH.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=SCRATCH)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.db = self.root / "books.json"
        self.env = os.environ.copy()
        self.env["TEMP"] = str(SCRATCH)
        self.env["TMP"] = str(SCRATCH)

    def call(self, *args):
        result = subprocess.run(
            [sys.executable, "-B", str(APP), "--db", str(self.db), *args],
            capture_output=True,
            text=True,
            cwd=REPO,
            env=self.env,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(len(result.stdout.splitlines()), 1, result.stderr)
        return json.loads(result.stdout)

    def add(self, book_id, title, author, pages):
        return self.call(
            "add", "--id", book_id, "--title", title,
            "--author", author, "--pages", str(pages),
        )

    def test_author_filter_trims_input_but_matches_case_exactly(self):
        self.add("ada", "Ada", "Ada Lovelace", 100)
        self.add("grace", "Grace", "Grace Hopper", 200)
        self.add("ada-lower", "Lowercase", "ada lovelace", 30)

        self.assertEqual(
            self.call("summary", "--author", "  Ada Lovelace  "),
            {"authors": [{"author": "Ada Lovelace", "books": 1, "finished": 0, "pages": 100}]},
        )
        self.assertEqual(self.call("summary", "--author", "ada lovelace"), {
            "authors": [{"author": "ada lovelace", "books": 1, "finished": 0, "pages": 30}],
        })
        self.assertEqual(self.call("summary", "--author", "  ADA LOVELACE "), {"authors": []})
        self.assertEqual(self.call("summary", "--author", "Missing Author"), {"authors": []})

    def test_summary_reflects_add_finish_and_csv_import_across_processes(self):
        self.add("ada-1", "First", "Ada", 100)
        self.add("ada-2", "Second", "Ada", 50)
        self.add("grace-1", "Third", "Grace", 200)

        # The add invocations above and each subsequent operation are separate
        # CLI processes, so these summaries also check persisted state.
        self.assertEqual(self.call("summary"), {"authors": [
            {"author": "Ada", "books": 2, "finished": 0, "pages": 150},
            {"author": "Grace", "books": 1, "finished": 0, "pages": 200},
        ]})

        self.call("finish", "--id", "ada-2")
        self.assertEqual(self.call("summary", "--author", "Ada"), {"authors": [
            {"author": "Ada", "books": 2, "finished": 1, "pages": 150},
        ]})

        imported = self.root / "import.csv"
        with imported.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(["id", "title", "author", "pages"])
            writer.writerow(["ada-3", "Third", "Ada", 75])
            writer.writerow(["grace-2", "Fourth", "Grace", 125])
        self.assertEqual(self.call("import", "--csv", str(imported)), {"imported": 2})

        self.assertEqual(self.call("summary"), {"authors": [
            {"author": "Ada", "books": 3, "finished": 1, "pages": 225},
            {"author": "Grace", "books": 2, "finished": 0, "pages": 325},
        ]})


if __name__ == "__main__":
    unittest.main()
