"""Pure query helpers for reading log entries."""


def filter_entries(entries, author=None, status=None):
    """Return entries matching optional author and status filters, in input order.

    The author filter is normalized by stripping surrounding whitespace and is
    compared exactly, including case, with each stored author.  When both
    filters are provided, an entry must match both.  The input iterable is not
    modified.
    """
    normalized_author = author.strip() if author is not None else None
    return [
        entry
        for entry in entries
        if (normalized_author is None or entry["author"] == normalized_author)
        and (status is None or entry["status"] == status)
    ]
