"""Pure query helpers for reading log book records."""


def filter_books(books, author=None, status=None):
    """Return books matching optional author and status filters, in input order.

    The author filter is normalized by stripping surrounding whitespace and is
    compared exactly, including case, with each stored author.  When both
    filters are provided, a book must match both.  The input iterable is not
    modified.
    """
    normalized_author = author.strip() if author is not None else None
    return [
        book
        for book in books
        if (normalized_author is None or book["author"] == normalized_author)
        and (status is None or book["status"] == status)
    ]
