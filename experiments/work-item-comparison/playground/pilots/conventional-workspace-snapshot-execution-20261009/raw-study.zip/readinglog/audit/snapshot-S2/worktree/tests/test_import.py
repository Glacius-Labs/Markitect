import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


APP = Path(__file__).resolve().parents[1] / "app.py"
WORKSPACE = APP.parent


class CsvImportContract(unittest.TestCase):
    def setUp(self):
        self.scratch = WORKSPACE / ".scratch"
        self.scratch.mkdir(exist_ok=True)
        self.folder = tempfile.TemporaryDirectory(dir=self.scratch)
        self.addCleanup(self.folder.cleanup)
        self.root = Path(self.folder.name)
        self.db = self.root / "books.json"
        self.env = os.environ.copy()
        self.env["TEMP"] = str(self.scratch)
        self.env["TMP"] = str(self.scratch)

    def call(self, *args):
        result = subprocess.run(
            [sys.executable, "-B", str(APP), "--db", str(self.db), *args],
            capture_output=True,
            text=True,
            env=self.env,
            cwd=WORKSPACE,
        )
        # The CLI contract is one JSON object on stdout, including errors.
        self.assertEqual(len(result.stdout.splitlines()), 1)
        return result.returncode, json.loads(result.stdout)

    def write_csv(self, name, rows, header=("id", "title", "author", "pages")):
        path = self.root / name
        with path.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.writer(stream)
            if header is not None:
                writer.writerow(header)
            writer.writerows(rows)
        return path

    def add_existing(self, book_id="existing"):
        code, record = self.call(
            "add", "--id", book_id, "--title", "Stored", "--author", "Reader", "--pages", "7"
        )
        self.assertEqual(code, 0)
        return record

    def test_import_normalizes_and_appends_in_input_order_across_restart(self):
        existing = self.add_existing()
        path = self.write_csv(
            "valid.csv",
            [
                ["  second ", "  A title  ", "  A writer ", "12"],
                ["third", "Another", "Writer", "3"],
            ],
        )

        self.assertEqual(self.call("import", "--csv", str(path)), (0, {"imported": 2}))
        imported = [
            {"id": "second", "title": "A title", "author": "A writer", "pages": 12, "status": "unread"},
            {"id": "third", "title": "Another", "author": "Writer", "pages": 3, "status": "unread"},
        ]
        self.assertEqual(self.call("list"), (0, {"books": [existing, *imported]}))
        # A separate CLI process sees the committed records in the same order.
        self.assertEqual(self.call("list"), (0, {"books": [existing, *imported]}))

    def test_valid_header_with_no_data_rows_imports_zero(self):
        path = self.write_csv("empty.csv", [])

        self.assertEqual(self.call("import", "--csv", str(path)), (0, {"imported": 0}))
        self.assertEqual(self.call("list"), (0, {"books": []}))

    def test_rejects_wrong_missing_or_extra_header_columns(self):
        self.add_existing()
        before = self.db.read_bytes()
        invalid_headers = [
            ("wrong-order.csv", ("title", "id", "author", "pages")),
            ("missing-column.csv", ("id", "title", "author")),
            ("extra-column.csv", ("id", "title", "author", "pages", "status")),
            ("no-header.csv", None),
            ("empty-file.csv", None),
        ]
        for name, header in invalid_headers:
            with self.subTest(header=header):
                rows = [] if name == "empty-file.csv" else [["new", "New title", "Writer", "10"]]
                path = self.write_csv(name, rows, header=header)
                code, output = self.call("import", "--csv", str(path))
                self.assertEqual(code, 2)
                self.assertEqual(set(output), {"error"})
                self.assertTrue(output["error"])
                self.assertEqual(self.db.read_bytes(), before)

    def test_late_invalid_rows_reject_the_whole_file_without_mutation(self):
        self.add_existing()
        before = self.db.read_bytes()
        invalid_files = {
            "bad-pages.csv": [["valid", "Good", "Writer", "10"], ["bad", "Bad", "Writer", "0"]],
            "non-integer-pages.csv": [["valid", "Good", "Writer", "10"], ["bad", "Bad", "Writer", "many"]],
            "blank-title.csv": [["valid", "Good", "Writer", "10"], ["bad", "   ", "Writer", "2"]],
            "blank-author.csv": [["valid", "Good", "Writer", "10"], ["bad", "Bad", "  ", "2"]],
            "blank-id.csv": [["valid", "Good", "Writer", "10"], [" ", "Bad", "Writer", "2"]],
        }
        for name, rows in invalid_files.items():
            with self.subTest(file=name):
                path = self.write_csv(name, rows)
                code, output = self.call("import", "--csv", str(path))
                self.assertEqual(code, 2)
                self.assertEqual(set(output), {"error"})
                self.assertTrue(output["error"])
                self.assertEqual(self.db.read_bytes(), before)
                self.assertEqual(self.call("list")[1], {"books": [
                    {"id": "existing", "title": "Stored", "author": "Reader", "pages": 7, "status": "unread"}
                ]})

    def test_rejects_ids_repeated_in_file_or_already_in_database(self):
        existing = self.add_existing()
        before = self.db.read_bytes()
        duplicate_inputs = {
            "database-duplicate.csv": [[" existing ", "Copy", "Writer", "1"]],
            "file-duplicate.csv": [["new", "First", "Writer", "1"], [" new ", "Second", "Writer", "2"]],
        }
        for name, rows in duplicate_inputs.items():
            with self.subTest(file=name):
                path = self.write_csv(name, rows)
                code, output = self.call("import", "--csv", str(path))
                self.assertEqual(code, 2)
                self.assertEqual(set(output), {"error"})
                self.assertTrue(output["error"])
                self.assertEqual(self.db.read_bytes(), before)
        # Identity remains case-sensitive, matching add.
        path = self.write_csv("case-sensitive.csv", [["Existing", "Different ID", "Writer", "1"]])
        self.assertEqual(self.call("import", "--csv", str(path)), (0, {"imported": 1}))
        self.assertEqual(self.call("list")[1]["books"][0], existing)


if __name__ == "__main__":
    unittest.main()
