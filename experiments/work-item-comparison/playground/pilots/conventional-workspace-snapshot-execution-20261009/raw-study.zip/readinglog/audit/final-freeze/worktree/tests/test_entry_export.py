import copy
import csv
from pathlib import Path
import tempfile
import unittest

from entry_export import export_entries


class EntryExportContract(unittest.TestCase):
    def setUp(self):
        scratch = Path(__file__).resolve().parents[1] / ".scratch"
        scratch.mkdir(exist_ok=True)
        self.folder = tempfile.TemporaryDirectory(dir=scratch)
        self.addCleanup(self.folder.cleanup)
        self.root = Path(self.folder.name)

    def read_csv(self, path):
        with path.open("r", encoding="utf-8", newline="") as source:
            return list(csv.reader(source))

    def test_exports_quoted_fields_statuses_and_insertion_order(self):
        entries = [
            {
                "id": "first,one",
                "title": "A title, with comma\nand newline",
                "author": 'Writer "One"',
                "pages": 12,
                "status": "unread",
            },
            {
                "id": "second",
                "title": "Second entry",
                "author": "Another Writer",
                "pages": 3,
                "status": "finished",
            },
        ]
        path = self.root / "books.csv"

        self.assertEqual(export_entries(path, entries), 2)
        self.assertEqual(
            self.read_csv(path),
            [
                ["id", "title", "author", "pages", "status"],
                ["first,one", "A title, with comma\nand newline", 'Writer "One"', "12", "unread"],
                ["second", "Second entry", "Another Writer", "3", "finished"],
            ],
        )

    def test_empty_export_writes_only_exact_header(self):
        path = self.root / "empty.csv"

        self.assertEqual(export_entries(path, []), 0)
        self.assertEqual(path.read_bytes(), b"id,title,author,pages,status\r\n")
        self.assertEqual(self.read_csv(path), [["id", "title", "author", "pages", "status"]])

    def test_does_not_mutate_supplied_entries(self):
        entries = [
            {"id": "one", "title": "Title", "author": "Writer", "pages": 1, "status": "unread"}
        ]
        original = copy.deepcopy(entries)

        export_entries(self.root / "entries.csv", entries)

        self.assertEqual(entries, original)

    def test_destination_os_error_propagates(self):
        unavailable_path = self.root / "missing" / "books.csv"

        with self.assertRaises(FileNotFoundError):
            export_entries(unavailable_path, [])


if __name__ == "__main__":
    unittest.main()
