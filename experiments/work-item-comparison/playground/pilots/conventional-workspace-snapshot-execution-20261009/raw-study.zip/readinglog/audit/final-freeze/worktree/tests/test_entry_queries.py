import unittest

from entry_queries import filter_entries


class FilterEntriesTests(unittest.TestCase):
    def setUp(self):
        self.entries = [
            {"id": "1", "title": "Dune", "author": "Frank Herbert", "pages": 412, "status": "unread"},
            {"id": "2", "title": "The Hobbit", "author": "J.R.R. Tolkien", "pages": 310, "status": "finished"},
            {"id": "3", "title": "Dune Messiah", "author": "Frank Herbert", "pages": 256, "status": "finished"},
            {"id": "4", "title": "Different case", "author": "frank Herbert", "pages": 100, "status": "unread"},
        ]

    def test_author_filter_trims_input_and_is_case_sensitive(self):
        self.assertEqual(
            ["1", "3"],
            [entry["id"] for entry in filter_entries(self.entries, author="  Frank Herbert  ")],
        )
        self.assertEqual(
            ["4"],
            [entry["id"] for entry in filter_entries(self.entries, author="frank Herbert")],
        )

    def test_author_and_status_filters_compose(self):
        selected = filter_entries(self.entries, author="Frank Herbert", status="finished")
        self.assertEqual(["3"], [entry["id"] for entry in selected])

    def test_unknown_author_returns_empty_list(self):
        self.assertEqual([], filter_entries(self.entries, author="Ursula Le Guin"))

    def test_filter_preserves_insertion_order_and_does_not_mutate_input(self):
        selected = filter_entries(self.entries, status="unread")
        self.assertEqual(["1", "4"], [entry["id"] for entry in selected])
        self.assertEqual(["1", "2", "3", "4"], [entry["id"] for entry in self.entries])


if __name__ == "__main__":
    unittest.main()
