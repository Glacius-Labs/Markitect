"""Small Readinglog CLI for adding, listing, and finishing books."""
import argparse
import csv
import json
from pathlib import Path
import sys

from book_export import export_books
from book_queries import filter_books


class JsonArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        raise ValueError(message)


def load(path):
    books = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
    if not isinstance(books, list):
        raise ValueError("Invalid database shape")
    seen = set()
    for book in books:
        if not isinstance(book, dict) or set(book) != {"id", "title", "author", "pages", "status"}:
            raise ValueError("Invalid stored record")
        if any(not isinstance(book[key], str) or not book[key].strip() for key in ("id", "title", "author")):
            raise ValueError("Invalid stored text")
        if type(book["pages"]) is not int or book["pages"] <= 0 or book["status"] not in ("unread", "finished"):
            raise ValueError("Invalid stored value")
        if book["id"] in seen:
            raise ValueError("Duplicate stored id")
        seen.add(book["id"])
    return books


def save(path, books):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(books, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def main():
    parser = JsonArgumentParser()
    parser.add_argument("--db", required=True, type=Path)
    actions = parser.add_subparsers(dest="command", required=True)
    listing = actions.add_parser("list")
    listing.add_argument("--status")
    listing.add_argument("--author")
    add = actions.add_parser("add")
    for field in ("id", "title", "author", "pages"):
        add.add_argument("--" + field, required=True)
    finish = actions.add_parser("finish")
    finish.add_argument("--id", required=True)
    importing = actions.add_parser("import")
    importing.add_argument("--csv", required=True, type=Path)
    exporting = actions.add_parser("export")
    exporting.add_argument("--csv", required=True, type=Path)
    summary = actions.add_parser("summary")
    summary.add_argument("--author")
    try:
        args = parser.parse_args()
        books = load(args.db)
        if args.command == "list":
            if args.status is not None and args.status not in ("unread", "finished"):
                raise ValueError("Invalid status; expected unread or finished")
            selected = filter_books(books, author=args.author, status=args.status)
            result = {"books": selected}
        elif args.command == "finish":
            book_id = args.id.strip()
            if not book_id:
                raise ValueError("Book id is required")
            result = next((book for book in books if book["id"] == book_id), None)
            if result is None:
                raise ValueError("Book not found")
            if result["status"] != "finished":
                result["status"] = "finished"
                save(args.db, books)
        elif args.command == "import":
            with args.csv.open("r", encoding="utf-8", newline="") as source:
                rows = csv.reader(source)
                header = next(rows, None)
                if header != ["id", "title", "author", "pages"]:
                    raise ValueError("CSV header must be id,title,author,pages")
                imported = []
                seen = {book["id"] for book in books}
                for row_number, row in enumerate(rows, start=2):
                    if len(row) != 4:
                        raise ValueError(f"CSV row {row_number} must have exactly 4 columns")
                    text = {key: row[index].strip() for index, key in enumerate(("id", "title", "author"))}
                    try:
                        pages = int(row[3].strip())
                    except ValueError as error:
                        raise ValueError(f"CSV row {row_number} has invalid pages") from error
                    if not all(text.values()) or pages <= 0:
                        raise ValueError(f"CSV row {row_number} has invalid book data")
                    if text["id"] in seen:
                        raise ValueError(f"CSV row {row_number} has duplicate id")
                    seen.add(text["id"])
                    imported.append(dict(text, pages=pages, status="unread"))
            if imported:
                books.extend(imported)
                save(args.db, books)
            result = {"imported": len(imported)}
        elif args.command == "summary":
            authors = {}
            for book in books:
                if args.author is not None and book["author"] != args.author.strip():
                    continue
                counts = authors.setdefault(book["author"], {"books": 0, "finished": 0, "pages": 0})
                counts["books"] += 1
                counts["finished"] += book["status"] == "finished"
                counts["pages"] += book["pages"]
            result = {"authors": [dict(author=name, **authors[name]) for name in sorted(authors)]}
        elif args.command == "export":
            same_path = args.csv.resolve() == args.db.resolve()
            if not same_path and args.csv.exists() and args.db.exists():
                same_path = args.csv.samefile(args.db)
            if same_path:
                raise ValueError("CSV export destination cannot be the database file")
            result = {"exported": export_books(args.csv, books)}
        else:
            text = {key: getattr(args, key).strip() for key in ("id", "title", "author")}
            pages = int(args.pages)
            if not all(text.values()) or pages <= 0 or any(book["id"] == text["id"] for book in books):
                raise ValueError("Invalid or duplicate book")
            result = dict(text, pages=pages, status="unread")
            books.append(result)
            save(args.db, books)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except (ValueError, OSError, TypeError, KeyError, csv.Error) as error:
        print(json.dumps({"error": str(error)}))
        return 2


if __name__ == "__main__":
    sys.exit(main())
