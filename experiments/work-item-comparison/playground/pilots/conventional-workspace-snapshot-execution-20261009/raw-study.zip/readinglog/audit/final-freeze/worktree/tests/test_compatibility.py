import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


REPO = Path(__file__).resolve().parents[1]
APP = REPO / "app.py"
SCRATCH = REPO / ".scratch"


class EntryRenameCompatibility(unittest.TestCase):
    def setUp(self):
        SCRATCH.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=SCRATCH)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.db = self.root / "state.json"
        self.env = os.environ.copy()
        self.env["TEMP"] = str(SCRATCH)
        self.env["TMP"] = str(SCRATCH)

    def call(self, *args, expected_code=0):
        proc = subprocess.run(
            [sys.executable, "-B", str(APP), "--db", str(self.db), *args],
            capture_output=True,
            text=True,
            cwd=REPO,
            env=self.env,
        )
        self.assertEqual(proc.returncode, expected_code, proc.stderr)
        self.assertEqual(len(proc.stdout.splitlines()), 1, proc.stderr)
        return json.loads(proc.stdout)

    def test_new_and_legacy_outputs_read_prechange_data_without_rewriting(self):
        old_entries = [
            {"id": "old-1", "title": "Stored Café", "author": "Ada Lovelace", "pages": 100, "status": "unread"},
            {"id": "old-2", "title": "Second", "author": "Ada Lovelace", "pages": 50, "status": "finished"},
            {"id": "other", "title": "Other", "author": "Grace Hopper", "pages": 200, "status": "unread"},
        ]
        # This is the raw record array written by the pre-rename implementation.
        prechange_bytes = (json.dumps(old_entries, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
        self.db.write_bytes(prechange_bytes)

        self.assertEqual(self.call("list"), {"entries": old_entries})
        self.assertEqual(self.call("list", "--legacy"), {"books": old_entries})
        self.assertEqual(
            self.call("list", "--author", " Ada Lovelace ", "--status", "unread"),
            {"entries": [old_entries[0]]},
        )
        self.assertEqual(
            self.call("list", "--legacy", "--author", " Ada Lovelace ", "--status", "unread"),
            {"books": [old_entries[0]]},
        )
        self.assertEqual(
            self.call("list", "--author", "Ada Lovelace", "--status", "finished", "--legacy"),
            {"books": [old_entries[1]]},
        )
        self.assertEqual(self.call("summary"), {"authors": [
            {"author": "Ada Lovelace", "entries": 2, "finished": 1, "pages": 150},
            {"author": "Grace Hopper", "entries": 1, "finished": 0, "pages": 200},
        ]})
        self.assertEqual(self.call("summary", "--author", " Ada Lovelace "), {"authors": [
            {"author": "Ada Lovelace", "entries": 2, "finished": 1, "pages": 150},
        ]})
        self.assertEqual(self.call("summary", "--legacy", "--author", " Ada Lovelace "), {"authors": [
            {"author": "Ada Lovelace", "books": 2, "finished": 1, "pages": 150},
        ]})
        self.assertEqual(self.call("summary", "--author", "Unknown"), {"authors": []})
        self.assertEqual(self.call("summary", "--legacy", "--author", "Unknown"), {"authors": []})
        # All read-only output-name changes leave the old database bytes intact.
        self.assertEqual(self.db.read_bytes(), prechange_bytes)

        # Every command continues to operate on the original stored records.
        added = {"id": "new", "title": "New entry", "author": "Ada Lovelace", "pages": 25, "status": "unread"}
        self.assertEqual(
            self.call("add", "--id", "new", "--title", "New entry", "--author", "Ada Lovelace", "--pages", "25"),
            added,
        )
        self.assertEqual(
            self.call("finish", "--id", "old-1"),
            {**old_entries[0], "status": "finished"},
        )
        incoming = self.root / "incoming.csv"
        incoming.write_text(
            "id,title,author,pages\nimported,Imported,Ada Lovelace,75\n",
            encoding="utf-8",
        )
        self.assertEqual(self.call("import", "--csv", str(incoming)), {"imported": 1})

        exported = self.root / "export.csv"
        self.assertEqual(self.call("export", "--csv", str(exported)), {"exported": 5})
        with exported.open(encoding="utf-8", newline="") as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual([row["id"] for row in rows], ["old-1", "old-2", "other", "new", "imported"])
        self.assertEqual(rows[0]["status"], "finished")

        stored = json.loads(self.db.read_text(encoding="utf-8"))
        self.assertEqual(len(stored), 5)
        self.assertTrue(all(set(entry) == {"id", "title", "author", "pages", "status"} for entry in stored))
        self.assertEqual(self.call("list")["entries"], stored)
        self.assertEqual(self.call("list", "--legacy")["books"], stored)
        self.assertEqual(self.call("summary")["authors"][0], {
            "author": "Ada Lovelace", "entries": 4, "finished": 2, "pages": 250
        })
        self.assertEqual(self.call("summary", "--legacy")["authors"][0], {
            "author": "Ada Lovelace", "books": 4, "finished": 2, "pages": 250
        })


if __name__ == "__main__":
    unittest.main()
