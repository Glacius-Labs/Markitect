"""CSV export helpers for reading log entries."""

import csv
from pathlib import Path


HEADER = ("id", "title", "author", "pages", "status")


def export_entries(path, entries):
    """Write entries to *path* as UTF-8 CSV and return the number written.

    The supplied sequence is read in its existing order and is never modified.
    File-system errors are allowed to propagate to the caller.
    """
    with Path(path).open("w", encoding="utf-8", newline="") as destination:
        writer = csv.writer(destination)
        writer.writerow(HEADER)
        for entry in entries:
            writer.writerow(entry[field] for field in HEADER)
    return len(entries)
