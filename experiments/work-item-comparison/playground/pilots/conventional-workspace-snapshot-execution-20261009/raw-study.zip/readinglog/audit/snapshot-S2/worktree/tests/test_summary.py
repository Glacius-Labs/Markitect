"""CLI regressions for author summaries and persisted finish state."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


REPO = Path(__file__).resolve().parents[1]
APP = REPO / "app.py"
SCRATCH = REPO / ".scratch"


class SummaryContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        SCRATCH.mkdir(exist_ok=True)

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory(dir=SCRATCH)
        self.addCleanup(self.temp_dir.cleanup)
        self.db = Path(self.temp_dir.name) / "books.json"
        self.env = os.environ.copy()
        # Keep subprocess temporary-file activity inside the writable workspace.
        self.env["TEMP"] = str(SCRATCH)
        self.env["TMP"] = str(SCRATCH)

    def run_cli(self, *args):
        return subprocess.run(
            [sys.executable, "-B", str(APP), "--db", str(self.db), *args],
            capture_output=True,
            text=True,
            env=self.env,
            cwd=REPO,
        )

    def assert_success(self, result, expected_json):
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, json.dumps(expected_json, ensure_ascii=False) + "\n")

    def add_book(self, book_id, title, author, pages):
        result = self.run_cli(
            "add", "--id", book_id, "--title", title,
            "--author", author, "--pages", str(pages),
        )
        expected = {
            "id": book_id,
            "title": title,
            "author": author,
            "pages": pages,
            "status": "unread",
        }
        self.assert_success(result, expected)
        return expected

    def test_empty_database_summary_has_exact_output(self):
        # A missing data file represents empty state.
        self.assert_success(self.run_cli("summary"), {"authors": []})

        # An explicitly persisted empty array has the same summary.
        self.db.write_text("[]\n", encoding="utf-8")
        self.assert_success(self.run_cli("summary"), {"authors": []})

    def test_lexical_author_aggregates_and_finish_persist_across_processes(self):
        # Deliberately add authors out of lexical order and spread records/statuses
        # across each author so counts, pages, and finished totals are all visible.
        self.add_book("z1", "Late Summer", "Zoe", 210)
        self.add_book("m1", "First Mira", "Mira", 90)
        self.add_book("a1", "Ada One", "Ada", 120)
        self.add_book("a2", "Ada Two", "Ada", 80)
        self.add_book("m2", "Second Mira", "Mira", 140)

        before_finish = {
            "authors": [
                {"author": "Ada", "books": 2, "finished": 0, "pages": 200},
                {"author": "Mira", "books": 2, "finished": 0, "pages": 230},
                {"author": "Zoe", "books": 1, "finished": 0, "pages": 210},
            ]
        }
        self.assert_success(self.run_cli("summary"), before_finish)

        self.assert_success(
            self.run_cli("finish", "--id", "a2"),
            {"id": "a2", "title": "Ada Two", "author": "Ada", "pages": 80, "status": "finished"},
        )
        self.assert_success(
            self.run_cli("finish", "--id", "m1"),
            {"id": "m1", "title": "First Mira", "author": "Mira", "pages": 90, "status": "finished"},
        )

        after_finish = {
            "authors": [
                {"author": "Ada", "books": 2, "finished": 1, "pages": 200},
                {"author": "Mira", "books": 2, "finished": 1, "pages": 230},
                {"author": "Zoe", "books": 1, "finished": 0, "pages": 210},
            ]
        }
        # This is a fresh CLI process; its summary must reflect both committed changes.
        self.assert_success(self.run_cli("summary"), after_finish)


if __name__ == "__main__":
    unittest.main()
