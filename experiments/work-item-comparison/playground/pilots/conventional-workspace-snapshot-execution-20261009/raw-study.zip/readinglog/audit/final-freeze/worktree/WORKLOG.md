# Worklog

## S1

- Released scope: B01 only, from `.study/station.json`; no unreleased items implemented.
- Implemented `finish --id` with whitespace normalization, missing-ID errors, idempotent results, and persisted transitions. Added `list --status unread|finished`, preserving insertion order and default unfiltered output.
- Updated README usage and behavior notes. Added CLI regression coverage for finish, repeat finish, filtering, ordering, errors, and persistence across process invocations.
- Assumption: finish IDs follow add's surrounding-whitespace normalization while remaining case-sensitive.
- Runtime/setup: `.study/runtime-profile.json` requests `gpt-6-luna` at high effort. This interface does not expose native provider/usage telemetry, so actual model-runtime identity and token receipts are unknown; no explicit override or fallback was made.
- Checks: `python -B -m unittest discover -s tests -v` passed (2 tests); `python -B checks/acceptance.py --case readinglog --station 1` passed (5 public findings).
- Check setup issue and repair: initial runs used the OS temp path, which child processes could not write under the sandbox. Reran both checks with `TEMP` and `TMP` set to ignored workspace-local `.scratch`; both then passed. The Python launcher emitted a real-location warning, but child CLI processes ran and checks completed successfully.
- Reviews/team: no subagents were needed for this single released item; S1 does not require a team.

## S2

- Released scope: B02, B03, B04, from `.study/station.json`; no S3/S4 items implemented.
- Implemented all-or-nothing UTF-8 CSV import with exact header/row widths, trimmed text, positive integer pages, case-sensitive duplicate detection across existing and incoming records, and input-order append. Added lexical author summary with all-book/page totals and finished counts.
- Updated README usage and behavior. Added independent import and summary CLI regression suites; retained S1 tests. Normalized command-line parser errors to the documented one-line JSON error response and added a regression check for missing required arguments.
- Assumptions: a CSV file must contain the exact header even when it has no data rows; a valid header-only file returns zero without rewriting the database. The existing single-writer atomic replacement is sufficient; no concurrent multiwriter behavior is promised.
- Team contributions: `/root/import_tests` (requested gpt-6-luna/high) added only `tests/test_import.py` (5 tests); reported interval approximately 20:54–20:56 UTC, exact start unavailable. `/root/summary_tests` (requested gpt-6-luna/high) added only `tests/test_summary.py` (2 tests); reported interval approximately 22:58–23:02 Europe/Berlin, exact timing unavailable. Both were observed active concurrently in native agent status; precise start/finish telemetry is unavailable. Their isolated checks passed; primary integration review found no file conflicts. Native token/provider receipts are unavailable. The installed profile was used for requested helper model/effort; actual runtime telemetry remains unknown.
- Checks: `python -B -m unittest discover -s tests -v` passed (10 tests); `python -B checks/acceptance.py --case readinglog --station 2` passed (8 public findings); `git diff --check` passed.
- Check setup issue and repair: set `TEMP` and `TMP` to workspace-local ignored `.scratch` for child-process temp writes. The Python launcher still printed a real-location warning to stderr; child CLI processes ran and all checks completed successfully.
- Open work: none within S2. Next: stop at the S2 station boundary and hand off the workspace snapshot.

## S3

- Released scope: B05–B11 from `.study/station.json`; no S4 rename work implemented.
- Added case-sensitive trimmed author filtering for `list`, composable with status and stable in insertion order; added matching filtered `summary`; added UTF-8 CSV export with the required header, status, quoting, row order, error reporting, database nonmutation, and guard against exporting over the database.
- Split work into pure query/export helper modules and CLI integration. Updated README for author filters and export. Added direct helper tests and CLI integration regressions. `TEAMWORK.md` records roles, contributions, overlap, review, and telemetry limitations.
- Checks: `python -B -m unittest discover -s tests -v` passed (23 tests); `python -B checks/acceptance.py --case readinglog --station 3` passed (11 public findings); `git diff --check` passed.
- Team test setup repair: export helper's first direct test attempt used system temp outside writable roots and failed; moving its temporary directory under `.scratch` resolved it. Final full suite and acceptance then passed. The interpreter again emitted its real-location warning without preventing CLI process execution. No integration conflicts remained.
- Runtime/receipts: all helper roles were requested with the profile's `gpt-6-luna`/high setting. Export and summary agents were observed running concurrently around 20:59 UTC; see `TEAMWORK.md` for intervals, native role receipts, contributions, and unknown model/provider/token telemetry. No intentional override/fallback was made.
- Open work: none within S3. Next: stop at the S3 station boundary and hand off the workspace snapshot.

## S4

- Released scope: B12 only.
- Compatibility decision was stated before implementation: new list/summary outputs use `entries`; `--legacy` on those commands preserves the former `books` keys and composes with filters. Command names, CSV headers, and raw stored record fields remain unchanged. Reading pre-change files never rewrites them.
- Renamed active code helpers and variables to entry terminology; updated default interfaces, tests, and README. Added a pre-change JSON fixture test covering default and legacy list/summary, author/status filtering, unchanged bytes after reads, and add/finish/import/export operating on the old records.
- No product configuration or Markitect model/view artifacts are part of this Conventional project; no such artifacts were created or changed. The controller's station metadata was left intact.
- Checks: `python -B -m py_compile app.py entry_export.py entry_queries.py` passed; `python -B -m unittest discover -s tests -v` passed (24 tests); `python -B checks/acceptance.py --case readinglog --station 4` passed (13 public findings); `git diff --check` passed.
- Repair note: one test patch did not match the file's exact expected block; I reread the test and applied the key changes against its current contents. No test or application failure remained. The Python launcher continued to print its real-location warning while checks exited successfully.
- Runtime: profile requests `gpt-6-luna` / high; this interface does not expose exact active model/provider or token usage. No explicit override/fallback was made.
- Open work: none in the released backlog. Stop at the S4 station boundary.
