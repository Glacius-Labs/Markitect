import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


APP = Path(__file__).resolve().parents[1] / "app.py"


class ExistingContract(unittest.TestCase):
    def test_add_list_restart_duplicate_and_invalid_input(self):
        with tempfile.TemporaryDirectory() as folder:
            db = Path(folder) / "books.json"
            def call(*args):
                result = subprocess.run([sys.executable, "-B", str(APP), "--db", str(db), *args], capture_output=True, text=True)
                return result.returncode, json.loads(result.stdout)
            self.assertEqual(call("list"), (0, {"books": []}))
            code, book = call("add", "--id", " a ", "--title", " Example ", "--author", " Writer ", "--pages", "120")
            self.assertEqual(code, 0)
            self.assertEqual(book, {"id": "a", "title": "Example", "author": "Writer", "pages": 120, "status": "unread"})
            self.assertEqual(call("list"), (0, {"books": [book]}))
            before = db.read_bytes()
            self.assertEqual(call("add", "--id", "a", "--title", "Again", "--author", "Writer", "--pages", "1")[0], 2)
            self.assertEqual(call("add", "--id", "b", "--title", "Bad", "--author", "Writer", "--pages", "0")[0], 2)
            self.assertEqual(db.read_bytes(), before)

    def test_finish_is_idempotent_and_status_filter_preserves_order(self):
        with tempfile.TemporaryDirectory() as folder:
            db = Path(folder) / "books.json"

            def call(*args):
                result = subprocess.run([sys.executable, "-B", str(APP), "--db", str(db), *args],
                                         capture_output=True, text=True)
                return result.returncode, json.loads(result.stdout)

            first = call("add", "--id", "one", "--title", "First", "--author", "Writer", "--pages", "10")[1]
            second = call("add", "--id", "two", "--title", "Second", "--author", "Writer", "--pages", "20")[1]
            self.assertEqual(call("list", "--status", "unread"), (0, {"books": [first, second]}))
            self.assertEqual(call("finish", "--id", " one "), (0, {**first, "status": "finished"}))
            finished = {**first, "status": "finished"}
            self.assertEqual(call("finish", "--id", "one"), (0, finished))
            self.assertEqual(call("list", "--status", "finished"), (0, {"books": [finished]}))
            self.assertEqual(call("list"), (0, {"books": [finished, second]}))
            self.assertEqual(call("finish", "--id", "missing")[0], 2)
            self.assertEqual(call("list", "--status", "archived")[0], 2)
            # A fresh process observes the persisted status transition.
            self.assertEqual(call("list", "--status", "finished"), (0, {"books": [finished]}))

    def test_argument_errors_use_json_contract_without_mutating_database(self):
        with tempfile.TemporaryDirectory() as folder:
            db = Path(folder) / "books.json"
            result = subprocess.run(
                [sys.executable, "-B", str(APP), "--db", str(db), "add", "--id", "incomplete"],
                capture_output=True,
                text=True,
            )
            self.assertEqual(result.returncode, 2)
            self.assertEqual(len(result.stdout.splitlines()), 1)
            self.assertIn("error", json.loads(result.stdout))
            self.assertFalse(db.exists())


if __name__ == "__main__":
    unittest.main()
