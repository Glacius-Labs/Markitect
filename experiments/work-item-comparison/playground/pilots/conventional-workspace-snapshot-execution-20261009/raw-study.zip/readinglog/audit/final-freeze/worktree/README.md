# Readinglog

This is a small Python 3.13 standard-library CLI for reading log entries stored in a JSON array. Existing command names and stored record fields remain stable. No network or external package is needed.

`python -B app.py --db PATH COMMAND ...`

Examples:

```text
python -B app.py --db reading.json add --id 1 --title Dune --author "Frank Herbert" --pages 412
python -B app.py --db reading.json finish --id 1
python -B app.py --db reading.json list --status unread
python -B app.py --db reading.json list
python -B app.py --db reading.json list --author "Frank Herbert" --status unread
python -B app.py --db reading.json import --csv additions.csv
python -B app.py --db reading.json export --csv backup.csv
python -B app.py --db reading.json summary
python -B app.py --db reading.json summary --author "Frank Herbert"
python -B app.py --db reading.json list --legacy
python -B app.py --db reading.json summary --legacy
```

Commands:

- `add --id ID --title TITLE --author AUTHOR --pages INTEGER` creates an entry record `{id,title,author,pages,status:"unread"}` and returns it. IDs are nonempty and case-sensitive, unique; surrounding whitespace on text input is stripped, required text cannot be empty, and pages must be a positive integer. Invalid or duplicate input returns `{"error":"..."}` and exit 2 without mutation.
- `list` returns `{"entries":[...]}` in insertion order, including every status. Optional `--status unread|finished` filters statuses without changing order.
- `list --author NAME` trims surrounding whitespace and matches the author exactly, including case. It composes with `--status`; results retain insertion order. An unknown author returns an empty list.
- `finish --id ID` marks the matching entry ID as `finished`. Surrounding whitespace on the ID is stripped, and repeating the command returns the same record without changing its status again.

- `import --csv PATH` imports UTF-8 CSV with exactly the header `id,title,author,pages`. It validates the whole file before changing the database, including required text, positive integer pages, and IDs duplicated within the file or against existing records. Any invalid row rejects the entire import without changing data. Success returns `{"imported":COUNT}` and appends unread entries in input order. A file with only the valid header imports zero; incorrect, missing, or extra columns fail. Text and IDs use the same trimming and case-sensitive identity as `add`.
- `summary` returns `{"authors":[{"author":NAME,"entries":COUNT,"finished":COUNT,"pages":TOTAL},...]}` ordered lexically by author. It counts every entry and its pages; `finished` counts only finished entries.
- `summary --author NAME` applies the same trimmed, case-sensitive exact author match. An unknown author returns `{"authors":[]}`; without the filter, summary behavior is unchanged.
- `export --csv PATH` writes UTF-8 CSV with header `id,title,author,pages,status` in insertion order, using CSV quoting for commas and newlines. It returns `{"exported":COUNT}` and does not change the database. A destination that is the database itself or cannot be written is an error.

Compatibility for one release period: `list --legacy` returns the former `{"books":[...]}` shape, and `summary --legacy` uses `"books"` for each author's count. Both switches compose with their author/status filters. Reads accept existing stored record arrays as-is and never rewrite them just to change output naming.

All successes write one JSON object and exit 0; domain/input errors write one error object and exit 2. Persist successful changes via atomic replacement; a missing data file is empty state and malformed existing data must not be overwritten. A second process on the same data observes committed results. No concurrent multiwriter guarantee is required.
