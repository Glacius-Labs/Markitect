import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


REPO = Path(__file__).resolve().parents[1]
APP = REPO / "app.py"
SCRATCH = REPO / ".scratch"


class S3CliContract(unittest.TestCase):
    def setUp(self):
        SCRATCH.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=SCRATCH)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.db = self.root / "books.json"
        self.env = os.environ.copy()
        self.env["TEMP"] = str(SCRATCH)
        self.env["TMP"] = str(SCRATCH)

    def call(self, *args):
        proc = subprocess.run(
            [sys.executable, "-B", str(APP), "--db", str(self.db), *args],
            capture_output=True,
            text=True,
            cwd=REPO,
            env=self.env,
        )
        self.assertEqual(len(proc.stdout.splitlines()), 1, proc.stderr)
        return proc.returncode, json.loads(proc.stdout), proc.stderr

    def add(self, book_id, title, author, pages):
        return self.call("add", "--id", book_id, "--title", title,
                         "--author", author, "--pages", str(pages))[1]

    def test_author_and_status_filters_compose_preserve_order_and_restart(self):
        self.add("a", "One", "Writer", 10)
        self.add("b", "Two", "Reader", 20)
        self.add("c", "Three", "Writer", 30)
        self.call("finish", "--id", "c")

        code, output, _ = self.call("list", "--author", " Writer ", "--status", "finished")
        self.assertEqual(code, 0)
        self.assertEqual([entry["id"] for entry in output["entries"]], ["c"])
        code, output, _ = self.call("list", "--author", "Writer", "--status", "unread")
        self.assertEqual(code, 0)
        self.assertEqual([entry["id"] for entry in output["entries"]], ["a"])
        self.assertEqual(self.call("list", "--author", "unknown")[1], {"entries": []})

    def test_export_quotes_statuses_preserves_database_and_reimports_text(self):
        title = "A title, with a comma\nand another line"
        self.add("a", title, "Writer, Jr.", 11)
        self.add("b", "Finished", "Reader", 12)
        self.call("finish", "--id", "b")
        before = self.db.read_bytes()
        destination = self.root / "export.csv"

        code, output, _ = self.call("export", "--csv", str(destination))
        self.assertEqual((code, output), (0, {"exported": 2}))
        with destination.open(encoding="utf-8", newline="") as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual(rows[0], {
            "id": "a", "title": title, "author": "Writer, Jr.", "pages": "11", "status": "unread"
        })
        self.assertEqual(rows[1]["status"], "finished")
        self.assertEqual(self.db.read_bytes(), before)

    def test_empty_export_and_destination_failures(self):
        destination = self.root / "empty.csv"
        self.assertEqual(self.call("export", "--csv", str(destination))[1], {"exported": 0})
        self.assertFalse(self.db.exists())
        with destination.open(encoding="utf-8", newline="") as stream:
            self.assertEqual(list(csv.reader(stream)), [["id", "title", "author", "pages", "status"]])

        self.add("a", "Title", "Writer", 1)
        before = self.db.read_bytes()
        code, output, _ = self.call("export", "--csv", str(self.db))
        self.assertEqual(code, 2)
        self.assertIn("error", output)
        self.assertEqual(self.db.read_bytes(), before)

        code, output, _ = self.call("export", "--csv", str(self.root))
        self.assertEqual(code, 2)
        self.assertIn("error", output)
        self.assertTrue(output["error"])
        self.assertEqual(self.db.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
