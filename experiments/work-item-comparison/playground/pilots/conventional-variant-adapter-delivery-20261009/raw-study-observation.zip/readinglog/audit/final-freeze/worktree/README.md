# Readinglog

This is an existing small Python 3.13 standard-library CLI. The baseline supports add and list over a JSON array. Preserve its command names, record shape and default listing semantics while completing BACKLOG.md. No network or external package is needed.

`python -B app.py --db PATH COMMAND ...`

Legacy commands:

- `add --id ID --title TITLE --author AUTHOR --pages INTEGER` creates a record `{id,title,author,pages,status:"unread"}` and returns it. IDs are nonempty and case-sensitive, unique; strip surrounding whitespace on text input, nonempty text required, pages must be a positive integer. Invalid or duplicate input returns `{"error":"..."}` and exit 2 without mutation.
- `list` returns `{"books":[...]}` in insertion order, including every status. Optional `--status unread|finished` filters the results without changing their insertion order; omitting it retains the original behavior.
`finish --id ID` marks the matching case-sensitive ID finished and returns the record. Repeating it succeeds with the same record. Unknown or blank IDs return an error and exit 2 without changing data.

Import UTF-8 CSV with `python -B app.py --db PATH import --csv PATH`. The file must have exactly the header `id,title,author,pages`. The whole file is validated before it is appended: text is stripped and must remain nonempty, pages must be positive integers, and IDs must be unique both in the file and in the database. IDs are case-sensitive. Invalid headers, rows, or duplicates reject the whole import without changing data. A valid header with no rows returns `{"imported":0}`; otherwise the command returns `{"imported":COUNT}` and appends unread records in input order.

`summary` returns one author entry per author, ordered lexically by author name. Each entry reports `books` (all records), `finished` (finished records only), and `pages` (pages across all records). For example: `{"authors":[{"author":"Ada","books":2,"finished":1,"pages":250}]}`.

All successful commands print one JSON object and exit 0. Invalid input and missing IDs print an error object and exit 2 without mutation. A missing database is treated as empty; malformed existing JSON is rejected and left untouched. Successful changes use atomic file replacement, and a later process reads the committed state. Concurrent multiwriter behavior is not guaranteed. Import requires readable UTF-8 CSV and a writable database location.
