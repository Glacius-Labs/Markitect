"""Small JSON-backed Readinglog command line application."""
import argparse
import csv
import json
from pathlib import Path
import sys


def load(path):
    books = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
    if not isinstance(books, list):
        raise ValueError("Invalid database shape")
    seen = set()
    for book in books:
        if not isinstance(book, dict) or set(book) != {"id", "title", "author", "pages", "status"}:
            raise ValueError("Invalid stored record")
        if any(not isinstance(book[key], str) or not book[key].strip() for key in ("id", "title", "author")):
            raise ValueError("Invalid stored text")
        if type(book["pages"]) is not int or book["pages"] <= 0 or book["status"] not in ("unread", "finished"):
            raise ValueError("Invalid stored value")
        if book["id"] in seen:
            raise ValueError("Duplicate stored id")
        seen.add(book["id"])
    return books


def save(path, books):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(books, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", required=True, type=Path)
    actions = parser.add_subparsers(dest="command", required=True)
    listing = actions.add_parser("list")
    listing.add_argument("--status", choices=("unread", "finished"))
    add = actions.add_parser("add")
    for field in ("id", "title", "author", "pages"):
        add.add_argument("--" + field, required=True)
    finish = actions.add_parser("finish")
    finish.add_argument("--id", required=True)
    importer = actions.add_parser("import")
    importer.add_argument("--csv", required=True, type=Path)
    actions.add_parser("summary")
    args = parser.parse_args()
    try:
        books = load(args.db)
        if args.command == "list":
            selected = books if args.status is None else [book for book in books if book["status"] == args.status]
            result = {"books": selected}
        elif args.command == "finish":
            book_id = args.id.strip()
            if not book_id:
                raise ValueError("Book id must not be empty")
            book = next((item for item in books if item["id"] == book_id), None)
            if book is None:
                raise ValueError("Book not found")
            if book["status"] != "finished":
                book["status"] = "finished"
                save(args.db, books)
            result = book
        elif args.command == "import":
            with args.csv.open(encoding="utf-8", newline="") as source:
                reader = csv.DictReader(source)
                fields = ["id", "title", "author", "pages"]
                if reader.fieldnames != fields:
                    raise ValueError("CSV header must be id,title,author,pages")
                imported = []
                seen = {book["id"] for book in books}
                for row_number, row in enumerate(reader, start=2):
                    if None in row or any(row.get(field) is None for field in fields):
                        raise ValueError(f"Invalid CSV columns on row {row_number}")
                    text = {key: row[key].strip() for key in ("id", "title", "author")}
                    pages = int(row["pages"])
                    if not all(text.values()) or pages <= 0:
                        raise ValueError(f"Invalid book on CSV row {row_number}")
                    if text["id"] in seen:
                        raise ValueError(f"Duplicate book id on CSV row {row_number}")
                    seen.add(text["id"])
                    imported.append(dict(text, pages=pages, status="unread"))
            books.extend(imported)
            if imported:
                save(args.db, books)
            result = {"imported": len(imported)}
        elif args.command == "summary":
            authors = {}
            for book in books:
                totals = authors.setdefault(book["author"], {"books": 0, "finished": 0, "pages": 0})
                totals["books"] += 1
                totals["finished"] += book["status"] == "finished"
                totals["pages"] += book["pages"]
            result = {"authors": [dict(author=author, **authors[author]) for author in sorted(authors)]}
        else:
            text = {key: getattr(args, key).strip() for key in ("id", "title", "author")}
            pages = int(args.pages)
            if not all(text.values()) or pages <= 0 or any(book["id"] == text["id"] for book in books):
                raise ValueError("Invalid or duplicate book")
            result = dict(text, pages=pages, status="unread")
            books.append(result)
            save(args.db, books)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except (ValueError, OSError, TypeError, KeyError, csv.Error, UnicodeError) as error:
        print(json.dumps({"error": str(error)}))
        return 2


if __name__ == "__main__":
    sys.exit(main())
