import json
import csv
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


APP = Path(__file__).resolve().parents[1] / "app.py"


class ExistingContract(unittest.TestCase):
    def test_add_list_restart_duplicate_and_invalid_input(self):
        with tempfile.TemporaryDirectory() as folder:
            db = Path(folder) / "books.json"
            def call(*args):
                result = subprocess.run([sys.executable, "-B", str(APP), "--db", str(db), *args], capture_output=True, text=True)
                return result.returncode, json.loads(result.stdout)
            self.assertEqual(call("list"), (0, {"books": []}))
            code, book = call("add", "--id", " a ", "--title", " Example ", "--author", " Writer ", "--pages", "120")
            self.assertEqual(code, 0)
            self.assertEqual(book, {"id": "a", "title": "Example", "author": "Writer", "pages": 120, "status": "unread"})
            self.assertEqual(call("list"), (0, {"books": [book]}))
            before = db.read_bytes()
            self.assertEqual(call("add", "--id", "a", "--title", "Again", "--author", "Writer", "--pages", "1")[0], 2)
            self.assertEqual(call("add", "--id", "b", "--title", "Bad", "--author", "Writer", "--pages", "0")[0], 2)
            self.assertEqual(db.read_bytes(), before)

    def test_finish_is_idempotent_and_status_filter_preserves_order(self):
        with tempfile.TemporaryDirectory() as folder:
            db = Path(folder) / "books.json"
            def call(*args):
                result = subprocess.run([sys.executable, "-B", str(APP), "--db", str(db), *args], capture_output=True, text=True)
                return result.returncode, json.loads(result.stdout)
            first = call("add", "--id", "a", "--title", "First", "--author", "Writer", "--pages", "10")[1]
            second = call("add", "--id", "b", "--title", "Second", "--author", "Writer", "--pages", "20")[1]
            finished = {**first, "status": "finished"}
            self.assertEqual(call("finish", "--id", " a "), (0, finished))
            committed = db.read_bytes()
            self.assertEqual(call("finish", "--id", "a"), (0, finished))
            self.assertEqual(db.read_bytes(), committed)
            self.assertEqual(call("list"), (0, {"books": [finished, second]}))
            self.assertEqual(call("list", "--status", "unread"), (0, {"books": [second]}))
            self.assertEqual(call("list", "--status", "finished"), (0, {"books": [finished]}))
            self.assertEqual(call("finish", "--id", "missing")[0], 2)
            self.assertEqual(call("list", "--status", "finished")[1], {"books": [finished]})

    def test_malformed_database_is_not_overwritten(self):
        with tempfile.TemporaryDirectory() as folder:
            db = Path(folder) / "books.json"
            db.write_text("{invalid", encoding="utf-8")
            before = db.read_bytes()
            result = subprocess.run([sys.executable, "-B", str(APP), "--db", str(db), "finish", "--id", "a"], capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertIn("error", json.loads(result.stdout))
            self.assertEqual(db.read_bytes(), before)

    def test_import_is_atomic_normalized_and_persists_in_input_order(self):
        with tempfile.TemporaryDirectory() as folder:
            db = Path(folder) / "books.json"
            source = Path(folder) / "books.csv"
            def call(*args):
                result = subprocess.run([sys.executable, "-B", str(APP), "--db", str(db), *args], capture_output=True, text=True)
                return result.returncode, json.loads(result.stdout)
            first = call("add", "--id", "existing", "--title", "Existing", "--author", "Writer", "--pages", "10")[1]
            with source.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.writer(handle)
                writer.writerow(["id", "title", "author", "pages"])
                writer.writerow([" b ", " Second ", " Writer ", "20"])
                writer.writerow(["c", "Third, part\nTwo", "Another", "30"])
            self.assertEqual(call("import", "--csv", str(source)), (0, {"imported": 2}))
            expected = [first,
                        {"id": "b", "title": "Second", "author": "Writer", "pages": 20, "status": "unread"},
                        {"id": "c", "title": "Third, part\nTwo", "author": "Another", "pages": 30, "status": "unread"}]
            self.assertEqual(call("list"), (0, {"books": expected}))
            self.assertEqual(call("finish", "--id", "b")[0], 0)
            self.assertEqual(call("summary"), (0, {"authors": [
                {"author": "Another", "books": 1, "finished": 0, "pages": 30},
                {"author": "Writer", "books": 2, "finished": 1, "pages": 30}]}))
            committed = db.read_bytes()
            source.write_text("id,title,author,pages\nd,Fourth,Writer,40\nb,Duplicate,Writer,50\n", encoding="utf-8")
            self.assertEqual(call("import", "--csv", str(source))[0], 2)
            self.assertEqual(db.read_bytes(), committed)
            source.write_text("id,title,author,pages\nd,Fourth,Writer,40\nd,Duplicate,Writer,50\n", encoding="utf-8")
            self.assertEqual(call("import", "--csv", str(source))[0], 2)
            self.assertEqual(db.read_bytes(), committed)

    def test_import_header_and_empty_valid_csv(self):
        with tempfile.TemporaryDirectory() as folder:
            db = Path(folder) / "books.json"
            source = Path(folder) / "books.csv"
            def call(*args):
                result = subprocess.run([sys.executable, "-B", str(APP), "--db", str(db), *args], capture_output=True, text=True)
                return result.returncode, json.loads(result.stdout)
            source.write_text("id,title,author,pages\n", encoding="utf-8")
            self.assertEqual(call("import", "--csv", str(source)), (0, {"imported": 0}))
            before = db.read_bytes() if db.exists() else None
            source.write_text("id,title,author\na,A,Writer\n", encoding="utf-8")
            self.assertEqual(call("import", "--csv", str(source))[0], 2)
            self.assertEqual(db.read_bytes() if db.exists() else None, before)
            for invalid_csv in (
                "id,title,author,pages,extra\na,A,Writer,1,x\n",
                "id,title,author,pages\na,,Writer,1\n",
                "id,title,author,pages\na,A,Writer,0\n",
                "id,title,author,pages\na,A,Writer\n",
                "id,title,author,pages\na,A,Writer,1,x\n",
            ):
                source.write_text(invalid_csv, encoding="utf-8")
                self.assertEqual(call("import", "--csv", str(source))[0], 2)
                self.assertEqual(db.read_bytes() if db.exists() else None, before)

    def test_summary_counts_pages_and_finished_books_by_sorted_author(self):
        with tempfile.TemporaryDirectory() as folder:
            db = Path(folder) / "books.json"
            def call(*args):
                result = subprocess.run([sys.executable, "-B", str(APP), "--db", str(db), *args], capture_output=True, text=True)
                return result.returncode, json.loads(result.stdout)
            call("add", "--id", "1", "--title", "One", "--author", "Zed", "--pages", "15")
            call("add", "--id", "2", "--title", "Two", "--author", "Amy", "--pages", "30")
            call("add", "--id", "3", "--title", "Three", "--author", "Amy", "--pages", "5")
            call("finish", "--id", "3")
            self.assertEqual(call("summary"), (0, {"authors": [
                {"author": "Amy", "books": 2, "finished": 1, "pages": 35},
                {"author": "Zed", "books": 1, "finished": 0, "pages": 15}]}))
            self.assertEqual(call("summary")[1], {"authors": [
                {"author": "Amy", "books": 2, "finished": 1, "pages": 35},
                {"author": "Zed", "books": 1, "finished": 0, "pages": 15}]})


if __name__ == "__main__":
    unittest.main()
