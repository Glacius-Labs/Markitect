"""In-memory evaluator mechanics only. No HTTP, product, server, build or trial."""
import copy
import io
import json
from pathlib import Path
import tempfile
import unittest
from contextlib import redirect_stdout
import holdout_checks as o

class Fixture(o.Client):
    def __init__(self,limit=10,bug=None):
        self.limit=limit;self.bug=bug;self.count=0;self.key_prefix='fixture-'
        self.orders={};self.keys={}
        self.stock={sku:{'sku':sku,'onHand':q,'reserved':0,'available':q} for sku,q in [('WIDGET',10),('GADGET',6)]}

    def request(self,method,route,payload=None,key=None):
        result=self._request(method,route,payload,key)
        return copy.deepcopy(result)

    def _request(self,method,route,payload,key):
        def err(status,code):return status,{'code':code,'message':'fixture error'}
        if method == 'GET':
            if route == '/catalog':return 200,[{'sku':s,'unitPriceCents':p} for s,p in [('WIDGET',1250),('GADGET',775)]]
            if route.startswith('/inventory/'):return 200,self.stock[route.split('/')[-1]]
            oid=route.split('/')[-1]
            return (200,self.orders[oid]) if oid in self.orders else err(404,'not_found')
        if route in ('/orders','/legacy/orders'):
            if not key or not key.strip():return err(400,'validation')
            lines=payload.get('items')
            if not isinstance(lines,list) or not lines:return err(400,'validation')
            if any(type(x.get('quantity')) is not int or x['quantity'] <= 0 for x in lines):
                if self.bug == 'invalid-side-effect':self.stock['GADGET']['reserved']+=1
                return err(400,'other' if self.bug == 'validation-code' else 'validation')
            if any(x.get('sku') not in self.stock for x in lines):return err(400,'unknown_sku')
            counts={}
            for x in lines:counts[x['sku']]=counts.get(x['sku'],0)+x['quantity']
            canonical=sorted(counts.items());keyspace=key+route if self.bug == 'route-namespace' else key
            if self.bug == 'old-replay-limit' and sum(counts.values()) > self.limit:return err(400,'order_limit')
            if keyspace in self.keys:
                oid,old=self.keys[keyspace]
                if canonical == old:return 200,self.orders[oid]
                if self.bug == 'conflict-mutation':self.orders[oid]['totalCents']+=1
                return err(409,'other' if self.bug == 'conflict-code' else 'idempotency_conflict')
            if sum(counts.values()) > self.limit:return err(400,'order_limit')
            if any(self.stock[s]['available'] < q for s,q in canonical):return err(409,'insufficient_stock')
            for s,q in canonical:
                self.stock[s]['reserved']+=q;self.stock[s]['available']-=q
            prices={'WIDGET':1250,'GADGET':775};oid=str(len(self.orders)+1)
            order={'id':oid,'status':'accepted','items':[{'sku':s,'quantity':q,'unitPriceCents':prices[s]} for s,q in canonical],
                   'totalCents':sum(prices[s]*q for s,q in canonical)}
            self.orders[oid]=order;self.keys[keyspace]=(oid,canonical)
            return 201,order
        _,_,oid,action=route.split('/')
        if oid not in self.orders:return err(404,'other' if self.bug == 'unknown-code' else 'not_found')
        order=self.orders[oid];target='cancelled' if action == 'cancel' else 'fulfilled'
        if order['status'] == target:return 200,order
        if order['status'] != 'accepted':
            if self.bug == 'opposite-side-effect':self.stock['WIDGET']['onHand']-=1
            return err(409,'other' if self.bug == 'transition-code' else 'invalid_transition')
        order['status']=target
        for x in order['items']:
            s=x['sku'];q=x['quantity']
            if self.bug != 'reserved-field':self.stock[s]['reserved']-=q
            if action == 'cancel':self.stock[s]['available']+=q
            elif self.bug != 'onhand-field':self.stock[s]['onHand']-=q
        return 200,order

def receipt(candidate='a'*40,process='p4',binary='old'):
    # Synthetic fixture metadata, never accepted as actual study evidence.
    return {'cellId':'fixture-only','databasePath':'fixture-db','databaseInstanceId':'db1',
            'candidateCommit':candidate,'processInstanceId':process,'binarySha256':binary}

class Mechanics(unittest.TestCase):
    def test_order_good(self):o.order_case(Fixture(),4)
    def test_order_conflict_code(self):
        with self.assertRaises(o.ProductViolation):o.order_case(Fixture(bug='conflict-code'),4)
    def test_order_conflict_unchanged(self):
        with self.assertRaises(o.ProductViolation):o.order_case(Fixture(bug='conflict-mutation'),4)
    def test_validation_good(self):o.validation_case(Fixture(),4)
    def test_validation_at_new_limit(self):o.validation_case(Fixture(limit=6),5)
    def test_validation_exact_code(self):
        with self.assertRaises(o.ProductViolation):o.validation_case(Fixture(bug='validation-code'),4)
    def test_validation_no_effect(self):
        with self.assertRaises(o.ProductViolation):o.validation_case(Fixture(bug='invalid-side-effect'),4)
    def test_lifecycle_good(self):o.lifecycle_case(Fixture())
    def test_lifecycle_field_deltas(self):
        for bug in ('reserved-field','onhand-field'):
            with self.subTest(bug=bug),self.assertRaises(o.ProductViolation):o.lifecycle_case(Fixture(bug=bug))
    def test_lifecycle_opposite_preserves(self):
        with self.assertRaises(o.ProductViolation):o.lifecycle_case(Fixture(bug='opposite-side-effect'))
    def test_lifecycle_codes(self):
        for bug in ('unknown-code','transition-code'):
            with self.subTest(bug=bug),self.assertRaises(o.ProductViolation):o.lifecycle_case(Fixture(bug=bug))
    def task5(self,bug=None,persistence_loss=False):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'checkpoint.json';c=Fixture()
            self.assertEqual(o.changed_limit_case(c,'before',path,receipt()),'EVIDENCE_CAPTURED')
            c.limit=6;c.bug=bug
            new=receipt('b'*40,'p5','new')
            self.assertEqual(o.changed_limit_case(c,'after',path,new),'EVIDENCE_CAPTURED')
            if persistence_loss:c.orders={}
            self.assertEqual(o.changed_limit_case(c,'restarted',path,receipt('b'*40,'p5r','new')),'PASS')
    def test_task5_complete_good(self):self.task5()
    def test_task5_old_order_precedes_new_limit(self):
        with self.assertRaises(o.ProductViolation):self.task5('old-replay-limit')
    def test_task5_shared_route_namespace(self):
        with self.assertRaises(o.ProductViolation):self.task5('route-namespace')
    def test_task5_persistence_required(self):
        with self.assertRaises(o.ProductViolation):self.task5(persistence_loss=True)
    def test_restart_good(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'restart.json';c=Fixture()
            self.assertEqual(o.restart_case(c,'before',path,receipt()),'EVIDENCE_CAPTURED')
            self.assertEqual(o.restart_case(c,'after',path,receipt(process='p4r')),'PASS')
    def test_continuity_wrong_cell_db_process_binary(self):
        for field,value in [('cellId','other'),('databasePath','elsewhere'),('databaseInstanceId','other'),
                            ('processInstanceId','p4'),('candidateCommit','a'*40)]:
            new=receipt('b'*40,'p5','new');new[field]=value
            with self.subTest(field=field),self.assertRaises(o.NotRun):o.continuity(receipt(),new)
    def test_restart_same_binary_required(self):
        with self.assertRaises(o.NotRun):o.continuity(receipt(),receipt(process='p4r',binary='different'),True)
    def test_missing_receipt_is_not_run(self):
        self.assertEqual(o.evaluate(lambda:o.read_receipt(None,'a'*40),'durable-state')['status'],'NOT RUN')
    def test_receipt_hash_binding(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);binary=root/'fixture.bin';binary.write_bytes(b'fixture only');trace=root/'trace';trace.write_text('fixture');db=root/'db';db.write_bytes(b'fixture')
            r=receipt();r.update(binaryPath=str(binary),binarySha256=o.sha(binary),operatorTracePath=str(trace),operatorTraceSha256=o.sha(trace),databasePath=str(db.resolve()))
            p=root/'receipt.json';p.write_text(json.dumps(r))
            validation=root/'validation.json';r.update(validationPath=str(validation),operatorId='fixture-operator')
            validation.write_text(json.dumps({'decision':'VERIFIED','validatorId':'fixture-validator',
                'bindings':{k:r[k] for k in ('cellId','candidateCommit','binarySha256','databasePath','databaseInstanceId','processInstanceId','operatorTraceSha256')}}))
            r['validationSha256']=o.sha(validation);p.write_text(json.dumps(r))
            self.assertEqual(o.read_receipt(p,'a'*40)['cellId'],'fixture-only')
            # A real identity mismatch still refuses; normalize the fixture,
            # never relax the evaluator's independent binding criteria.
            wrong=json.loads(validation.read_text());wrong['bindings']['databasePath']=str(root/'other-db')
            validation.write_text(json.dumps(wrong));r['validationSha256']=o.sha(validation);p.write_text(json.dumps(r))
            with self.assertRaises(o.NotRun):o.read_receipt(p,'a'*40)
            wrong['bindings']['databasePath']=str(db.resolve())
            validation.write_text(json.dumps(wrong));r['validationSha256']=o.sha(validation);p.write_text(json.dumps(r))
            binary.write_bytes(b'changed')
            with self.assertRaises(o.NotRun):o.read_receipt(p,'a'*40)
    def test_attribution(self):
        for exc,status,attribution in [(o.ProductViolation('released'),'FAIL','product-invariant'),
                (o.NotRun('unknown'),'NOT RUN','precondition-or-inapplicable'),
                (o.InfrastructureError(),'NOT RUN','infrastructure'),
                (KeyError(),'EVALUATION ERROR','evaluator-harness'),
                (AssertionError(),'EVALUATION ERROR','evaluator-harness')]:
            def action():raise exc
            with self.subTest(exc=type(exc).__name__):
                result=o.evaluate(action,'verification_quality')
                self.assertEqual((result['status'],result['attribution']),(status,attribution))
    def test_invalid_invocation_structured(self):
        out=io.StringIO()
        with redirect_stdout(out):self.assertEqual(o.main([]),1)
        self.assertEqual(json.loads(out.getvalue())['status'],'NOT RUN')
    def test_unchanged_atomic_positive(self):o.base.atomic_case(Fixture(limit=6))
    def test_task5_config_change_may_retain_binary(self):
        o.continuity(receipt(),receipt('b'*40,'p5','old'))
    def test_lifecycle_persistence(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'life.json';c=Fixture()
            self.assertEqual(o.lifecycle_restart_case(c,'before',path,receipt()),'EVIDENCE_CAPTURED')
            self.assertEqual(o.lifecycle_restart_case(c,'after',path,receipt(process='p4r')),'PASS')
            c.orders['1']['status']='accepted'
            with self.assertRaises(o.ProductViolation):o.lifecycle_restart_case(c,'after',path,receipt(process='p4r'))
    def test_malformed_checkpoint_is_evaluation_error(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'bad.json';p.write_text('{')
            result=o.evaluate(lambda:o.restart_case(Fixture(),'after',p,receipt()),'durable-state')
            self.assertEqual(result['status'],'EVALUATION ERROR')

if __name__ == '__main__':unittest.main()
