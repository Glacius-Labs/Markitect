"""Prospective private evaluation; no product process is started by this module.

Continuity receipts are operator evidence, not proof of OS isolation. An actual
study must freeze and independently verify them; offline fixtures never qualify.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.error
import urllib.request
import uuid
import base_checks as base

PUBLIC = Path(__file__).resolve().parents[2] / 'v4-evaluation-correction-20261009/public'
PLAN = Path(__file__).with_name('holdout-plan.json')
CASES = {
    'order-normalization': ('validated-order', 1),
    'validation-boundaries': ('validated-order', 1),
    'multi-sku-atomic-reservation': ('atomic-inventory', 2),
    'idempotent-concurrency': ('atomic-inventory', 2),
    'restart-durability': ('durable-state', 3),
    'terminal-transition-ordering': ('durable-lifecycle', 4),
    'rule-change-entrypoint-parity': ('current-limit-and-compatibility', 5),
}

class ProductViolation(AssertionError):
    """Only explicit assertions of a released product requirement use this."""

class NotRun(Exception):
    pass

class InfrastructureError(Exception):
    pass

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

class Client(base.Client):
    def check(self, label, ok):
        if not ok:
            raise ProductViolation(label)
        self.count += 1

    def request(self, method, route, payload=None, key=None):
        headers = {'Content-Type': 'application/json'}
        if key is not None:
            headers['Idempotency-Key'] = key
        body = json.dumps(payload).encode() if payload is not None else None
        req = urllib.request.Request(self.base + route, data=body, headers=headers, method=method)
        try:
            try:
                response = urllib.request.urlopen(req, timeout=15)
            except urllib.error.HTTPError as exc:
                response = exc
            with response:
                raw = response.read()
                status = response.status
        except (OSError, TimeoutError) as exc:
            raise InfrastructureError('transport-unavailable') from exc
        try:
            value = json.loads(raw)
        except (ValueError, UnicodeError) as exc:
            raise ProductViolation('required-json-response') from exc
        self.check('required-json-shape',isinstance(value,list) if route == '/catalog' else isinstance(value,dict))
        return status, value

    def inventory(self, sku):
        status, value = self.request('GET', '/inventory/' + sku)
        self.check('inventory-readable', status == 200 and isinstance(value, dict))
        self.check('inventory-fields', all(type(value.get(k)) is int for k in ('onHand', 'reserved', 'available')))
        return value

def error(c, observation, status, code, label):
    actual, body = observation
    c.check(label, actual == status and isinstance(body, dict) and body.get('code') == code
            and isinstance(body.get('message'), str) and bool(body['message'].strip()))

def state(c):
    return {sku: c.inventory(sku) for sku in ('WIDGET', 'GADGET')}

def fetch(c, oid):
    status, value = c.request('GET', '/orders/' + str(oid))
    c.check('order-readable', status == 200 and isinstance(value, dict))
    return value

def accepted(c, result, lines, status=201):
    actual, order = result
    c.check('accepted-order-shape', actual == status and isinstance(order, dict)
            and bool(order.get('id')) and order.get('status') == 'accepted')
    counts = {}
    prices = {'WIDGET': 1250, 'GADGET': 775}
    for line in lines:
        counts[line['sku']] = counts.get(line['sku'], 0) + line['quantity']
    expected = [{'sku': sku, 'quantity': quantity, 'unitPriceCents': prices[sku]}
                for sku, quantity in sorted(counts.items())]
    c.check('normalized-priced-items', order.get('items') == expected)
    c.check('integer-cent-total', type(order.get('totalCents')) is int
            and order['totalCents'] == sum(x['quantity'] * x['unitPriceCents'] for x in expected))
    return order

def order_case(c, through):
    lines = [{'sku':'GADGET','quantity':2}, {'sku':'WIDGET','quantity':1}, {'sku':'GADGET','quantity':1}]
    key = c.key_prefix + 'same'
    first = accepted(c, c.create(lines, key), lines)
    before = state(c) if through >= 2 else None
    canonical = [{'sku':'GADGET','quantity':3}, {'sku':'WIDGET','quantity':1}]
    status, retry = c.create(canonical, key)
    c.check('canonical-retry-same-result', status == 200 and retry == first)
    error(c, c.create([{'sku':'GADGET','quantity':2}], key), 409, 'idempotency_conflict', 'exact-key-conflict')
    c.check('conflict-original-unchanged', fetch(c, first['id']) == first)
    if before is not None:
        c.check('retry-conflict-inventory-unchanged', state(c) == before)
    error(c, c.request('GET', '/orders/' + uuid.uuid4().hex), 404, 'not_found', 'unknown-order')

def validation_case(c, through):
    limit = 6 if through >= 5 else 10
    lines = [{'sku':'WIDGET','quantity':limit}]
    first = accepted(c, c.create(lines, c.key_prefix+'boundary'), lines)
    before = state(c) if through >= 2 else None
    probes = [
        ({'items':[{'sku':'WIDGET','quantity':limit+1}]}, 'over', 'order_limit'),
        ({'items':[{'sku':'GADGET','quantity':1.25}]}, 'fraction', 'validation'),
        ({'items':[{'sku':'GADGET','quantity':0}]}, 'zero', 'validation'),
        ({'items':[{'sku':'GADGET','quantity':-1}]}, 'negative', 'validation'),
        ({'items':[{'sku':'GADGET','quantity':'1'}]}, 'string', 'validation'),
        ({'items':[]}, 'empty', 'validation'), ({}, 'missing', 'validation'),
        ({'items':[{'sku':'UNKNOWN','quantity':1}]}, 'unknown', 'unknown_sku'),
    ]
    rejected_keys = []
    for payload, suffix, code in probes:
        key = c.key_prefix + suffix
        error(c, c.request('POST', '/orders', payload, key), 400, code, 'declared-validation-code')
        rejected_keys.append(key)
        c.check('rejection-preserves-original', fetch(c, first['id']) == first)
        if before is not None:
            c.check('rejection-preserves-inventory', state(c) == before)
    for key in (None, '   '):
        error(c, c.request('POST','/orders',{'items':[{'sku':'GADGET','quantity':1}]},key),
              400,'validation','missing-blank-key')
        if before is not None:
            c.check('bad-key-preserves-inventory', state(c) == before)
    # Public API has no list-orders route: inspect all observable state and prove
    # rejected keys were not committed. Free boundary stock only after checking.
    if through >= 4:
        lifecycle_order(c, first, 'cancel')
    if through == 1 or through >= 4:
        for key in rejected_keys:
            good = [{'sku':'GADGET','quantity':1}]
            made = accepted(c, c.create(good,key),good)
            if through >= 4:
                lifecycle_order(c,made,'cancel')

def lifecycle_order(c, order, action):
    oid = order['id']
    before = state(c)
    quantities = {x['sku']:x['quantity'] for x in order['items']}
    status, terminal = c.request('POST',f'/orders/{oid}/{action}',{})
    expected_status = 'cancelled' if action == 'cancel' else 'fulfilled'
    expected_order = dict(order, status=expected_status)
    c.check('terminal-order-result',status == 200 and terminal == expected_order)
    after = state(c)
    for sku, original in before.items():
        q = quantities.get(sku,0)
        expected = dict(original)
        expected['reserved'] -= q
        if action == 'cancel':
            expected['available'] += q
        else:
            expected['onHand'] -= q
        c.check('individual-inventory-transition', after[sku] == expected)
    c.check('terminal-readback',fetch(c,oid) == expected_order)
    status, repeated = c.request('POST',f'/orders/{oid}/{action}',{})
    c.check('repeat-terminal-same-order',status == 200 and repeated == expected_order)
    c.check('repeat-terminal-no-effect',state(c) == after and fetch(c,oid) == expected_order)
    opposite = 'fulfill' if action == 'cancel' else 'cancel'
    error(c,c.request('POST',f'/orders/{oid}/{opposite}',{}),409,'invalid_transition','opposite-exact-code')
    c.check('opposite-preserves-order-and-stock',fetch(c,oid) == expected_order and state(c) == after)
    return expected_order

def lifecycle_case(c):
    terminals=[]
    for sku, q, action in [('WIDGET',2,'cancel'),('GADGET',1,'fulfill')]:
        lines=[{'sku':sku,'quantity':q}]
        terminals.append(lifecycle_order(c,accepted(c,c.create(lines),lines),action))
    before=state(c)
    for action in ('cancel','fulfill'):
        error(c,c.request('POST',f'/orders/{uuid.uuid4().hex}/{action}',{}),404,'not_found','unknown-transition')
        c.check('unknown-transition-preserves-inventory',state(c) == before)
    return terminals

def lifecycle_restart_case(c,phase,checkpoint,receipt):
    if phase == 'before':
        terminals=lifecycle_case(c)
        save(checkpoint,{'receipt':receipt,'terminals':terminals,'inventory':state(c)})
        return 'EVIDENCE_CAPTURED'
    s=load(checkpoint)
    continuity(s['receipt'],receipt,same_candidate=True)
    c.check('terminal-state-persisted',state(c) == s['inventory'])
    for order in s['terminals']:
        c.check('terminal-order-persisted',fetch(c,order['id']) == order)
        action='cancel' if order['status'] == 'cancelled' else 'fulfill'
        status,repeated=c.request('POST',f"/orders/{order['id']}/{action}",{})
        c.check('persisted-terminal-repeat',status == 200 and repeated == order and state(c) == s['inventory'])
    return 'PASS'

def read_receipt(path, candidate):
    """Require actual artifacts and trace digests, never synthesize a prior version."""
    if not path:
        raise NotRun('operator-receipt-missing')
    p=Path(path)
    if not p.is_file():
        raise NotRun('operator-receipt-unavailable')
    try:
        r=json.loads(p.read_text(encoding='utf-8-sig'))
    except (ValueError,UnicodeError) as exc:
        raise NotRun('operator-receipt-invalid') from exc
    fields=('cellId','databasePath','databaseInstanceId','processInstanceId',
            'candidateCommit','binaryPath','binarySha256','operatorTracePath','operatorTraceSha256',
            'validationPath','validationSha256','operatorId')
    if not isinstance(r,dict) or any(not isinstance(r.get(k),str) or not r[k].strip() for k in fields):
        raise NotRun('operator-receipt-incomplete')
    if r['candidateCommit'] != candidate:
        raise NotRun('operator-candidate-binding-mismatch')
    for pathfield,hashfield in [('binaryPath','binarySha256'),('operatorTracePath','operatorTraceSha256')]:
        artifact=Path(r[pathfield])
        if not artifact.is_absolute() or not artifact.is_file() or sha(artifact) != r[hashfield]:
            raise NotRun('operator-artifact-binding-mismatch')
    db=Path(r['databasePath'])
    if not db.is_absolute() or not db.is_file():
        raise NotRun('operator-database-unavailable')
    r['databasePath']=str(db.resolve())
    verification=Path(r['validationPath'])
    if not verification.is_absolute() or not verification.is_file() or sha(verification) != r['validationSha256']:
        raise NotRun('independent-operator-validation-missing')
    try:
        v=json.loads(verification.read_text(encoding='utf-8-sig'))
    except (ValueError,UnicodeError) as exc:
        raise NotRun('independent-operator-validation-invalid') from exc
    bound=('cellId','candidateCommit','binarySha256','databasePath','databaseInstanceId',
           'processInstanceId','operatorTraceSha256')
    if not isinstance(v,dict) or v.get('decision') != 'VERIFIED' or not v.get('validatorId') \
            or v['validatorId'] == r['operatorId'] or not isinstance(v.get('bindings'),dict) \
            or any(v['bindings'].get(k) != r[k] for k in bound):
        raise NotRun('independent-operator-validation-not-established')
    r['receiptSha256']=sha(p)
    return r

def continuity(old,new,same_candidate=False):
    for field in ('cellId','databasePath','databaseInstanceId'):
        if old[field] != new[field]:
            raise NotRun('operator-continuity-not-established')
    if old['processInstanceId'] == new['processInstanceId']:
        raise NotRun('distinct-process-restart-not-established')
    if same_candidate and any(old[k] != new[k] for k in ('candidateCommit','binarySha256')):
        raise NotRun('restart-candidate-changed')
    if not same_candidate and old['candidateCommit'] == new['candidateCommit']:
        raise NotRun('actual-prior-stage-candidate-not-established')

def save(path,value):
    if not path:
        raise NotRun('checkpoint-path-missing')
    Path(path).write_text(json.dumps(value,sort_keys=True),encoding='utf-8')

def load(path):
    if not path or not Path(path).is_file():
        raise NotRun('checkpoint-unavailable')
    return json.loads(Path(path).read_text(encoding='utf-8'))

def restart_case(c,phase,checkpoint,receipt):
    if phase == 'before':
        lines=[{'sku':'WIDGET','quantity':3}]; key=c.key_prefix+'restart'
        made=accepted(c,c.create(lines,key),lines)
        save(checkpoint,{'receipt':receipt,'order':made,'key':key,'lines':lines,
                         'catalog':list(c.request('GET','/catalog')),'inventory':state(c)})
        return 'EVIDENCE_CAPTURED'
    s=load(checkpoint)
    continuity(s['receipt'],receipt,same_candidate=True)
    c.check('restart-logical-state',fetch(c,s['order']['id']) == s['order']
            and state(c) == s['inventory'] and list(c.request('GET','/catalog')) == s['catalog'])
    status,replay=c.create(s['lines'],s['key'])
    c.check('restart-replay',status == 200 and replay == s['order'] and state(c) == s['inventory'])
    return 'PASS'

def changed_limit_case(c,phase,checkpoint,receipt):
    if phase == 'before':
        lines=[{'sku':'WIDGET','quantity':7}]; key=c.key_prefix+'prior'
        made=accepted(c,c.create(lines,key),lines)
        save(checkpoint,{'phase':'prior-task4','priorReceipt':receipt,'order':made,
                         'key':key,'lines':lines,'inventory':state(c)})
        return 'EVIDENCE_CAPTURED'
    s=load(checkpoint)
    if phase == 'after':
        if s['phase'] != 'prior-task4':
            raise NotRun('task4-checkpoint-required')
        continuity(s['priorReceipt'],receipt)
        c.check('old-order-readable',fetch(c,s['order']['id']) == s['order'] and state(c) == s['inventory'])
        status,replay=c.create(s['lines'],s['key'])
        c.check('old-limit-canonical-replay',status == 200 and replay == s['order'] and state(c) == s['inventory'])
        error(c,c.create([{'sku':'WIDGET','quantity':1}],s['key']),409,'idempotency_conflict','old-key-conflict')
        c.check('old-conflict-preserves-state',fetch(c,s['order']['id']) == s['order'] and state(c) == s['inventory'])
        s['oldTerminal']=lifecycle_order(c,s['order'],'cancel')
        # Same key across both routes proves a shared idempotency namespace.
        records=[]
        for route,other in [('/orders','/legacy/orders'),('/legacy/orders','/orders')]:
            before=state(c); lines=[{'sku':'WIDGET','quantity':2}]; key=c.key_prefix+uuid.uuid4().hex
            made=accepted(c,c.create(lines,key,route),lines)
            after=state(c)
            for sku in before:
                expected=dict(before[sku]);q=2 if sku == 'WIDGET' else 0
                expected['reserved']+=q;expected['available']-=q
                c.check('route-exact-reservation',after[sku] == expected)
            status,retry=c.create(lines,key,other)
            c.check('cross-route-canonical-retry',status == 200 and retry == made)
            error(c,c.create([{'sku':'WIDGET','quantity':1}],key,other),409,'idempotency_conflict','cross-route-conflict')
            c.check('cross-route-preserves-state',state(c) == after and fetch(c,made['id']) == made)
            records.append({'order':made,'key':key,'lines':lines,'route':route,'other':other})
            before=state(c)
            error(c,c.create([{'sku':'GADGET','quantity':7}],route=route),400,'order_limit','new-limit-exact-code')
            c.check('invalid-route-all-sku-no-effect',state(c) == before)
            boundary=[{'sku':'GADGET','quantity':6}]
            six=accepted(c,c.create(boundary,route=route),boundary)
            lifecycle_order(c,six,'cancel')
        normalized=[{k:r['order'].get(k) for k in ('status','items','totalCents')} for r in records]
        c.check('valid-route-result-parity',normalized[0] == normalized[1])
        s.update(phase='task5-before-restart',task5Receipt=receipt,routeRecords=records,inventory=state(c))
        save(checkpoint,s)
        return 'EVIDENCE_CAPTURED'
    if s['phase'] != 'task5-before-restart':
        raise NotRun('task5-before-restart-checkpoint-required')
    continuity(s['task5Receipt'],receipt,same_candidate=True)
    c.check('task5-persisted-inventory-and-old-order',state(c) == s['inventory']
            and fetch(c,s['order']['id']) == s['oldTerminal'])
    for r in s['routeRecords']:
        c.check('both-routes-persisted',fetch(c,r['order']['id']) == r['order'])
        status,replay=c.create(r['lines'],r['key'],r['other'])
        c.check('both-routes-persisted-retry',status == 200 and replay == r['order'] and state(c) == s['inventory'])
    return 'PASS'

def evaluate(action,requirement):
    try:
        status=action() or 'PASS'
        return {'status':status,'attribution':'none','requirementId':requirement}
    except ProductViolation as exc:
        return {'status':'FAIL','attribution':'product-invariant','requirementId':requirement,'assertionId':str(exc)}
    except NotRun as exc:
        return {'status':'NOT RUN','attribution':'precondition-or-inapplicable','requirementId':requirement,'reasonId':str(exc)}
    except (InfrastructureError,OSError) as exc:
        return {'status':'NOT RUN','attribution':'infrastructure','requirementId':requirement,'failureClass':type(exc).__name__}
    except Exception as exc:
        return {'status':'EVALUATION ERROR','attribution':'evaluator-harness','requirementId':requirement,'failureClass':type(exc).__name__}

class Parser(argparse.ArgumentParser):
    def error(self,message):
        raise NotRun('invalid-invocation')

def main(argv=None):
    parser=Parser(description=__doc__)
    for name in ('base-url','candidate-sha','candidate-repository','condition','case'):
        parser.add_argument('--'+name,required=True)
    parser.add_argument('--through-task',type=int,required=True)
    parser.add_argument('--candidate-frozen',action='store_true')
    parser.add_argument('--fresh-db-confirmed',action='store_true')
    parser.add_argument('--phase',choices=('before','after','restarted'),default='before')
    parser.add_argument('--checkpoint')
    parser.add_argument('--operator-receipt')
    metadata={}
    def run():
        args=parser.parse_args(argv)
        if args.case not in CASES or args.condition not in ('greenfield','brownfield'):
            raise NotRun('unknown-case-or-condition')
        requirement,cutoff=CASES[args.case]
        metadata.update(requirementId=requirement,candidateCommit=args.candidate_sha,condition=args.condition,throughTask=args.through_task)
        # Task5 before phase intentionally executes genuine Task4, all others
        # require the released cutoff. No alternative old version is generated.
        required=4 if args.case == 'rule-change-entrypoint-parity' and args.phase == 'before' else cutoff
        if args.through_task < required or args.through_task > 6 or not args.candidate_frozen:
            raise NotRun('cutoff-or-freeze-not-established')
        if args.case == 'rule-change-entrypoint-parity' and args.phase == 'before' and args.through_task != 4:
            raise NotRun('actual-task4-required')
        if args.phase == 'before' and not args.fresh_db_confirmed:
            raise NotRun('fresh-db-not-established')
        if args.phase != 'before' and args.case not in ('restart-durability','terminal-transition-ordering','rule-change-entrypoint-parity'):
            raise NotRun('phase-not-applicable')
        if args.case in ('restart-durability','terminal-transition-ordering') and args.phase == 'restarted':
            raise NotRun('phase-not-applicable')
        repo=Path(args.candidate_repository)
        if not repo.is_absolute() or not repo.is_dir():
            raise NotRun('candidate-repository-unavailable')
        try:
            actual=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
            dirty=subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip()
        except subprocess.CalledProcessError as exc:
            raise NotRun('candidate-repository-not-verifiable') from exc
        if actual != args.candidate_sha or dirty:
            raise NotRun('candidate-not-clean-and-bound')
        receipt=None
        if args.case in ('restart-durability','terminal-transition-ordering','rule-change-entrypoint-parity'):
            receipt=read_receipt(args.operator_receipt,args.candidate_sha)
        c=Client(args.base_url)
        if args.case == 'order-normalization': return order_case(c,args.through_task)
        if args.case == 'validation-boundaries': return validation_case(c,args.through_task)
        if args.case == 'restart-durability': return restart_case(c,args.phase,args.checkpoint,receipt)
        if args.case == 'rule-change-entrypoint-parity': return changed_limit_case(c,args.phase,args.checkpoint,receipt)
        if args.case == 'terminal-transition-ordering': return lifecycle_restart_case(c,args.phase,args.checkpoint,receipt)
        if args.case == 'multi-sku-atomic-reservation': return base.atomic_case(c)
        return base.concurrency_case(c)
    result=evaluate(run,'unresolved')
    result.update(metadata)
    result.update(schemaVersion=2,caseDigest=sha(PLAN),productQualityEvidence='actual-run-only; fixtures do not qualify')
    print(json.dumps(result,sort_keys=True))
    return 0 if result['status'] in ('PASS','EVIDENCE_CAPTURED') else 1

if __name__ == '__main__':
    raise SystemExit(main())
