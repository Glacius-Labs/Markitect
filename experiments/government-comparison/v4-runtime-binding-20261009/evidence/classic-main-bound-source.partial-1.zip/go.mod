module github.com/Glacius-Labs/Markitect

go 1.27.1

require go.yaml.in/yaml/v3 v3.0.5
