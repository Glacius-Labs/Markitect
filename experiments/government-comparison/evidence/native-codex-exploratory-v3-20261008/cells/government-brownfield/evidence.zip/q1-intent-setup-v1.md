# Q1 intent replay — Government Brownfield Task 1

Recorded: 2026-10-08T22:03:58Z, before implementation.
Cell: government-brownfield-v3-20261008, Task 1. Starting HEAD: `5d21ef02cd9d5485c26bc4053a35c61ad33024c1` on `codex/native-v3-government-brownfield`.

## Released sources and cutoff

- `stage-1/01-create-order.md`, SHA-256 `bf5c1e5bf148245bfbc8212e2ad90b7369d8a1a03765258eda078f1ec87075a9` (Task 1 cutoff).
- `stage-1/brief.md`, SHA-256 `4692ec98bbf8f8a140020e88182a62504689e6e6df5aa80af7c6783cdacb13c8` (version 0.2).
- `stage-1/architecture.md`, SHA-256 `7459d9514358d1448c2353e0c0bf3d24d11a7eaf84b67c695724c88d20023700` (version 0.3).
- `stage-1/brownfield-provenance.md`, SHA-256 `155f6f736adf4d48b71074f74a9221d9f8ac796a938b5b8b0650f741d59eb548`.
- `stage-1/checks.py`, SHA-256 `fc96859ce7cc71426ed774f3ff5d88a45adcf016d2250c259287d1da628ac0cc`.

These are the only current stage requirements and Brownfield evidence considered; no future task card was read.

## Stated intent, terms, rules, priorities, and freedoms

Task 1 requires `/health`, `/catalog`, `POST /orders`, and `GET /orders/{id}`. The service uses .NET 10 and local SQLite from the runner's bind/database settings; JSON is camelCase; money is integer euro cents. Catalog prices are WIDGET 1250 and GADGET 775. Orders require nonempty items and a nonblank `Idempotency-Key`; quantities are positive integers with combined sum at most 10. Duplicate SKU lines combine and canonical items sort by SKU. Missing/empty items, absent/blank key, and invalid quantities yield 400 `validation`; unknown SKU yields 400 `unknown_sku`; sum above 10 yields 400 `order_limit`. Error messages are nonempty. New valid orders return 201 and status `accepted` with ID, normalized items and exact total; equal key plus equal canonical request returns 200 and same ID; same key with different canonical request returns 409 `idempotency_conflict` without changing original; known ID reads back the same order and unknown ID returns 404 `not_found`.

Brownfield explicitly requires preserving useful behavior in the supplied candidate, including `POST /legacy/orders`. Provenance records the initial working inventory route and its current zero-reservation semantics, existing order validation/idempotency/persistence, local SQLite configuration, and no reservation/lifecycle behavior. The task does not add stock reservation or later lifecycle rules. The architecture allows minimal APIs/controllers, ADO.NET/direct SQL, and one or a few projects; it does not require DDD, Clean Architecture, repositories, mediator, ORM, containers, cloud, or paid services. Keep the service runnable with concise build/run/check instructions. Fixed tool pins are in the common architecture and inherited Brownfield fixture.

## Assumptions

- Preserve the initial `GET /inventory/{sku}` response and `POST /legacy/orders` behavior because Brownfield provenance states they are existing behavior and the task says to preserve working behavior.
- Exact error wording, ID format, table layout, and project count are not prescribed; preserve existing compatible choices where practical.
- Health response body is not constrained beyond HTTP 200, so retain existing body.
- Unknown questions below do not block behavior specified by this release.

## Behavior-changing questions

- None that block Task 1. The published contract gives required statuses, codes, values, canonicalization and Brownfield preservation; it leaves only implementation details and exact error prose open. No coordinator clarification requested.

Q1 artifact frozen before implementation; no human acceptance is implied.
