# Q1 intent replay — Government Brownfield Task 1

Recorded: 2026-10-08T22:11Z (before implementation edits)

## Released sources and cutoff

- Common brief v0.2: `inputs/stage-1/brief.md`, SHA-256 `4692ec98bbf8f8a140020e88182a62504689e6e6df5aa80af7c6783cdacb13c8`.
- Shared architecture v0.3: `inputs/stage-1/architecture.md`, SHA-256 `7459d9514358d1448c2353e0c0bf3d24d11a7eaf84b67c695724c88d20023700`.
- Current task card `01-create-order.md`, SHA-256 `bf5c1e5bf148245bfbc8212e2ad90b7369d8a1a03765258eda078f1ec87075a9`.
- Brownfield provenance packet `brownfield-provenance.md`, SHA-256 `155f6f736adf4d48b71074f74a9221d9f8ac796a938b5b8b0650f741d59eb548`.
- Current public checks `checks.py`, SHA-256 `fc96859ce7cc71426ed774f3ff5d88a45adcf016d2250c259287d1da628ac0cc`.

The cutoff is Task 1 only. I do not infer behavior from later task material.

## Stated intent and rules

Implement and validate `GET /health`, `GET /catalog`, `POST /orders`, and `GET /orders/{id}` on the existing .NET 10 / local SQLite service. Keep exact integer-cent prices and totals, canonicalize duplicate SKU lines and sort by SKU, require a nonblank idempotency key, reject empty/missing items and invalid/non-positive/non-integer quantities with HTTP 400 `validation`, unknown SKUs with 400 `unknown_sku`, and combined quantity over 10 with 400 `order_limit`. New accepted orders return 201, same-key canonical retries return 200 with the same ID, changed requests under the same key return 409 `idempotency_conflict`, and unknown order IDs return 404 `not_found`; error messages are non-empty. Preserve useful existing Brownfield behavior, including the supplied compatibility route. The service remains runnable with concise build/run/check guidance.

The Brownfield packet says the existing `/legacy/orders` route shares order behavior and must remain understandable; initial inventory behavior is read-only, with no stock reservation or lifecycle behavior at this cutoff. It describes the fixture as purpose-built and does not assert production history.

## Freedoms, assumptions, and questions

The published architecture permits minimal APIs or controllers, direct SQL or ADO.NET, one or a few projects, and proportionate abstractions; it does not require DDD, Clean Architecture, repositories, mediators, ORMs, containers, cloud, or paid services. Assumption: existing compatible route and inventory behavior are preserved byte-for-byte in behavior unless a Task 1 requirement requires a change. Open behavior-changing questions: none found in the released inputs. Existing freedoms (including implementation structure) do not block work.