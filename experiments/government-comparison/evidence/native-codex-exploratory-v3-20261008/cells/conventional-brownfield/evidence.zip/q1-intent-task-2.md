# Q1 intent replay — conventional brownfield, Task 2

Recorded: 2026-10-08 22:09:41 UTC (before Task 2 implementation changes)
Cutoff: the currently released Task 2 card, `inputs/stage-2/02-reserve-stock.md`; no later card is in scope.

## Released sources

- Task 2 `inputs/stage-2/02-reserve-stock.md`, SHA-256 `e2b2afde36c28ac8fed8fff89325c40d69bb075056cf02809f908dfaf14858a6`
- Shared brief `inputs/stage-2/brief.md` v0.2, SHA-256 `4692ec98bbf8f8a140020e88182a62504689e6e6df5aa80af7c6783cdacb13c8`
- Shared architecture `inputs/stage-2/architecture.md` v0.3, SHA-256 `7459d9514358d1448c2353e0c0bf3d24d11a7eaf84b67c695724c88d20023700`
- Brownfield provenance `inputs/stage-2/brownfield-provenance.md`, SHA-256 `155f6f736adf4d48b71074f74a9221d9f8ac796a938b5b8b0650f741d59eb548`
- Current public checks `inputs/stage-2/checks.py`, SHA-256 `cd7a930f542ec2364609de1b0ad11ceb286d0219d113b57f17c8fbfc9554585b`
- Stage 1 card `inputs/stage-2/01-create-order.md`, SHA-256 `bf5c1e5bf148245bfbc8212e2ad90b7369d8a1a03765258eda078f1ec87075a9`; Stage 1 is preserved as prior released behavior.

## Stated behavior and constraints

Task 2 adds `GET /inventory/{sku}` with `sku`, `onHand`, `reserved`, and `available = onHand - reserved`; initial stock is WIDGET 10 and GADGET 6. Unknown SKUs return 404 `unknown_sku`. Successful order creation reserves every requested unit atomically while the order remains `accepted`. If any requested quantity is unavailable, return 409 `insufficient_stock`, without an accepted order or any reservation changes. Concurrent requests may not reserve the same unit twice. Same-key, same-canonical-request retries return 200 with the same order and no additional reservation; a different canonical request returns 409 `idempotency_conflict` without state changes. All Task 1 status codes, errors, totals, and Brownfield behavior remain. The public checks require multi-SKU all-or-nothing handling and competing requests at a stock boundary.

The Brownfield source has existing `POST /legacy/orders`, which shares its order handler, and existing inventory reads backed by `on_hand`; both are compatibility behavior. Task 1 has already established order validation, canonicalization, idempotency, and error envelopes, including malformed quantity validation. The implementation should preserve these and exact package/toolchain pins. The architecture permits a proportionate direct-SQL implementation in the existing one-process SQLite service.

## Assumptions

- The legacy alias continues to use the shared order path and therefore reserves stock under the same behavior as `/orders`.
- Existing databases created before the new `reserved` column should be upgraded with zero reserved stock, preserving existing on-hand counts.
- Reservation and accepted-order/idempotency writes must be one SQLite transaction; a failed multi-item reservation rolls back all earlier stock updates.
- Reservation release/cancellation/fulfillment is outside this task because no such behavior is released here.

## Behavior-changing questions

- The released inputs define no missing decision that blocks Task 2. Internal transaction/schema design is free. For a request containing both an unavailable known SKU and an unknown SKU, the card does not state precedence; preserve the existing unknown-SKU validation by checking SKU existence before reserving any stock.
