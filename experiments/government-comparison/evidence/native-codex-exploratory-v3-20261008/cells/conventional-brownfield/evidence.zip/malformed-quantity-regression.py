import json
import urllib.error
import urllib.request

url = 'http://127.0.0.1:5188/orders'
for label, raw in [('string', '{"items":[{"sku":"WIDGET","quantity":"bad"}]}'), ('null', '{"items":[{"sku":"WIDGET","quantity":null}]}'), ('overflow-exponent', '{"items":[{"sku":"WIDGET","quantity":1e999}]}')]:
    request = urllib.request.Request(url, data=raw.encode(), headers={'Content-Type': 'application/json', 'Idempotency-Key': 'repair-' + label}, method='POST')
    try:
        response = urllib.request.urlopen(request, timeout=5)
    except urllib.error.HTTPError as exc:
        response = exc
    with response:
        status = response.status
        body = json.loads(response.read())
    assert status == 400 and body.get('code') == 'validation' and body.get('message'), (label, status, body)
    print(json.dumps({'case': label, 'status': status, 'body': body}))
