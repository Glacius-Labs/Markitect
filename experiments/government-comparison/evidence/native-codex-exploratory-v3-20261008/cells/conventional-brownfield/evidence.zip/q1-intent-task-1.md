# Q1 intent replay — conventional brownfield, Task 1

Recorded: 2026-10-08 22:00:36 UTC (before any implementation changes)
Cutoff: the currently released Task 1 card, `01-create-order.md`; no later task card is in scope.

## Released sources

- `inputs/stage-1/brief.md` v0.2, SHA-256 `4692ec98bbf8f8a140020e88182a62504689e6e6df5aa80af7c6783cdacb13c8`
- `inputs/stage-1/architecture.md` v0.3, SHA-256 `7459d9514358d1448c2353e0c0bf3d24d11a7eaf84b67c695724c88d20023700`
- `inputs/stage-1/01-create-order.md`, SHA-256 `bf5c1e5bf148245bfbc8212e2ad90b7369d8a1a03765258eda078f1ec87075a9`
- Brownfield evidence `inputs/stage-1/brownfield-provenance.md`, SHA-256 `155f6f736adf4d48b71074f74a9221d9f8ac796a938b5b8b0650f741d59eb548`
- Public checks `inputs/stage-1/checks.py`, SHA-256 `fc96859ce7cc71426ed774f3ff5d88a45adcf016d2250c259287d1da628ac0cc`
- Common setup/method: `inputs/q1-intent-setup-v1.md`, `inputs/method.md`, `inputs/oldschool-workflow-brief-20261008.md`.

## Stated behavior and constraints

The common brief and Task 1 require a .NET 10 HTTP service using local SQLite. Task 1 requires `/health`, `/catalog`, `POST /orders`, and `GET /orders/{id}`; catalog prices are fixed integer euro cents. New valid orders are `accepted`, with normalized item lines, exact integer-cent totals and an ID. The combined quantity limit is 10 inclusive. Requests require nonempty items, a nonblank `Idempotency-Key`, positive integer quantities, and known case-sensitive SKUs. Validation, unknown SKU, and over-limit errors map respectively to HTTP 400 with `validation`, `unknown_sku`, and `order_limit`; errors have useful nonempty messages. A repeated key with an equivalent canonical request (duplicate lines combined and lines sorted by SKU) returns the original order with 200. Reusing the key for different content returns 409 `idempotency_conflict` and leaves the first result unchanged. Unknown order reads return 404 `not_found`.

Brownfield provenance says the supplied service already implements health/catalog/inventory, order create/read and `POST /legacy/orders`, with SQLite persistence and idempotency; its legacy route uses the existing order behavior. Task 1 explicitly says to preserve working behavior in the supplied candidate. The known starting gap is no stock reservation or available-stock rejection. The legacy route is useful existing behavior and must remain understandable/preserved. This task does not activate later inventory reservation/lifecycle behavior.

The architecture allows minimal APIs or controllers, direct SQL or ADO.NET, one or a small number of projects, and proportionate abstractions. It does not require DDD, Clean Architecture, repository pattern, mediator, ORM, container, cloud service, or paid service. Toolchain and package versions are pinned in the supplied fixture; do not change them for this task. The public working-method brief calls for scoped observable criteria, exploration of relevant instructions/Git/entrypoints/data flow/callers, a complete bounded implementation, risk-based checks, independent review where useful, drift/error reproduction and SHA-bound handoff evidence.

## Assumptions

- The Brownfield fixture's stated existing valid route behavior is part of the compatibility contract; in particular `/legacy/orders` continues to accept orders under the same validation/idempotency behavior.
- Existing inventory read behavior remains unchanged and accepted orders do not reserve or decrement stock during this task, because provenance explicitly marks reservation as a later concern.
- Existing order API wire shapes should remain compatible unless Task 1 explicitly changes them; the active changes are the initial brief's stated requirements and explicit Task 1 errors/limit.

## Behavior-changing questions

- The released sources define no additional behavior-changing decision needed for Task 1. They expressly leave internal architecture and ID/schema choices open. No clarification is requested.
