# Q1 intent replay — Task 1

Recorded: 2026-10-08T22:03:06Z (before implementation changes)
Cell: classic-brownfield-v3-20261008; branch `codex/native-v3-classic-brownfield`; starting source SHA `5d21ef02cd9d5485c26bc4053a35c61ad33024c1`.

## Released references and cutoff

The bound cutoff is Task 1 only. I read the common service brief v0.2 (SHA-256 `4692ec98bbf8f8a140020e88182a62504689e6e6df5aa80af7c6783cdacb13c8`), shared architecture note v0.3 (`7459d9514358d1448c2353e0c0bf3d24d11a7eaf84b67c695724c88d20023700`), Task 1 card (`bf5c1e5bf148245bfbc8212e2ad90b7369d8a1a03765258eda078f1ec87075a9`), and Brownfield provenance packet (`155f6f736adf4d48b71074f74a9221d9f8ac796a938b5b8b0650f741d59eb548`). The released public check source is `checks.py` (`fc96859ce7cc71426ed774f3ff5d88a45adcf016d2250c259287d1da628ac0cc`). The source tree starts at the SHA above. No later task card is part of this replay.

## Stated intent, rules, priorities, and freedoms

Build/maintain a small C# .NET 10 local HTTP order service backed by SQLite. This Brownfield cell inherits working service behavior and must preserve it while implementing the Task 1 routes and contract. Required routes: `GET /health`, `GET /catalog`, `POST /orders`, `GET /orders/{id}`. Health answers 200; catalog has WIDGET at 1250 cents and GADGET at 775 cents. Orders require nonempty items and nonblank Idempotency-Key. Positive integer quantities have total sum at most 10 inclusive. Normalize duplicate SKU lines and compare requests canonically by SKU. Unknown SKU returns 400 `unknown_sku`; invalid inputs return 400 `validation`; over-limit returns 400 `order_limit`; errors have useful nonempty messages. A new order is 201/accepted with normalized items, integer-cent total, and ID. Replaying an equivalent request/key returns 200 and same ID; reusing the key for different canonical content returns 409 `idempotency_conflict`, preserving first result. Known ID reads the same order; unknown ID returns 404 `not_found`.

The Brownfield fixture's existing `POST /legacy/orders` path is valid behavior and must remain understandable/preserved. Existing health/catalog/inventory/order/idempotency/SQLite behavior and the stated toolchain/dependency pins are provenance/starting evidence, not a supplied canonical model. No stock reservation, availability rejection, concurrency guarantee, cancellation, fulfillment, or canonical-model reconciliation is active Task 1 behavior. Keep compatibility with actual current behavior. Use integer cents, not floating point. Choose proportionate internal structure; no prescribed project layout/pattern.

## Assumptions

- The existing fixture behavior described in the provenance packet is the preservation baseline, subject to confirming it in the source and checks.
- No hidden migration or production database history exists, consistent with the provenance statement.
- Useful ownership/dependency/projection detail must be discovered from repository source; prose links do not create canonical dependencies.

## Behavior-changing open questions

- Does “preserve working behavior” require retaining every existing response/status detail on `POST /legacy/orders`, beyond the described same-behavior alias contract? The packet describes its current behavior but no separate route-specific output variations.
- Should malformed JSON distinguish parser failures from validation errors? Task card only specifies the enumerated invalid fields.
- What exact ownership boundaries are intended among HTTP wiring, persistence, validation, contracts, generated projections, and legacy alias? No model is supplied; this is an authoring freedom unless a current task behavior depends on it.

These questions do not block the stated Task 1 behavior; I will preserve observed compatible behavior and avoid inventing extra contract requirements.
