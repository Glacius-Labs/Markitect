Follow the supplied Oldschool working-method brief. Use ordinary good engineering, useful independent review and focused checks. Do not use Markitect/Government. Record decisions, implementation, uncertainty and SHA-bound validation. You may request genuinely useful independent helpers within the same ledger, not start them yourself.

