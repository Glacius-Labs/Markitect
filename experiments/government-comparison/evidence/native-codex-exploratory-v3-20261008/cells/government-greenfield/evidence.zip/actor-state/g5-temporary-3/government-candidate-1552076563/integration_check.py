import os, subprocess, sys, time, urllib.request
from pathlib import Path
root = Path.cwd()
env = os.environ.copy()
env['ASPNETCORE_URLS'] = 'http://127.0.0.1:5097'
env['ORDERS_DB_PATH'] = str(root / 'orders-test.db')
proc = subprocess.Popen(['dotnet', 'run', '--project', 'src/Orders.Api/Orders.Api.csproj', '--no-build', '--no-launch-profile'], cwd=root, env=env, stdout=(root/'service.stdout.log').open('w'), stderr=(root/'service.stderr.log').open('w'))
try:
    ready = False
    for _ in range(40):
        if proc.poll() is not None:
            break
        try:
            with urllib.request.urlopen('http://127.0.0.1:5097/health', timeout=1) as r:
                if r.status == 200:
                    ready = True
                    break
        except Exception:
            time.sleep(.25)
    if not ready:
        print((root/'service.stdout.log').read_text(errors='replace'))
        print((root/'service.stderr.log').read_text(errors='replace'))
        raise SystemExit('service did not become ready')
    check = subprocess.run(['C:/Python313/python.exe', 'C:/Users/Consiliari/Documents/Scientist-Native-v3-20261008/support/government-greenfield/inputs/stage-1/checks.py', '--base-url', 'http://127.0.0.1:5097', '--through-task', '1', '--condition', 'greenfield', '--checkpoint', str(root/'checkpoint.json')], cwd=root, env=env, text=True)
    raise SystemExit(check.returncode)
finally:
    if proc.poll() is None:
        proc.terminate()
        try: proc.wait(timeout=5)
        except subprocess.TimeoutExpired: proc.kill(); proc.wait()
