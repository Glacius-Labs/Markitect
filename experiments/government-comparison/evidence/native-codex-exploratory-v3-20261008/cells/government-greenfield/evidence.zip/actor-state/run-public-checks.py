import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

p = argparse.ArgumentParser()
p.add_argument('--checks', required=True)
p.add_argument('--checkpoint', required=True)
p.add_argument('--base-url', default='http://127.0.0.1:5187')
a = p.parse_args()
root = Path.cwd()
run = subprocess.run(['dotnet', 'build', 'src/Orders.Api/Orders.Api.csproj', '--configuration', 'Release', '--locked-mode'], cwd=root, text=True, capture_output=True, timeout=120)
sys.stdout.write(run.stdout)
sys.stderr.write(run.stderr)
if run.returncode:
    raise SystemExit(run.returncode)
audit = subprocess.run(['dotnet', 'list', 'src/Orders.Api/Orders.Api.csproj', 'package', '--vulnerable', '--include-transitive', '--no-restore'], cwd=root, text=True, capture_output=True, timeout=60)
sys.stdout.write(audit.stdout)
sys.stderr.write(audit.stderr)
if audit.returncode:
    raise SystemExit(audit.returncode)
with tempfile.NamedTemporaryFile(prefix='task1-', suffix='.sqlite', dir=Path(__file__).parent, delete=False) as f:
    db = f.name
Path(db).unlink(missing_ok=True)
env = os.environ.copy()
env['ASPNETCORE_URLS'] = a.base_url
env['ORDERS_DB_PATH'] = db
proc = subprocess.Popen(['dotnet', 'run', '--project', 'src/Orders.Api/Orders.Api.csproj', '--configuration', 'Release', '--no-build', '--no-launch-profile'], cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
try:
    deadline = time.monotonic() + 45
    healthy = False
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            print(proc.stdout.read(), file=sys.stderr)
            raise SystemExit(proc.returncode or 1)
        try:
            with urllib.request.urlopen(a.base_url + '/health', timeout=2) as response:
                if response.status == 200:
                    healthy = True
                    break
        except (urllib.error.URLError, TimeoutError):
            time.sleep(.25)
    if not healthy:
        raise SystemExit('service did not become healthy')
    check = subprocess.run([sys.executable, '-B', a.checks, '--base-url', a.base_url, '--through-task', '1', '--condition', 'greenfield', '--checkpoint', a.checkpoint], cwd=root, text=True, capture_output=True, timeout=90)
    sys.stdout.write(check.stdout)
    sys.stderr.write(check.stderr)
    raise SystemExit(check.returncode)
finally:
    proc.terminate()
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)
    if proc.stdout:
        output = proc.stdout.read()
        if output:
            print(output, file=sys.stderr)
    Path(db).unlink(missing_ok=True)