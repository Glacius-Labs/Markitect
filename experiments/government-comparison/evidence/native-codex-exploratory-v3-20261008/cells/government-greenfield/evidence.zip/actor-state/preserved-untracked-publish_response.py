import hashlib, json, os
from pathlib import Path
root = Path.cwd()
support = Path('C:/Users/Consiliari/Documents/Scientist-Native-v3-20261008/support/government-greenfield')
mailbox = support / 'state/mailbox/c9a1ba80e598a12081c92f4003611aec'
ws = support / 'state/g5-temporary-3/government-candidate-1552076563'
inv = json.loads((mailbox/'invocation.json').read_text(encoding='utf-8'))
paths = ['NuGet.Config','README.md','global.json','src/Orders.Api/Orders.Api.csproj','src/Orders.Api/Program.cs','src/Orders.Api/packages.lock.json']
files=[]; manifest=[]
for rel in paths:
    raw=(ws/rel).read_bytes()
    content=raw.decode('utf-8')
    files.append({'path':rel,'mode':'100644','content':content})
    manifest.append({'path':rel,'sha256':hashlib.sha256(raw).hexdigest()})
lock = json.loads((ws/'src/Orders.Api/packages.lock.json').read_text(encoding='utf-8'))
assert lock['dependencies']['net10.0']['SQLite']['resolved'] == '3.53.4'
q1 = support/'state/q1/government-greenfield-task1.md'
evidence = {
  'role':'executor','runId':inv['runId'],'recordedUtc':'2026-10-08T21:54:35Z',
  'sourceRevision':inv['request']['sourceRevision'],'invocationInputDigest':inv['inputDigest'],
  'q1Record':str(q1),'q1Sha256':hashlib.sha256(q1.read_bytes()).hexdigest(),
  'toolchain':{'dotnetSdk':'10.0.103','runtime':'10.0.3'},
  'checks':[
    {'command':'dotnet restore src/Orders.Api/Orders.Api.csproj --use-lock-file --verbosity minimal','exitCode':0,'result':'restored from explicit NuGet.org source'},
    {'command':'dotnet build src/Orders.Api/Orders.Api.csproj --no-restore --verbosity minimal','exitCode':0,'result':'0 warnings, 0 errors'},
    {'command':'dotnet list src/Orders.Api/Orders.Api.csproj package --vulnerable --include-transitive --no-restore','exitCode':0,'result':'no vulnerable packages reported by current NuGet sources'},
    {'command':'Python 3.13 local HTTP launch + supplied stage-1 checks.py --through-task 1 --condition greenfield','exitCode':0,'passed':['health','catalog prices','invalid zero','invalid negative','invalid fractional','invalid unknown','invalid empty','invalid limit','missing key','unknown order','created exact total','read order','semantic retry','key conflict'],'stdout':'state/g5-temporary-3/government-candidate-1552076563/service.stdout.log','stderr':'state/g5-temporary-3/government-candidate-1552076563/service.stderr.log'}
  ],
  'packageLockSha256':hashlib.sha256((ws/'src/Orders.Api/packages.lock.json').read_bytes()).hexdigest(),
  'candidateFiles':manifest,
  'limitations':['No independent Ressort review, vote, promotion, or human acceptance has occurred.','No behavior beyond released Task 1 was implemented.','Concurrency under simultaneous first requests using the same idempotency key was not separately exercised.']
}
epath=support/'state/g5-temporary-3/government-candidate-1552076563/executor-evidence.json'
epath.write_text(json.dumps(evidence,indent=2)+'\n',encoding='utf-8')
response={
 'apiVersion':inv['apiVersion'],'runId':inv['runId'],'nonce':inv['nonce'],'role':'executor','inputDigest':inv['inputDigest'],
 'outcome':'proposed','candidateFiles':files,
 'evidenceRefs':[str(epath),str(q1)],
 'verifierObservations':[],
 'candidateJson':{'candidateId':'government-greenfield-v3-20261008-task1','files':manifest,'evidence':str(epath),'limitations':evidence['limitations']},
 'uncertainty':['The SDK/runtime and package vulnerability result describe this runner and current NuGet advisory data.','Same-key simultaneous first-write contention was not separately tested.']
}
tmp=mailbox/'response.tmp'; final=mailbox/'response.json'
with tmp.open('x',encoding='utf-8',newline='\n') as f:
    f.write(json.dumps(response,ensure_ascii=False,separators=(',',':'))+'\n'); f.flush(); os.fsync(f.fileno())
os.replace(tmp,final)
print(json.dumps({'response':str(final),'responseSha256':hashlib.sha256(final.read_bytes()).hexdigest(),'candidateCount':len(files),'evidence':str(epath),'evidenceSha256':hashlib.sha256(epath.read_bytes()).hexdigest(),'candidateDigests':manifest},indent=2))
