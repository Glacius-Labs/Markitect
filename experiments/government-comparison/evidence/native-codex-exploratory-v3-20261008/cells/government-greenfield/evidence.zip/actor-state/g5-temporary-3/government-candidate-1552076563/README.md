# Local Orders API

Requires the pinned .NET SDK 10.0.103. Restore and build from this directory with `dotnet restore src/Orders.Api/Orders.Api.csproj --use-lock-file` and `dotnet build src/Orders.Api/Orders.Api.csproj --no-restore`.

Run with `ASPNETCORE_URLS=http://127.0.0.1:5080` and `ORDERS_DB_PATH=./orders.db` set in the environment, then `dotnet run --project src/Orders.Api/Orders.Api.csproj --no-build`. The service creates its SQLite schema on startup. `GET /health`, `GET /catalog`, `POST /orders`, and `GET /orders/{id}` implement the released Task 1 contract.

The public release check can be run as `python checks.py --base-url http://127.0.0.1:5080 --through-task 1 --condition greenfield` from the supplied stage-1 input directory.
