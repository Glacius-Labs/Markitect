# Q1 intent replay — Task 1

Recorded: 2026-10-08T21:42:10Z, before any implementation change.

## Released source and cutoff

This replay uses the cell's released inputs only: common brief v0.2 (`stage-1/brief.md`, SHA-256 `4692ec98bbf8f8a140020e88182a62504689e6e6df5aa80af7c6783cdacb13c8`); reference architecture v0.3 (`stage-1/architecture.md`, SHA-256 `7459d9514358d1448c2353e0c0bf3d24d11a7eaf84b67c695724c88d20023700`); Task 1 (`stage-1/01-create-order.md`, SHA-256 `bf5c1e5bf148245bfbc8212e2ad90b7369d8a1a03765258eda078f1ec87075a9`); and public checks (`stage-1/checks.py`, SHA-256 `fc96859ce7cc71426ed774f3ff5d88a45adcf016d2250c259287d1da628ac0cc`). The release manifest is `stage-1/release.json` (SHA-256 `d1b32f63fd4b856e4d944114d4b0294e8087c718423948289d1d69e3b37f5a50`). Shared replay procedure is `q1-intent-setup-v1.md` (SHA-256 `40bba049ac18da05deaa31943e3f6452280220f560f39e55a908704b8397312e`). The cutoff is Task 1 as currently released; no later task card is treated as a requirement.

## Stated intent

Build a small local HTTP service in C# targeting .NET 10 with SQLite. The runner supplies bind address and database path. It must implement `GET /health`, `GET /catalog`, `POST /orders`, and `GET /orders/{id}`. The catalog contains WIDGET at 1250 euro cents and GADGET at 775. A valid new order is accepted and returns its ID, normalized items, and integer-cent total. For two WIDGETs and one GADGET the total is 3275. Reads return the same stored order; unknown IDs return 404 with `not_found`.

Task 1 sets the maximum sum of line quantities to 10 inclusive. Missing/empty items, missing or blank idempotency key, and invalid/non-positive/non-integer quantities produce HTTP 400 `validation`; an unknown SKU produces HTTP 400 `unknown_sku`; a quantity sum over 10 produces HTTP 400 `order_limit`. Every error message is non-empty. Duplicate SKU lines combine and canonical items sort by SKU. Repeating a key with the same canonical request returns HTTP 200 and the original ID; the key with a different canonical request returns HTTP 409 `idempotency_conflict` and leaves the first result unchanged. A new valid request returns HTTP 201. Prices and totals use integer cents, not binary floating point. Provide concise build/run/check instructions.

The specified runtime pins are .NET SDK 10.0.103 with roll-forward disabled, .NET and ASP.NET Core runtime 10.0.3, `Microsoft.Data.Sqlite` 10.0.3, and SQLitePCLRaw bundle/core 3.0.5, exact package versions and lock file; restore from NuGet.org with local source configuration. The architecture does not require a project count, table names, schema, ID format, exact prose, or internal pattern. Minimal APIs or controllers, direct SQL or ADO.NET, and one or a few projects are permitted. No DDD, Clean Architecture, repository pattern, mediator, ORM, container, cloud or paid service is required. Keep abstractions proportionate. Greenfield starts empty. The Brownfield compatibility clause does not supply Greenfield behavior.

## Direct statements versus assumptions

Direct: only the four named routes are in scope; the quantities cap is 10; cents are integers; SQLite is local; routes, statuses, error codes and idempotency/canonicalization semantics above are required. Direct: service must run with runner-provided address/database values. Direct: implementation structure is free within the stated options.

Assumptions for implementation unless contradicted by the released contract: a simple random/stable string ID is sufficient because no format is prescribed; a small orders table plus order-item rows is proportionate; initialize schema when the process starts; use case-sensitive fixed SKU identifiers as listed; serialize the order's normalized values into the response from its persisted row data. I will avoid defining concurrency semantics or extra input/error behavior beyond what this task and normal HTTP parsing require.

## Questions that could affect behavior

The released material does not state an ID format, order table shape, display names, request-size policy, or simultaneous same-key race semantics. These do not prevent the required sequential behavior and are left as implementation freedoms. No released rule conflicts with proceeding. No question is being treated as user acceptance or a new requirement.
