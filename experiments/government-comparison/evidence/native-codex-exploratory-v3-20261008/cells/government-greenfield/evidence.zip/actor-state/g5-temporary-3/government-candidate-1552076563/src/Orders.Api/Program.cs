using System.Text.Json;
using Microsoft.Data.Sqlite;

var builder = WebApplication.CreateBuilder(args);
var dbPath = Environment.GetEnvironmentVariable("ORDERS_DB_PATH") ?? Path.Combine(AppContext.BaseDirectory, "orders.db");
var fullDbPath = Path.GetFullPath(dbPath);
Directory.CreateDirectory(Path.GetDirectoryName(fullDbPath)!);
var connectionString = new SqliteConnectionStringBuilder { DataSource = fullDbPath, Mode = SqliteOpenMode.ReadWriteCreate, Pooling = true }.ToString();
await using (var connection = new SqliteConnection(connectionString))
{
    await connection.OpenAsync();
    var command = connection.CreateCommand();
    command.CommandText = """
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS orders (
            id TEXT PRIMARY KEY,
            idempotency_key TEXT NOT NULL UNIQUE,
            canonical_request TEXT NOT NULL,
            status TEXT NOT NULL,
            total_cents INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS order_items (
            order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
            sku TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            unit_price_cents INTEGER NOT NULL,
            PRIMARY KEY (order_id, sku)
        );
        """;
    await command.ExecuteNonQueryAsync();
}

var app = builder.Build();
app.MapGet("/health", () => Results.Ok(new { status = "ok" }));
app.MapGet("/catalog", () => Results.Ok(new[] { new CatalogItem("WIDGET", 1250), new CatalogItem("GADGET", 775) }));

app.MapPost("/orders", async (HttpRequest request) =>
{
    var key = request.Headers["Idempotency-Key"].ToString();
    if (string.IsNullOrWhiteSpace(key)) return Error(400, "validation", "Idempotency-Key header is required and must not be blank.");

    JsonDocument body;
    try { body = await JsonDocument.ParseAsync(request.Body); }
    catch (JsonException) { return Error(400, "validation", "Request body must be a JSON object with a non-empty items array."); }
    using (body)
    {
        if (body.RootElement.ValueKind != JsonValueKind.Object || !body.RootElement.TryGetProperty("items", out var itemsElement) || itemsElement.ValueKind != JsonValueKind.Array || itemsElement.GetArrayLength() == 0)
            return Error(400, "validation", "Items must be a non-empty array.");
        var quantities = new SortedDictionary<string, int>(StringComparer.Ordinal);
        var totalQuantity = 0;
        foreach (var item in itemsElement.EnumerateArray())
        {
            if (item.ValueKind != JsonValueKind.Object || !item.TryGetProperty("sku", out var skuElement) || skuElement.ValueKind != JsonValueKind.String || string.IsNullOrWhiteSpace(skuElement.GetString()))
                return Error(400, "validation", "Each item must include a non-empty SKU.");
            if (!item.TryGetProperty("quantity", out var quantityElement) || quantityElement.ValueKind != JsonValueKind.Number || !quantityElement.TryGetInt32(out var quantity) || quantity <= 0)
                return Error(400, "validation", "Each item quantity must be a positive integer.");
            var sku = skuElement.GetString()!;
            if (sku is not ("WIDGET" or "GADGET")) return Error(400, "unknown_sku", $"SKU '{sku}' is not in the catalog.");
            if (totalQuantity > 10 - quantity) return Error(400, "order_limit", "The total quantity per order cannot exceed 10.");
            totalQuantity += quantity;
            quantities[sku] = checked(quantities.GetValueOrDefault(sku) + quantity);
        }
        var normalized = quantities.Select(x => new OrderItem(x.Key, x.Value, Price(x.Key))).ToArray();
        var canonical = JsonSerializer.Serialize(normalized.Select(x => new CanonicalItem(x.Sku, x.Quantity)));
        await using var connection = new SqliteConnection(connectionString);
        await connection.OpenAsync();
        await using var transaction = await connection.BeginTransactionAsync();
        var lookup = connection.CreateCommand();
        lookup.Transaction = (SqliteTransaction)transaction;
        lookup.CommandText = "SELECT id, canonical_request FROM orders WHERE idempotency_key = $key";
        lookup.Parameters.AddWithValue("$key", key);
        await using (var reader = await lookup.ExecuteReaderAsync())
        {
            if (await reader.ReadAsync())
            {
                var existingId = reader.GetString(0);
                var existingCanonical = reader.GetString(1);
                await reader.CloseAsync();
                if (!StringComparer.Ordinal.Equals(existingCanonical, canonical)) return Error(409, "idempotency_conflict", "This idempotency key was already used for a different order.");
                var existing = await LoadOrder(connection, (SqliteTransaction)transaction, existingId);
                await transaction.CommitAsync();
                return Results.Ok(existing);
            }
        }
        var id = Guid.NewGuid().ToString("D");
        var total = normalized.Sum(x => x.Quantity * x.UnitPriceCents);
        var insert = connection.CreateCommand();
        insert.Transaction = (SqliteTransaction)transaction;
        insert.CommandText = "INSERT INTO orders (id, idempotency_key, canonical_request, status, total_cents) VALUES ($id, $key, $canonical, 'accepted', $total)";
        insert.Parameters.AddWithValue("$id", id);
        insert.Parameters.AddWithValue("$key", key);
        insert.Parameters.AddWithValue("$canonical", canonical);
        insert.Parameters.AddWithValue("$total", total);
        await insert.ExecuteNonQueryAsync();
        foreach (var orderItem in normalized)
        {
            var add = connection.CreateCommand();
            add.Transaction = (SqliteTransaction)transaction;
            add.CommandText = "INSERT INTO order_items (order_id, sku, quantity, unit_price_cents) VALUES ($id, $sku, $quantity, $price)";
            add.Parameters.AddWithValue("$id", id);
            add.Parameters.AddWithValue("$sku", orderItem.Sku);
            add.Parameters.AddWithValue("$quantity", orderItem.Quantity);
            add.Parameters.AddWithValue("$price", orderItem.UnitPriceCents);
            await add.ExecuteNonQueryAsync();
        }
        await transaction.CommitAsync();
        return Results.Created($"/orders/{id}", new Order(id, "accepted", normalized, total));
    }
});

app.MapGet("/orders/{id}", async (string id) =>
{
    await using var connection = new SqliteConnection(connectionString);
    await connection.OpenAsync();
    var order = await LoadOrder(connection, null, id);
    return order is null ? Error(404, "not_found", $"Order '{id}' was not found.") : Results.Ok(order);
});
app.Run();

static int Price(string sku) => sku == "WIDGET" ? 1250 : 775;
static IResult Error(int status, string code, string message) => Results.Json(new ErrorBody(code, message), statusCode: status);
static async Task<Order?> LoadOrder(SqliteConnection connection, SqliteTransaction? transaction, string id)
{
    var command = connection.CreateCommand();
    command.Transaction = transaction;
    command.CommandText = "SELECT status, total_cents FROM orders WHERE id = $id";
    command.Parameters.AddWithValue("$id", id);
    await using var reader = await command.ExecuteReaderAsync();
    if (!await reader.ReadAsync()) return null;
    var status = reader.GetString(0);
    var total = reader.GetInt32(1);
    await reader.CloseAsync();
    var itemCommand = connection.CreateCommand();
    itemCommand.Transaction = transaction;
    itemCommand.CommandText = "SELECT sku, quantity, unit_price_cents FROM order_items WHERE order_id = $id ORDER BY sku";
    itemCommand.Parameters.AddWithValue("$id", id);
    var items = new List<OrderItem>();
    await using var itemReader = await itemCommand.ExecuteReaderAsync();
    while (await itemReader.ReadAsync()) items.Add(new OrderItem(itemReader.GetString(0), itemReader.GetInt32(1), itemReader.GetInt32(2)));
    return new Order(id, status, items, total);
}

record CatalogItem(string Sku, int UnitPriceCents);
record CanonicalItem(string Sku, int Quantity);
record OrderItem(string Sku, int Quantity, int UnitPriceCents);
record Order(string Id, string Status, IReadOnlyList<OrderItem> Items, int TotalCents);
record ErrorBody(string Code, string Message);
