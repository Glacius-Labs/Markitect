# Government Greenfield v3 model helper: wire-shape evidence

This is a shape-only helper result. It records the pinned executable behavior and public contract evidence; it does not select domain semantics or propose a case model.

## Supported source envelope seen in the pinned executable

`markitect.exe government --help` shows `schema`, `inspect`, and `plan` actions. The help command exits 0. `government --action schema` exits 0 and emits the built-in structural Schema with `apiVersion: markitect.government/v1alpha1`; the exact output is retained at `state/model-helper-scratch/government-schema.txt`.

The public Government docs describe one strict source document with `apiVersion: markitect.government-source/v1alpha1`, `constitution`, inline `schemas` and `definitions`, and `observation` (government.md, line 14). Native probes establish that the YAML root also requires `kind: GovernmentSource`: with the documented `apiVersion` and empty `constitution/schemas/definitions/observation` but without `kind`, inspect exits 1 and reports `source.version: expected markitect.government-source/v1alpha1 GovernmentSource`; adding `kind: GovernmentSource` removes that finding and reaches semantic validation (`constitution.identity` when no Constitution Definition resolves). A top-level `version:` is rejected as an unknown YAML field. Thus the observed source envelope is:

```yaml
apiVersion: markitect.government-source/v1alpha1
kind: GovernmentSource
constitution: {apiVersion: markitect.government/v1alpha1, kind: Constitution, namespace: "", name: constitution}
schemas: []
definitions: []
observation: {roots: [.]}
```

The object form of `constitution` is supported by the docs and root-kind probe. Full identities contain exactly the explicit `apiVersion`, `kind`, `namespace` (empty allowed), and `name` fields according to government.md line 14 and the emitted built-in schema.

## Core Definition discrepancy and limit

The docs state that Government Definitions carry `purpose` and that full identities use `apiVersion`, `kind`, `namespace`, and `name` (government.md, line 14). The runtime schema emits full four-field identity objects for arbitrary `subject`/`scope` values. However, the actual pinned source decoder rejects `namespace` and `name` on every `definitions[]` item as unknown fields on `core.Definition`. It also rejects a top-level `properties` field. The decoder accepts the Core Definition envelope fields `apiVersion`, `kind`, `purpose`, and `spec`; that is consistent with the public architecture’s description of the structural Core (architecture.md, line 173), but not enough to establish a valid Definition identity wire shape.

A minimal Definition with only those accepted fields (`apiVersion`, `kind: Area`, `purpose`, `spec: {}`) passes YAML decoding but inspect exits 1 with `definition.identity` and an empty name. Trying `spec: {name: root}` still yields the empty-name identity error and additionally `spec.unknown-property: name: Kind "Area" does not declare Property "name"`. Therefore `spec.name` is not an accepted identity workaround. No successful named Core Definition was found within this helper’s bounded probes. Do not treat `namespace`/`name`/`properties` at the Definition top level as supported by this executable, and do not infer an alternative identity encoding from these results.

## Native receipts

All commands ran from the assigned Greenfield cell working directory and used only its pinned `product/markitect.exe`, public `product/docs`, public `product/modules`, and disposable files under `support/government-greenfield/state/model-helper-scratch`.

- `markitect.exe government --help` — exit 0; action and flags listed.
- `markitect.exe government --action schema` — exit 0; built-in Schema emitted; SHA-256 of executable: `12241F325E4AF59451E4021B31D9E6F5B829B5DE06C94D35EAABFB9D663AA51F`.
- Existing task config `government.yaml`, `--action inspect` — exit 2; YAML rejects `namespace`, `name`, and `properties` on `core.Definition`.
- Existing task config `government.yaml`, `--action plan --order order.yaml` — exit 2; same Definition decoding refusal.
- Scratch source with documented root fields but no `kind` — exit 1; `source.version` finding (above).
- Scratch source adding `kind: GovernmentSource`, empty `definitions`, empty `schemas`, and `constitution: {}` — exit 1; source decoding succeeds, built-in Schema is present, then Constitution identity cannot resolve.
- Scratch source with `kind: GovernmentSource`, a full Constitution identity, and one `{apiVersion, kind, purpose, spec: {}}` Area Definition — exit 1; YAML decoding succeeds, then `definition.identity` reports empty name.
- Scratch source with `spec: {name: root}` — exit 1; same identity finding plus `spec.unknown-property`.
- Scratch source with top-level `version:` — exit 2; `field version not found in type government.Source`.
- Scratch source wrapping fields under `source:` — exit 2; `field source not found in type government.Source`.

The raw scratch YAMLs and CLI stdout are retained in `state/model-helper-scratch/`. These statuses distinguish parser acceptance from semantic model validity; none is a valid Government model or acceptance result.

## Public references and uncertainty

- `product/docs/government.md:14-18` describes source, Definition, full-identity, and Constitution/Order shapes.
- `product/docs/architecture.md:173` describes explicit Schema and Definition compilation through the structural Core; `:223` describes Schema Module vocabulary and its schema files.
- `product/modules/foundation/schema.yaml` is a public custom Schema example showing `apiVersion`, `purpose`, `kinds`, Kind `purpose`, and nested `properties`; it is not a Government Definition example.
- Pinned CLI output is authoritative only for this executable’s behavior. The mismatch means the exact supported named Definition serialization remains unresolved here. A primary actor must preserve this as a compatibility blocker/uncertainty or obtain an independently permitted source of evidence; it should not manufacture a case model from a guessed encoding.
