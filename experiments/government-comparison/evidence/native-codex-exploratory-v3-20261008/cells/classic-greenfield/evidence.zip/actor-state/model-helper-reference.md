# Classic greenfield Task 1 — public canonical model shape reference

Scope: shape facts from this cell's pinned v0.14.1 product docs and modules plus read-only native CLI validation. This is not a case model or semantic recommendation.

## Supported inputs

- The canonical source config explicitly selects Definition files, local Module manifest/files, and exact package pins. Runtime `projectionBindings` is separate from canonical intent: it maps a full Projection identity to one exact installed Module name. The Host resolves that pin and requires a unique compatible execution entrypoint. The Projection Definition itself does not name a Module, package, executor, or projector. (Pinned `product/docs/canonical-projections.md`; `product/docs/architecture.md`.)
- Generic Definition documents have the accepted normalized envelope `apiVersion`, `kind`, `metadata` (`name`, `namespace`), `purpose`, and `spec` object. The `apiVersion` and `kind` select the Schema/Kind; `spec` contains only that Kind's declared properties. Names/namespace and exact identity are used in references.
- The foundation Schema Module declares API `markitect.foundation/v1`:
  - `Projection`: `source.definitions[]` entries each have `apiVersion`, `kind`, `namespace`, `name`; `representation` is exactly `dotnet` or `markdown`; `target` has `repository` and `path`; optional repeated `policies[]` are typed refs to foundation `ProjectionPolicy`.
  - `ProjectionPolicy`: `sourceKind` is a kind reference; `targetTechnology` and `guidance` are strings.
- The supplied example commerce Schema Module declares `commerce.example.org/v1` kinds `UseCase` (required `handledBy` ref to `Handler`), `Handler` (no spec properties), and `EffectAxis` (required string `boundary`). These are example vocabulary, not universal required case fields.
- A Definition file's source path and bytes are fixed inputs. Projection scope is an explicit ordered list; the product does not infer closure from references or prose.

The frozen documentation names the configuration ingredients but the support package does not include `examples/canonical-projection/canonical.yaml`, and `markitect --help` does not expose a key-by-key config schema. Therefore this reference does not claim an exact raw config YAML envelope beyond the named concepts above. Do not infer extra keys from normalized CLI output.

## Native validation receipts

Ran read-only from the assigned repo root against the existing `markitect.yaml` using the pinned `product/markitect.exe`:

- `markitect canonical --repo . --config markitect.yaml --action modules` — exit 0; emitted resolved Module inventory and `status: preview`, `provisional: true`.
- `markitect canonical --repo . --config markitect.yaml --action model` — exit 0; emitted normalized schemas, Definitions, and typed edges with `status: passed`, `provisional: true`. This verifies parser/model acceptance for the current snapshot only; it does not validate any separate scratch or future model.
- `markitect.exe --help`, `canonical --help`, `help canonical`, `help model`, `help schema` — returned usage successfully; canonical options include `--config`, `--action`, `--repo`, `--revision`, and model/context selectors. Help does not enumerate raw config keys.

No files in the repo were changed and no fixture or scratch model was used as a method outcome. The accepted current model was not copied into this reference.
