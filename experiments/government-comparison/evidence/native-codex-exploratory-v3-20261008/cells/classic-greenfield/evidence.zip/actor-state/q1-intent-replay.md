# Q1 intent replay — Task 1, Classic Greenfield

Recorded: 2026-10-08T21:42:00Z (UTC; before implementation)

## Released sources and cutoff

- Common brief v0.2: `support/classic-greenfield/inputs/stage-1/brief.md`, SHA-256 `4692ec98bbf8f8a140020e88182a62504689e6e6df5aa80af7c6783cdacb13c8`.
- Reference architecture/fixture contract v0.3: `.../architecture.md`, SHA-256 `7459d9514358d1448c2353e0c0bf3d24d11a7eaf84b67c695724c88d20023700`.
- Current task card Task 1: `.../01-create-order.md`, SHA-256 `bf5c1e5bf148245bfbc8212e2ad90b7369d8a1a03765258eda078f1ec87075a9`.
- Public checks supplied with this release: `.../checks.py`, SHA-256 `fc96859ce7cc71426ed774f3ff5d88a45adcf016d2250c259287d1da628ac0cc`.
- Cutoff is Task 1 only. Later behavior is not in scope.

## Stated intent and rules

Build a small local C# HTTP service targeting `net10.0`, pinned to SDK `10.0.103` with roll-forward disabled and ASP.NET/.NET runtime `10.0.3`, using SQLite. Required routes are health, fixed catalog, create order, and read order. JSON is camelCase; prices/totals are integer euro cents. Catalog is WIDGET=1250, GADGET=775. Orders start `accepted`, return normalized sorted SKU lines and total, and persist in SQLite. Duplicate SKU lines are combined. The maximum sum of line quantities is 10 inclusive. Missing/empty items, blank/missing idempotency key, and invalid/non-positive/non-integer quantities return 400 `validation`; unknown SKU returns 400 `unknown_sku`; above-limit quantity returns 400 `order_limit`; errors include useful non-empty messages. A canonical retry with same key returns 200 and original ID; key reuse for another canonical request returns 409 `idempotency_conflict` without changing the original. Unknown order reads return 404 `not_found`.

Exact direct package pins: Microsoft.Data.Sqlite 10.0.3; SQLitePCLRaw.bundle_e_sqlite3 3.0.5; SQLitePCLRaw.core 3.0.5, with lock file and clean NuGet.org source configuration. The resolved SQLite engine is 3.53.4. No warnings are to be suppressed.

## Freedoms

Minimal API or controllers; direct SQL/ADO.NET; one or a few projects; schema and ID design; proportionate abstractions; concise build/run/check instructions. The service binds to runner-supplied address and SQLite path. Do not add routes beyond those active at task start.

## Assumptions and open behavior questions

- I will normalize SKU identity as exact catalog SKU spelling because no case-folding rule is released.
- I will reject malformed JSON/non-object item shapes with a useful `validation` response as a conservative API choice.
- I assume generated IDs may be opaque strings because format is intentionally unspecified.
- No released decision changes route, status, pricing, quantity limit, canonicalization, persistence, or error-code behavior; remaining choices above are implementation freedoms.

No future task requirements or human acceptance are inferred.
