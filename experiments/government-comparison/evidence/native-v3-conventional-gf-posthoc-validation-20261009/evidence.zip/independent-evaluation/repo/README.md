# Order Service

A small .NET 10 HTTP service backed by SQLite. The service uses `ASPNETCORE_URLS` for its bind address and `ORDER_DB_PATH` for the SQLite file.

From the repository root, restore the pinned graph and build:

```powershell
dotnet restore src/OrderService/OrderService.csproj --locked-mode
dotnet build src/OrderService/OrderService.csproj --no-restore
```

Run it with explicit local settings:

```powershell
$env:ASPNETCORE_URLS = 'http://127.0.0.1:5080'
$env:ORDER_DB_PATH = (Join-Path $PWD 'orders.db')
dotnet run --no-build --project src/OrderService/OrderService.csproj
```

Run the released Task 5 checks from a second terminal while the service is running:

```powershell
python C:/path/to/released/checks.py --base-url http://127.0.0.1:5080 --through-task 5 --condition greenfield --checkpoint checkpoint.json
```

After stopping and restarting the service with the same database path, verify the saved checkpoint with `--verify-restart checkpoint.json` instead of `--checkpoint`. Run the focused persistence check to also verify the SQLite-backed catalog and idempotency behavior:

```powershell
python scripts/check-restart.py --base-url http://127.0.0.1:5080 --checkpoint checkpoint.json
```

To verify lifecycle durability, prepare the fulfilled-order checkpoint before stopping the service and verify it after restart:

```powershell
python scripts/check-lifecycle-restart.py --base-url http://127.0.0.1:5080 --prepare lifecycle.json
# Stop and restart with the same ORDER_DB_PATH.
python scripts/check-lifecycle-restart.py --base-url http://127.0.0.1:5080 --verify lifecycle.json
```

`GET /inventory/{sku}` reports `onHand`, `reserved`, and `available`. Initial stock is 10 WIDGET and 6 GADGET. New orders reserve all requested stock in the same SQLite transaction as the order; insufficient stock returns HTTP 409 with code `insufficient_stock`.

`POST /orders/{id}/cancel` releases an accepted order's reservation; `POST /orders/{id}/fulfill` consumes it. Repeating the same action is safe, and the opposite action returns HTTP 409 with code `invalid_transition`.

Both `POST /orders` and `POST /legacy/orders` use the same order behavior. The sum of line quantities is limited to six inclusive.
