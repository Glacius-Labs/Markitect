"""Prepare or verify a fulfilled-order persistence check across a process restart."""

import argparse
import json
from pathlib import Path
import urllib.error
import urllib.request
import uuid


def request(base_url, method, route, payload=None, key=None):
    headers = {"Content-Type": "application/json"}
    if key is not None:
        headers["Idempotency-Key"] = key
    body = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(base_url.rstrip("/") + route, data=body, headers=headers, method=method)
    try:
        response = urllib.request.urlopen(req, timeout=10)
    except urllib.error.HTTPError as exc:
        response = exc
    with response:
        return response.status, json.loads(response.read())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare", metavar="CHECKPOINT")
    mode.add_argument("--verify", metavar="CHECKPOINT")
    args = parser.parse_args()
    passed = []

    if args.prepare:
        idempotency_key = f"task4-lifecycle-restart-{uuid.uuid4()}"
        status, before = request(args.base_url, "GET", "/inventory/WIDGET")
        assert status == 200 and before["available"] > 0
        status, created = request(args.base_url, "POST", "/orders", {"items": [{"sku": "WIDGET", "quantity": 1}]}, idempotency_key)
        assert status == 201 and created["status"] == "accepted"
        status, reserved = request(args.base_url, "GET", "/inventory/WIDGET")
        assert status == 200 and reserved["reserved"] == before["reserved"] + 1 and reserved["available"] == before["available"] - 1
        status, fulfilled = request(args.base_url, "POST", f"/orders/{created['id']}/fulfill", {})
        assert status == 200 and fulfilled["status"] == "fulfilled"
        status, after = request(args.base_url, "GET", "/inventory/WIDGET")
        assert status == 200 and after["onHand"] == reserved["onHand"] - 1 and after["reserved"] == reserved["reserved"] - 1 and after["available"] == reserved["available"]
        Path(args.prepare).write_text(json.dumps({"order": fulfilled, "inventory": after}, indent=2) + "\n", encoding="utf-8")
        passed.extend(["fulfillment changed status", "fulfillment consumed reserved stock", "available stock unchanged"])
    else:
        checkpoint = json.loads(Path(args.verify).read_text(encoding="utf-8"))
        order = checkpoint["order"]
        expected_inventory = checkpoint["inventory"]
        status, actual = request(args.base_url, "GET", f"/orders/{order['id']}")
        assert status == 200 and actual == order and actual["status"] == "fulfilled"
        status, inventory = request(args.base_url, "GET", "/inventory/WIDGET")
        assert status == 200 and inventory == expected_inventory
        passed.extend(["fulfilled status persisted", "fulfillment inventory persisted"])

        status, repeated = request(args.base_url, "POST", f"/orders/{order['id']}/fulfill", {})
        assert status == 200 and repeated == order
        status, after_repeat = request(args.base_url, "GET", "/inventory/WIDGET")
        assert status == 200 and after_repeat == expected_inventory
        passed.extend(["repeated fulfillment is idempotent", "repeat leaves inventory unchanged"])

        status, error = request(args.base_url, "POST", f"/orders/{order['id']}/cancel", {})
        assert status == 409 and error.get("code") == "invalid_transition"
        status, after_opposite = request(args.base_url, "GET", "/inventory/WIDGET")
        assert status == 200 and after_opposite == expected_inventory
        passed.extend(["opposite transition rejected", "rejection leaves inventory unchanged"])

    print(json.dumps({"status": "passed", "checks": passed}, indent=2))


if __name__ == "__main__":
    main()
