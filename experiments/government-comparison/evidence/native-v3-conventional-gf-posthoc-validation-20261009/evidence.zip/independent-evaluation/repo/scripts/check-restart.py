"""Verify catalog, order, inventory, and idempotency state after a restart."""

import argparse
import json
from pathlib import Path
import urllib.error
import urllib.request


def request(base_url, method, route, payload=None, key=None):
    headers = {"Content-Type": "application/json"}
    if key is not None:
        headers["Idempotency-Key"] = key
    body = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(base_url.rstrip("/") + route, data=body, headers=headers, method=method)
    try:
        response = urllib.request.urlopen(req, timeout=10)
    except urllib.error.HTTPError as exc:
        response = exc
    with response:
        return response.status, json.loads(response.read())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--checkpoint", required=True)
    args = parser.parse_args()
    checkpoint = json.loads(Path(args.checkpoint).read_text(encoding="utf-8"))
    passed = []

    status, catalog = request(args.base_url, "GET", "/catalog")
    assert status == 200 and {item["sku"]: item["unitPriceCents"] for item in catalog} == {"WIDGET": 1250, "GADGET": 775}
    passed.append("catalog persisted")

    status, order = request(args.base_url, "GET", f"/orders/{checkpoint['order']['id']}")
    assert status == 200 and order == checkpoint["order"]
    passed.append("order persisted")

    expected_inventory = checkpoint["inventory"]
    status, inventory = request(args.base_url, "GET", f"/inventory/{expected_inventory['sku']}")
    assert status == 200 and inventory == expected_inventory
    passed.append("inventory persisted")

    canonical_request = {"items": [{"sku": "GADGET", "quantity": 1}, {"sku": "WIDGET", "quantity": 2}]}
    status, retry = request(args.base_url, "POST", "/orders", canonical_request, "public-initial")
    assert status == 200 and retry == checkpoint["order"]
    passed.append("idempotent retry persisted")

    status, after_retry = request(args.base_url, "GET", f"/inventory/{expected_inventory['sku']}")
    assert status == 200 and after_retry == expected_inventory
    passed.append("retry did not reserve again")
    print(json.dumps({"status": "passed", "checks": passed}, indent=2))


if __name__ == "__main__":
    main()
