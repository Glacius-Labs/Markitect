import json,urllib.error,urllib.request
base='http://127.0.0.1:54725'
for action in ('cancel','fulfill'):
 req=urllib.request.Request(base+f'/orders/public-unknown-{action}/{action}',data=b'{}',headers={'Content-Type':'application/json'},method='POST')
 try:r=urllib.request.urlopen(req,timeout=5)
 except urllib.error.HTTPError as e:r=e
 with r: status=r.status; body=json.loads(r.read())
 assert status==404 and body.get('code')=='not_found' and body.get('message','').strip(),(action,status,body)
print(json.dumps({'status':'passed','checks':['unknown cancel returns useful not_found','unknown fulfill returns useful not_found']}))
