# Q1 intent replay — Conventional Greenfield, Task 2

Recorded before Task 2 implementation changes. Current released cutoff: Task 2 only. Public source versions and hashes are bound by `inputs/stage-2/release.json` (schema 1, throughTask 2):

- `inputs/stage-2/brief.md` v0.2: `4692ec98bbf8f8a140020e88182a62504689e6e6df5aa80af7c6783cdacb13c8`
- `inputs/stage-2/architecture.md` v0.3: `7459d9514358d1448c2353e0c0bf3d24d11a7eaf84b67c695724c88d20023700`
- `inputs/stage-2/01-create-order.md` Task 1: `bf5c1e5bf148245bfbc8212e2ad90b7369d8a1a03765258eda078f1ec87075a9`
- `inputs/stage-2/02-reserve-stock.md` Task 2: `e2b2afde36c28ac8fed8fff89325c40d69bb075056cf02809f908dfaf14858a6`
- `inputs/stage-2/checks.py`: `cd7a930f542ec2364609de1b0ad11ceb286d0219d113b57f17c8fbfc9554585b`
- Setup procedure `inputs/q1-intent-setup-v1.md`: `40bba049ac18da05deaa31943e3f6452280220f560f39e55a908704b8397312e`

## Current intent

Keep Task 1 routes and behavior. Add `GET /inventory/{sku}` returning camelCase `sku`, `onHand`, `reserved`, and `available` (`onHand - reserved`). Initial stock is 10 WIDGET and 6 GADGET. Unknown inventory SKU returns 404 `unknown_sku` with a useful message.

Order creation must reserve all requested units atomically. The order remains `accepted`. If any line cannot be fulfilled, respond 409 `insufficient_stock`; do not create an accepted order or change any reservation. Competing requests must not reserve the same unit. Same idempotency key plus same canonical request returns the same order with 200 and no extra reservation. Same key with a different canonical request returns 409 `idempotency_conflict` with no state change. Preserve Task 1 validation, status codes, codes, totals, canonicalization, and existing behavior.

Task 2's public checks specifically exercise the initial order, reservation values, retries, WIDGET stock-boundary concurrency, exhaustion, rejection atomicity, and a mixed-SKU all-or-nothing request. Implementation remains free to use a proportionate schema/API design within the architecture's existing freedoms.

## Assumptions and unanswered details

Use one database transaction to serialize competing reservation decisions and make order plus inventory changes atomic. Seed inventory idempotently on startup so restart does not reset stock. SKU matching follows the existing ordinal exact catalog lookup. The released sources do not define a special scheduling/fairness order for simultaneous requests, contention response timing, or exact error-message text; return the specified outcome once each transaction is serialized and use useful messages. These unanswered details do not block implementation.

