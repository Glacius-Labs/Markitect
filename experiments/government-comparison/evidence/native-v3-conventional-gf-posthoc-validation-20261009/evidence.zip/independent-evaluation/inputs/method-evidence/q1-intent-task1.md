# Q1 intent replay — Conventional Greenfield, Task 1

Recorded: 2026-10-08 21:41 UTC, before any implementation change.

## Released sources and cutoff

This replay uses only the current shared initial service brief v0.2, reference architecture/fixture contract v0.3, Task 1 card, and its public `checks.py`; the release manifest binds these exact SHA-256 values:

- `inputs/stage-1/brief.md` (v0.2): `4692ec98bbf8f8a140020e88182a62504689e6e6df5aa80af7c6783cdacb13c8`
- `inputs/stage-1/architecture.md` (v0.3): `7459d9514358d1448c2353e0c0bf3d24d11a7eaf84b67c695724c88d20023700`
- `inputs/stage-1/01-create-order.md` (Task 1): `bf5c1e5bf148245bfbc8212e2ad90b7369d8a1a03765258eda078f1ec87075a9`
- `inputs/stage-1/checks.py`: `fc96859ce7cc71426ed774f3ff5d88a45adcf016d2250c259287d1da628ac0cc`
- Setup procedure `inputs/q1-intent-setup-v1.md`: `40bba049ac18da05deaa31943e3f6452280220f560f39e55a908704b8397312e`
- Public working-method description `inputs/oldschool-workflow-brief-20261008.md`: `5b9dddff5d07d9cb1e6427c43e46f1259e9fb49fd030fc0a6e1e44b21e60aadc`

Cutoff is Task 1 only. The repository starts empty at base `0416e366626d31933443ce2901d6a3696261db7b`. Later task cards are not part of this replay or implementation.

## Stated intent and rules

Build a small C# HTTP service targeting .NET 10, backed by local SQLite. The runner supplies bind address and database path. It must implement `GET /health`, `GET /catalog`, `POST /orders`, and `GET /orders/{id}`. The catalog includes WIDGET at 1250 cents and GADGET at 775 cents. A successful new order has status `accepted`, normalized items, integer-cent total and ID; the two-WIDGET/one-GADGET example totals 3275 cents. Reads return the same order; unknown IDs return 404 `not_found`.

For order creation, require a nonempty item list and nonblank `Idempotency-Key`. Quantities must be positive integers and the sum of line quantities may not exceed 10. Unknown SKUs return 400 `unknown_sku`; the other listed input failures return 400 `validation`; over-limit returns 400 `order_limit`. Error bodies have a nonempty useful message. Combine repeated SKU lines and canonicalize by SKU. Repeating a key with the same canonical request returns 200 and the original order ID; using it for a different canonical request returns 409 `idempotency_conflict` without changing the first result. Prices and totals use integer cents.

Architecture pins: C# `net10.0`, SDK `10.0.103` with roll-forward disabled, runtime `10.0.3`, and exact direct package versions `Microsoft.Data.Sqlite` 10.0.3, `SQLitePCLRaw.bundle_e_sqlite3` 3.0.5, and `SQLitePCLRaw.core` 3.0.5, with bracketed versions and a lock file. Use a NuGet.org-only local config for restore; record the actual resolved graph and tool versions. Public checks can be run against a fresh DB and include a restart durability check.

## Freedoms explicitly preserved

Minimal APIs or controllers, direct SQL or ADO.NET, one or a few projects, and proportional internal abstractions are allowed. The documents do not require DDD, Clean Architecture, repositories, mediators, ORM, containers, cloud or paid services. Project/table names, ID format, schema shape and exact error prose are open. Keep the service runnable with concise build/run/check instructions.

## Assumptions and open behavior questions

Assumptions for implementation: use deterministic ordinal SKU comparison and a simple schema; preserve integer arithmetic and reject malformed values rather than coercing them. Choose concise useful error messages. No assumption is made that the public examples define additional routes or requirements.

Open questions not answered by the released sources: Are SKU matching and key matching case-sensitive? How should malformed JSON, wrong JSON types, extra fields, whitespace around SKUs, or quantities beyond the supported integer range be handled? Is same-key simultaneous request behavior required to be serialized into one order? Are any exact error-message strings expected? The stated contract and checks do not resolve these details, so use ordinary deterministic behavior without adding new business rules.

