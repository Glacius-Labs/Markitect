# Q1 intent replay — Conventional Greenfield, Task 5

Recorded before implementation changes. The current release is bound by `inputs/stage-5/release.json` (schema 1, throughTask 5):

- `inputs/stage-5/brief.md` v0.2: `4692ec98bbf8f8a140020e88182a62504689e6e6df5aa80af7c6783cdacb13c8`
- `inputs/stage-5/architecture.md` v0.3: `7459d9514358d1448c2353e0c0bf3d24d11a7eaf84b67c695724c88d20023700`
- `inputs/stage-5/01-create-order.md` Task 1: `bf5c1e5bf148245bfbc8212e2ad90b7369d8a1a03765258eda078f1ec87075a9`
- `inputs/stage-5/02-reserve-stock.md` Task 2: `e2b2afde36c28ac8fed8fff89325c40d69bb075056cf02809f908dfaf14858a6`
- `inputs/stage-5/03-persist-state.md` Task 3: `2e9e4b6084d553a21720215e6cd5632508c875ea577b3492da01346a84ca2c53`
- `inputs/stage-5/04-order-lifecycle.md` Task 4: `f9ff9d364f4ed9a1d4a6f61189f7c32e017c22f1ac1acdba8eec5cc046e4faa0`
- `inputs/stage-5/05-change-limit.md` Task 5: `8ae2fca3229f9c4ceb9f618da68eabe02f08071b1d51075af715139a8f5d2ae4`
- `inputs/stage-5/checks.py`: `1c05a2985f262ddf3d18e2fe0be4750e20c7a61a2921b5062655b3595d0be51b`
- Setup procedure `inputs/q1-intent-setup-v1.md`: `40bba049ac18da05deaa31943e3f6452280220f560f39e55a908704b8397312e`

## Current intent

Preserve Tasks 1–4 behavior. Change the maximum sum of order line quantities to 6 inclusive; above six returns HTTP 400 `order_limit`, and six is valid if inventory is available. Apply the same limit at every active order entry point. Add `POST /legacy/orders` as a Greenfield alias for `POST /orders`; both accept the same JSON and idempotency header and produce equivalent status, order, idempotency, inventory, and persistence results. Preserve lifecycle behavior and valid neighboring inputs. Update code and affected documentation/checks.

## Assumptions and unanswered details

Use one shared handler and one named limit constant so the routes cannot drift. The inherited Task 1 wording defines the bound as the sum of line quantities, including duplicate lines before canonicalization. The published card and checks specify the required limit and alias behavior; no behavior-changing question remains open.

