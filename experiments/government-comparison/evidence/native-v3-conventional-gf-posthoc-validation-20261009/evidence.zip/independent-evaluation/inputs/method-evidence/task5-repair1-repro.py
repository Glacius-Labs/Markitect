import argparse
import json
import sqlite3
import urllib.error
import urllib.request


def request(base, route, payload=None, key=None):
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Idempotency-Key"] = key
    body = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(base.rstrip("/") + route, data=body, headers=headers, method="POST" if payload is not None else "GET")
    try:
        response = urllib.request.urlopen(req, timeout=10)
    except urllib.error.HTTPError as exc:
        response = exc
    with response:
        return response.status, json.loads(response.read())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--database", required=True)
    args = parser.parse_args()
    order_id = "public-old-seven-order"
    key = "public-old-seven-key"
    canonical = '[{"Sku":"WIDGET","Quantity":7,"UnitPriceCents":1250}]'
    with sqlite3.connect(args.database) as db:
        db.execute("INSERT INTO orders (id, idempotency_key, canonical_request, status, total_cents) VALUES (?, ?, ?, 'accepted', 8750)", (order_id, key, canonical))
        db.execute("INSERT INTO order_items (order_id, sku, quantity, unit_price_cents) VALUES (?, 'WIDGET', 7, 1250)", (order_id,))
        db.execute("UPDATE inventory SET reserved = 7 WHERE sku = 'WIDGET'")

    status, original = request(args.base_url, f"/orders/{order_id}")
    assert status == 200 and original["status"] == "accepted" and original["totalCents"] == 8750
    passed = ["seeded prior-limit order remains readable"]
    before = request(args.base_url, "/inventory/WIDGET")[1]
    assert before == {"sku": "WIDGET", "onHand": 10, "reserved": 7, "available": 3}

    duplicate_spelling = {"items": [{"sku": "WIDGET", "quantity": 3}, {"sku": "WIDGET", "quantity": 4}]}
    for route, payload in (("/orders", duplicate_spelling), ("/legacy/orders", {"items": [{"sku": "WIDGET", "quantity": 7}]})):
        status, replay = request(args.base_url, route, payload, key)
        assert status == 200 and replay == original
        assert request(args.base_url, "/inventory/WIDGET")[1] == before
        passed.append(f"same-key old-order replay at {route}")

    status, conflict = request(args.base_url, "/orders", {"items": [{"sku": "WIDGET", "quantity": 6}]}, key)
    assert status == 409 and conflict["code"] == "idempotency_conflict"
    passed.append("different canonical request conflicts")

    for route in ("/orders", "/legacy/orders"):
        status, error = request(args.base_url, route, {"items": [{"sku": "WIDGET", "quantity": 7}]}, f"new-seven-{route}")
        assert status == 400 and error["code"] == "order_limit"
        assert request(args.base_url, "/inventory/WIDGET")[1] == before
        passed.append(f"new seven-unit request rejected at {route}")

    status, cancelled = request(args.base_url, f"/orders/{order_id}/cancel", {})
    assert status == 200 and cancelled["status"] == "cancelled"
    released = request(args.base_url, "/inventory/WIDGET")[1]
    assert released == {"sku": "WIDGET", "onHand": 10, "reserved": 0, "available": 10}
    assert request(args.base_url, f"/orders/{order_id}/cancel", {}) == (200, cancelled)
    assert request(args.base_url, "/inventory/WIDGET")[1] == released
    passed.extend(["old order cancellation releases reservation", "repeat cancellation changes no inventory"])
    print(json.dumps({"status": "passed", "checks": passed}, indent=2))


if __name__ == "__main__":
    main()
