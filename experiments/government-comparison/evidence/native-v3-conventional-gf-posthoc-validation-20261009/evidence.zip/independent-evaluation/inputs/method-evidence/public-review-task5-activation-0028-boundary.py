import json
import urllib.error
import urllib.request
base='http://127.0.0.1:52004'
def call(route, payload=None, key=None):
    headers={'Content-Type':'application/json'}
    if key is not None: headers['Idempotency-Key']=key
    body=json.dumps(payload).encode() if payload is not None else None
    req=urllib.request.Request(base+route,data=body,headers=headers,method='POST' if payload is not None else 'GET')
    try: response=urllib.request.urlopen(req,timeout=10)
    except urllib.error.HTTPError as e: response=e
    with response: return response.status,json.loads(response.read())
def order(*lines): return {'items':[{'sku':sku,'quantity':qty} for sku,qty in lines]}
def inv(sku): return call('/inventory/'+sku)[1]
checks=[]
start_w=inv('WIDGET'); start_g=inv('GADGET')
s,o=call('/orders',order(('WIDGET',2),('WIDGET',4)),'cross-route-widget')
assert s==201 and o['items']==[{'sku':'WIDGET','quantity':6,'unitPriceCents':1250}]; checks.append('orders accepts duplicate-line sum-six boundary')
after_w=inv('WIDGET')
s,r=call('/legacy/orders',order(('WIDGET',6)),'cross-route-widget')
assert s==200 and r==o and inv('WIDGET')==after_w; checks.append('legacy canonical retry of orders key returns same order without new reservation')
s,e=call('/legacy/orders',order(('WIDGET',5)),'cross-route-widget')
assert s==409 and e['code']=='idempotency_conflict' and inv('WIDGET')==after_w; checks.append('cross-route conflicting key leaves reservation unchanged')
s,g=call('/legacy/orders',order(('GADGET',6)),'cross-route-gadget')
assert s==201 and g['items']==[{'sku':'GADGET','quantity':6,'unitPriceCents':775}]; checks.append('legacy accepts six-unit boundary when inventory allows')
after_g=inv('GADGET')
s,r=call('/orders',order(('GADGET',3),('GADGET',3)),'cross-route-gadget')
assert s==200 and r==g and inv('GADGET')==after_g; checks.append('orders canonical retry of legacy key returns same order without new reservation')
for route in ('/orders','/legacy/orders'):
  for sku in ('WIDGET','GADGET'):
    s,e=call(route,order((sku,4),(sku,3)),f'over-limit-{route}-{sku}')
    assert s==400 and e['code']=='order_limit' and e['message'].strip(); checks.append(f'{route} rejects duplicate-line sum-seven for {sku}')
print(json.dumps({'status':'passed','checks':checks},indent=2))
