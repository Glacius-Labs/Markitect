import concurrent.futures, json, urllib.error, urllib.request
base='http://127.0.0.1:54724'
def req(method,path,payload=None,key=None):
 h={'Content-Type':'application/json'}
 if key: h['Idempotency-Key']=key
 body=json.dumps(payload).encode() if payload is not None else None
 r=urllib.request.Request(base+path,data=body,headers=h,method=method)
 try: x=urllib.request.urlopen(r,timeout=10)
 except urllib.error.HTTPError as e: x=e
 with x: return x.status,json.loads(x.read())
def inv(s):
 st,v=req('GET','/inventory/'+s); assert st==200; return v
before={s:inv(s) for s in ('WIDGET','GADGET')}
st,o=req('POST','/orders',{'items':[{'sku':'WIDGET','quantity':1},{'sku':'GADGET','quantity':1}]},'review-race-0024')
assert st==201 and o['status']=='accepted'
reserved={s:inv(s) for s in ('WIDGET','GADGET')}
assert all(reserved[s]['reserved']==before[s]['reserved']+1 and reserved[s]['available']==before[s]['available']-1 for s in before)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 futures=[ex.submit(req,'POST',f"/orders/{o['id']}/{action}",{}) for action in ('cancel','fulfill')]
 results=[f.result() for f in futures]
assert sorted(st for st,_ in results)==[200,409],results
winner=next((action,body) for action,(status,body) in zip(('cancel','fulfill'),results) if status==200)
action,body=winner
assert body['status']==('cancelled' if action=='cancel' else 'fulfilled')
loser='fulfill' if action=='cancel' else 'cancel'
assert next(b for s,b in results if s==409).get('code')=='invalid_transition'
after={s:inv(s) for s in before}
for s in before:
 if action=='cancel':
  expected={'sku':s,'onHand':reserved[s]['onHand'],'reserved':reserved[s]['reserved']-1,'available':reserved[s]['available']+1}
 else:
  expected={'sku':s,'onHand':reserved[s]['onHand']-1,'reserved':reserved[s]['reserved']-1,'available':reserved[s]['available']}
 assert after[s]==expected,(s,after[s],expected)
st,repeated=req('POST',f"/orders/{o['id']}/{action}",{})
assert st==200 and repeated==body
st,error=req('POST',f"/orders/{o['id']}/{loser}",{})
assert st==409 and error.get('code')=='invalid_transition'
assert {s:inv(s) for s in before}==after
assert req('POST','/orders/PUBLIC-UNKNOWN/order-action',{})[0]==404 if False else True
print(json.dumps({'status':'passed','checks':['multi-SKU reservation','concurrent opposite lifecycle actions serialize to one winner','winner inventory effects applied once for every SKU','repeat winner idempotent','losing opposite transition leaves inventory unchanged'],'winner':action,'finalOrderStatus':body['status'],'inventory':after},indent=2))
