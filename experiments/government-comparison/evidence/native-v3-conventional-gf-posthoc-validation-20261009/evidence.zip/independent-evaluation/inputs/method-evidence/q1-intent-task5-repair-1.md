# Task 5 semantic repair intent — round 1

Recorded at 2026-10-08T22:23:49Z. This note is recorded after the code edit and before final evidence/closure; it is not represented as a pre-implementation Q1 replay. Original pre-implementation intent remains state/q1-intent-task5.md and its bytes are unchanged.

Trigger: fresh public review T5-001 showed that Task 5's six-unit new-order limit ran before the persisted idempotency lookup. Task 1/3 require same-key canonical retries to replay a prior accepted order; a schema-valid seven-unit accepted order was seeded by review in a candidate-initialized DB and matching retries were rejected at both aliases.

Repair intent: preserve the six-unit limit on new order creation while moving enforcement into the existing immediate SQLite transaction after matching key/canonical replay and before inventory reservation or new persistence. Matching existing orders must replay at either shared route; changed canonical input under that key must remain a conflict. Keep lifecycle and inventory semantics intact. Assumption: quantities in a valid request remain positive Int32 values and canonical matching continues to use the persisted current catalog price, as in released behavior.

The repair patch had already been applied when this repair activation context was resumed. Subsequent actions in this activation include compile, seeded regression, full released checks, restart verification, vulnerability audit, and commit.