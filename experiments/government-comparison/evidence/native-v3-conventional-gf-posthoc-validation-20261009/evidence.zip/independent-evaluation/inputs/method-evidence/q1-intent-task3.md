# Q1 intent replay — Conventional Greenfield, Task 3

Recorded before implementation changes. This cell's released cutoff is Task 3, as bound by `inputs/stage-3/release.json` (schema 1, throughTask 3):

- `inputs/stage-3/brief.md` v0.2: `4692ec98bbf8f8a140020e88182a62504689e6e6df5aa80af7c6783cdacb13c8`
- `inputs/stage-3/architecture.md` v0.3: `7459d9514358d1448c2353e0c0bf3d24d11a7eaf84b67c695724c88d20023700`
- `inputs/stage-3/01-create-order.md` Task 1: `bf5c1e5bf148245bfbc8212e2ad90b7369d8a1a03765258eda078f1ec87075a9`
- `inputs/stage-3/02-reserve-stock.md` Task 2: `e2b2afde36c28ac8fed8fff89325c40d69bb075056cf02809f908dfaf14858a6`
- `inputs/stage-3/03-persist-state.md` Task 3: `2e9e4b6084d553a21720215e6cd5632508c875ea577b3492da01346a84ca2c53`
- `inputs/stage-3/checks.py`: `da8370546b56ec1ff61a5dd37b641ce16b0ff9dba0df681dcc939d3562d1d3ea`
- Setup procedure `inputs/q1-intent-setup-v1.md`: `40bba049ac18da05deaa31943e3f6452280220f560f39e55a908704b8397312e`

## Current intent

Persist catalog, orders, canonical idempotency keys, and inventory reservations in the runner-supplied local SQLite database. On a fresh database, initialize the schema and initial data. After restart at the same path, catalog, inventory, order reads, and idempotent retries must have the same logical results. A failed order/reservation operation leaves no partial success. Preserve all Task 1 and Task 2 behavior. No external database service is permitted; no migration framework is required.

## Assumptions and unanswered details

The existing catalog is fixed by the released brief, so persist its seeded rows in SQLite and read the catalog from SQLite. Seed catalog and initial inventory with insert-if-absent behavior so startup on an existing database cannot reset reservations. Existing Task 2's immediate SQLite write transaction is the transaction boundary for atomic order and reservation writes. The card does not require a migration framework, schema version table, dynamic catalog editing, or behavior for manually corrupting the database; none is added. No released behavior question blocks implementation.

