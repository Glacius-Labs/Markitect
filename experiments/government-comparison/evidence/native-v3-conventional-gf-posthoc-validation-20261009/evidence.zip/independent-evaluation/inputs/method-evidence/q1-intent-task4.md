# Q1 intent replay — Conventional Greenfield, Task 4

Recorded before implementation changes. Current cutoff is Task 4, bound by `inputs/stage-4/release.json` (schema 1, throughTask 4):

- `inputs/stage-4/brief.md` v0.2: `4692ec98bbf8f8a140020e88182a62504689e6e6df5aa80af7c6783cdacb13c8`
- `inputs/stage-4/architecture.md` v0.3: `7459d9514358d1448c2353e0c0bf3d24d11a7eaf84b67c695724c88d20023700`
- `inputs/stage-4/01-create-order.md` Task 1: `bf5c1e5bf148245bfbc8212e2ad90b7369d8a1a03765258eda078f1ec87075a9`
- `inputs/stage-4/02-reserve-stock.md` Task 2: `e2b2afde36c28ac8fed8fff89325c40d69bb075056cf02809f908dfaf14858a6`
- `inputs/stage-4/03-persist-state.md` Task 3: `2e9e4b6084d553a21720215e6cd5632508c875ea577b3492da01346a84ca2c53`
- `inputs/stage-4/04-order-lifecycle.md` Task 4: `f9ff9d364f4ed9a1d4a6f61189f7c32e017c22f1ac1acdba8eec5cc046e4faa0`
- `inputs/stage-4/checks.py`: `a73019281035b8b2d8a1011a0ca0058800ba82380dd0c256754a85f732b7b218`
- Setup procedure `inputs/q1-intent-setup-v1.md`: `40bba049ac18da05deaa31943e3f6452280220f560f39e55a908704b8397312e`

## Current intent

Keep the released create, reserve, persistence, read, and inventory behaviors. Add `POST /orders/{id}/cancel` and `POST /orders/{id}/fulfill`. An accepted order can transition to cancelled (release its reservation exactly once) or fulfilled (decrease on-hand and reserved by the order quantities together, leaving available unchanged). Repeating the same terminal action returns HTTP 200 with the current order and has no second inventory effect. The opposite action after a terminal transition returns HTTP 409 `invalid_transition` without changing state. Unknown order IDs return 404 `not_found`. Status and inventory updates must be durable together.

## Assumptions and unanswered details

Implement each action as a SQLite transaction that locks, loads the order, applies the status and matching inventory change, then commits. Return the order object for successful transitions and same-action repeats; use a useful error object for invalid transitions and missing IDs, consistent with released API conventions. Exact success-message text and serialization details are unspecified and do not change required behavior. The released card does not add other lifecycle states or actions.

