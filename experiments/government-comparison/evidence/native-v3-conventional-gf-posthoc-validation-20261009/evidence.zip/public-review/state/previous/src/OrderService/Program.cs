using System.Text.Json;
using Microsoft.Data.Sqlite;
using SQLitePCL;

Batteries.Init();
Console.WriteLine($"SQLite native engine version number: {raw.sqlite3_libversion_number()}");

var databasePath = Environment.GetEnvironmentVariable("ORDER_DB_PATH");
if (string.IsNullOrWhiteSpace(databasePath))
{
    throw new InvalidOperationException("Set ORDER_DB_PATH to the SQLite database file path.");
}

var database = new OrderDatabase(databasePath);
await database.InitializeAsync();

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

app.MapGet("/catalog", async (CancellationToken cancellationToken) =>
    Results.Ok(await database.FindCatalogAsync(cancellationToken)));

app.MapGet("/inventory/{sku}", async (string sku, CancellationToken cancellationToken) =>
{
    var inventory = await database.FindInventoryAsync(sku, cancellationToken);
    return inventory is null
        ? Error(404, "unknown_sku", $"SKU '{sku}' is not in the catalog.")
        : Results.Ok(inventory);
});

app.MapPost("/orders", async (HttpRequest request, CancellationToken cancellationToken) =>
{
    var key = request.Headers["Idempotency-Key"].FirstOrDefault();
    if (string.IsNullOrWhiteSpace(key))
    {
        return Error(400, "validation", "A nonblank Idempotency-Key header is required.");
    }

    OrderRequest parsed;
    try
    {
        using var document = await JsonDocument.ParseAsync(request.Body, cancellationToken: cancellationToken);
        if (!TryParseOrder(document.RootElement, out parsed, out var parseError))
        {
            return Error(400, "validation", parseError);
        }
    }
    catch (JsonException)
    {
        return Error(400, "validation", "The request body must be valid JSON.");
    }

    var lineQuantityTotal = parsed.Items.Sum(item => (long)item.Quantity);
    if (lineQuantityTotal > 10)
    {
        return Error(400, "order_limit", "An order may contain at most 10 total units.");
    }

    var catalog = (await database.FindCatalogAsync(cancellationToken))
        .ToDictionary(item => item.Sku, item => item.UnitPriceCents, StringComparer.Ordinal);

    foreach (var item in parsed.Items)
    {
        if (!catalog.TryGetValue(item.Sku, out _))
        {
            return Error(400, "unknown_sku", $"SKU '{item.Sku}' is not in the catalog.");
        }
    }

    var normalized = parsed.Items
        .GroupBy(item => item.Sku, StringComparer.Ordinal)
        .Select(group => new OrderItem(group.Key, group.Sum(item => item.Quantity), catalog[group.Key]))
        .OrderBy(item => item.Sku, StringComparer.Ordinal)
        .ToArray();

    var result = await database.CreateOrGetAsync(key, normalized, cancellationToken);
    if (result.ErrorCode == "idempotency_conflict")
    {
        return Error(409, "idempotency_conflict", "This Idempotency-Key was already used for a different order.");
    }

    if (result.ErrorCode == "insufficient_stock")
    {
        return Error(409, "insufficient_stock", "One or more requested items are unavailable.");
    }

    return Results.Json(result.Order, statusCode: result.Created ? 201 : 200);
});

app.MapGet("/orders/{id}", async (string id, CancellationToken cancellationToken) =>
{
    var order = await database.FindAsync(id, cancellationToken);
    return order is null
        ? Error(404, "not_found", $"Order '{id}' was not found.")
        : Results.Ok(order);
});

app.MapPost("/orders/{id}/cancel", async (string id, CancellationToken cancellationToken) =>
    TransitionResponse(await database.TransitionOrderAsync(id, "cancelled", cancellationToken)));

app.MapPost("/orders/{id}/fulfill", async (string id, CancellationToken cancellationToken) =>
    TransitionResponse(await database.TransitionOrderAsync(id, "fulfilled", cancellationToken)));

await app.RunAsync();

static IResult Error(int status, string code, string message) =>
    Results.Json(new ApiError(code, message), statusCode: status);

static IResult TransitionResponse(OrderTransitionResult result) => result.ErrorCode switch
{
    "not_found" => Error(404, "not_found", "The requested order was not found."),
    "invalid_transition" => Error(409, "invalid_transition", "The order is already in a different terminal state."),
    _ => Results.Ok(result.Order)
};

static bool TryParseOrder(JsonElement root, out OrderRequest parsed, out string error)
{
    parsed = new OrderRequest([]);
    error = "The request must contain a nonempty items array.";
    if (root.ValueKind != JsonValueKind.Object ||
        !root.TryGetProperty("items", out var items) ||
        items.ValueKind != JsonValueKind.Array ||
        items.GetArrayLength() == 0)
    {
        return false;
    }

    var parsedItems = new List<OrderLine>();
    foreach (var item in items.EnumerateArray())
    {
        if (item.ValueKind != JsonValueKind.Object ||
            !item.TryGetProperty("sku", out var skuElement) ||
            skuElement.ValueKind != JsonValueKind.String ||
            string.IsNullOrWhiteSpace(skuElement.GetString()) ||
            !item.TryGetProperty("quantity", out var quantityElement) ||
            quantityElement.ValueKind != JsonValueKind.Number ||
            !quantityElement.TryGetInt32(out var quantity) ||
            quantity <= 0)
        {
            error = "Each item must have a nonblank SKU and a positive integer quantity.";
            return false;
        }

        parsedItems.Add(new OrderLine(skuElement.GetString()!, quantity));
    }

    parsed = new OrderRequest(parsedItems);
    error = string.Empty;
    return true;
}

internal sealed record CatalogItem(string Sku, int UnitPriceCents);
internal sealed record OrderLine(string Sku, int Quantity);
internal sealed record OrderRequest(IReadOnlyList<OrderLine> Items);
internal sealed record OrderItem(string Sku, int Quantity, int UnitPriceCents);
internal sealed record OrderResponse(string Id, string Status, IReadOnlyList<OrderItem> Items, int TotalCents);
internal sealed record ApiError(string Code, string Message);
internal sealed record InventoryResponse(string Sku, int OnHand, int Reserved, int Available);
internal sealed record CreateResult(OrderResponse? Order, bool Created, string? ErrorCode = null);
internal sealed record OrderTransitionResult(OrderResponse? Order, string? ErrorCode = null);

internal sealed class OrderDatabase
{
    private readonly string _connectionString;

    public OrderDatabase(string path)
    {
        var fullPath = Path.GetFullPath(path);
        var directory = Path.GetDirectoryName(fullPath);
        if (!string.IsNullOrEmpty(directory))
        {
            Directory.CreateDirectory(directory);
        }

        _connectionString = new SqliteConnectionStringBuilder
        {
            DataSource = fullPath,
            ForeignKeys = true,
            DefaultTimeout = 15
        }.ToString();
    }

    public async Task InitializeAsync()
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        await using var command = connection.CreateCommand();
        command.CommandText = """
            PRAGMA journal_mode = WAL;
            CREATE TABLE IF NOT EXISTS orders (
                id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                canonical_request TEXT NOT NULL,
                status TEXT NOT NULL,
                total_cents INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS order_items (
                order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
                sku TEXT NOT NULL,
                quantity INTEGER NOT NULL CHECK (quantity > 0),
                unit_price_cents INTEGER NOT NULL CHECK (unit_price_cents >= 0),
                PRIMARY KEY (order_id, sku)
            );
            CREATE TABLE IF NOT EXISTS catalog (
                sku TEXT PRIMARY KEY,
                unit_price_cents INTEGER NOT NULL CHECK (unit_price_cents >= 0)
            );
            CREATE TABLE IF NOT EXISTS inventory (
                sku TEXT PRIMARY KEY,
                on_hand INTEGER NOT NULL CHECK (on_hand >= 0),
                reserved INTEGER NOT NULL CHECK (reserved >= 0 AND reserved <= on_hand)
            );
            INSERT OR IGNORE INTO catalog (sku, unit_price_cents) VALUES ('WIDGET', 1250);
            INSERT OR IGNORE INTO catalog (sku, unit_price_cents) VALUES ('GADGET', 775);
            INSERT OR IGNORE INTO inventory (sku, on_hand, reserved) VALUES ('WIDGET', 10, 0);
            INSERT OR IGNORE INTO inventory (sku, on_hand, reserved) VALUES ('GADGET', 6, 0);
            """;
        await command.ExecuteNonQueryAsync();
    }

    public async Task<CreateResult> CreateOrGetAsync(string key, IReadOnlyList<OrderItem> items, CancellationToken cancellationToken)
    {
        var canonical = JsonSerializer.Serialize(items);
        var total = items.Sum(item => checked(item.Quantity * item.UnitPriceCents));
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var transaction = connection.BeginTransaction(deferred: false);

        await using (var find = connection.CreateCommand())
        {
            find.Transaction = transaction;
            find.CommandText = "SELECT id, canonical_request FROM orders WHERE idempotency_key = $key;";
            find.Parameters.AddWithValue("$key", key);
            await using var reader = await find.ExecuteReaderAsync(cancellationToken);
            if (await reader.ReadAsync(cancellationToken))
            {
                var id = reader.GetString(0);
                var previousCanonical = reader.GetString(1);
                await reader.DisposeAsync();
                if (!StringComparer.Ordinal.Equals(previousCanonical, canonical))
                {
                    transaction.Commit();
                    return new CreateResult(null, false, "idempotency_conflict");
                }

                var existing = await ReadOrderAsync(connection, transaction, id, cancellationToken);
                transaction.Commit();
                return new CreateResult(existing!, false);
            }
        }

        foreach (var item in items)
        {
            await using var availability = connection.CreateCommand();
            availability.Transaction = transaction;
            availability.CommandText = "SELECT on_hand - reserved FROM inventory WHERE sku = $sku;";
            availability.Parameters.AddWithValue("$sku", item.Sku);
            var value = await availability.ExecuteScalarAsync(cancellationToken);
            if (value is null || value is DBNull)
            {
                throw new InvalidOperationException($"Inventory row for '{item.Sku}' is missing.");
            }

            if (Convert.ToInt32(value) < item.Quantity)
            {
                transaction.Commit();
                return new CreateResult(null, false, "insufficient_stock");
            }
        }

        var orderId = Guid.NewGuid().ToString("N");
        await using (var insert = connection.CreateCommand())
        {
            insert.Transaction = transaction;
            insert.CommandText = "INSERT INTO orders (id, idempotency_key, canonical_request, status, total_cents) VALUES ($id, $key, $canonical, 'accepted', $total);";
            insert.Parameters.AddWithValue("$id", orderId);
            insert.Parameters.AddWithValue("$key", key);
            insert.Parameters.AddWithValue("$canonical", canonical);
            insert.Parameters.AddWithValue("$total", total);
            await insert.ExecuteNonQueryAsync(cancellationToken);
        }

        foreach (var item in items)
        {
            await using var reserve = connection.CreateCommand();
            reserve.Transaction = transaction;
            reserve.CommandText = "UPDATE inventory SET reserved = reserved + $quantity WHERE sku = $sku AND on_hand - reserved >= $quantity;";
            reserve.Parameters.AddWithValue("$sku", item.Sku);
            reserve.Parameters.AddWithValue("$quantity", item.Quantity);
            if (await reserve.ExecuteNonQueryAsync(cancellationToken) != 1)
            {
                throw new InvalidOperationException($"Could not reserve inventory for '{item.Sku}' after availability was checked.");
            }
        }

        foreach (var item in items)
        {
            await using var insertItem = connection.CreateCommand();
            insertItem.Transaction = transaction;
            insertItem.CommandText = "INSERT INTO order_items (order_id, sku, quantity, unit_price_cents) VALUES ($id, $sku, $quantity, $price);";
            insertItem.Parameters.AddWithValue("$id", orderId);
            insertItem.Parameters.AddWithValue("$sku", item.Sku);
            insertItem.Parameters.AddWithValue("$quantity", item.Quantity);
            insertItem.Parameters.AddWithValue("$price", item.UnitPriceCents);
            await insertItem.ExecuteNonQueryAsync(cancellationToken);
        }

        transaction.Commit();
        return new CreateResult(new OrderResponse(orderId, "accepted", items, total), true);
    }

    public async Task<IReadOnlyList<CatalogItem>> FindCatalogAsync(CancellationToken cancellationToken)
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT sku, unit_price_cents FROM catalog ORDER BY sku COLLATE BINARY;";
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        var items = new List<CatalogItem>();
        while (await reader.ReadAsync(cancellationToken))
        {
            items.Add(new CatalogItem(reader.GetString(0), reader.GetInt32(1)));
        }

        return items;
    }

    public async Task<InventoryResponse?> FindInventoryAsync(string sku, CancellationToken cancellationToken)
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT on_hand, reserved FROM inventory WHERE sku = $sku;";
        command.Parameters.AddWithValue("$sku", sku);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken))
        {
            return null;
        }

        var onHand = reader.GetInt32(0);
        var reserved = reader.GetInt32(1);
        return new InventoryResponse(sku, onHand, reserved, onHand - reserved);
    }

    public async Task<OrderResponse?> FindAsync(string id, CancellationToken cancellationToken)
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        return await ReadOrderAsync(connection, null, id, cancellationToken);
    }

    public async Task<OrderTransitionResult> TransitionOrderAsync(string id, string targetStatus, CancellationToken cancellationToken)
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var transaction = connection.BeginTransaction(deferred: false);

        string? currentStatus;
        await using (var command = connection.CreateCommand())
        {
            command.Transaction = transaction;
            command.CommandText = "SELECT status FROM orders WHERE id = $id;";
            command.Parameters.AddWithValue("$id", id);
            currentStatus = (string?)await command.ExecuteScalarAsync(cancellationToken);
        }

        if (currentStatus is null)
        {
            transaction.Commit();
            return new OrderTransitionResult(null, "not_found");
        }

        if (StringComparer.Ordinal.Equals(currentStatus, targetStatus))
        {
            var repeated = await ReadOrderAsync(connection, transaction, id, cancellationToken);
            transaction.Commit();
            return new OrderTransitionResult(repeated);
        }

        if (!StringComparer.Ordinal.Equals(currentStatus, "accepted"))
        {
            transaction.Commit();
            return new OrderTransitionResult(null, "invalid_transition");
        }

        var orderItems = new List<(string Sku, int Quantity)>();
        await using (var command = connection.CreateCommand())
        {
            command.Transaction = transaction;
            command.CommandText = "SELECT sku, quantity FROM order_items WHERE order_id = $id ORDER BY sku COLLATE BINARY;";
            command.Parameters.AddWithValue("$id", id);
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                orderItems.Add((reader.GetString(0), reader.GetInt32(1)));
            }
        }

        foreach (var item in orderItems)
        {
            await using var command = connection.CreateCommand();
            command.Transaction = transaction;
            command.CommandText = targetStatus == "cancelled"
                ? "UPDATE inventory SET reserved = reserved - $quantity WHERE sku = $sku AND reserved >= $quantity;"
                : "UPDATE inventory SET on_hand = on_hand - $quantity, reserved = reserved - $quantity WHERE sku = $sku AND on_hand >= $quantity AND reserved >= $quantity;";
            command.Parameters.AddWithValue("$sku", item.Sku);
            command.Parameters.AddWithValue("$quantity", item.Quantity);
            if (await command.ExecuteNonQueryAsync(cancellationToken) != 1)
            {
                throw new InvalidOperationException($"Could not apply the {targetStatus} inventory change for '{item.Sku}'.");
            }
        }

        await using (var command = connection.CreateCommand())
        {
            command.Transaction = transaction;
            command.CommandText = "UPDATE orders SET status = $status WHERE id = $id AND status = 'accepted';";
            command.Parameters.AddWithValue("$status", targetStatus);
            command.Parameters.AddWithValue("$id", id);
            if (await command.ExecuteNonQueryAsync(cancellationToken) != 1)
            {
                throw new InvalidOperationException("The order state changed during its lifecycle transition.");
            }
        }

        var updated = await ReadOrderAsync(connection, transaction, id, cancellationToken);
        transaction.Commit();
        return new OrderTransitionResult(updated);
    }

    private static async Task<OrderResponse?> ReadOrderAsync(SqliteConnection connection, SqliteTransaction? transaction, string id, CancellationToken cancellationToken)
    {
        string status;
        int total;
        await using (var command = connection.CreateCommand())
        {
            command.Transaction = transaction;
            command.CommandText = "SELECT status, total_cents FROM orders WHERE id = $id;";
            command.Parameters.AddWithValue("$id", id);
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
            {
                return null;
            }

            status = reader.GetString(0);
            total = reader.GetInt32(1);
        }

        var items = new List<OrderItem>();
        await using (var command = connection.CreateCommand())
        {
            command.Transaction = transaction;
            command.CommandText = "SELECT sku, quantity, unit_price_cents FROM order_items WHERE order_id = $id ORDER BY sku COLLATE BINARY;";
            command.Parameters.AddWithValue("$id", id);
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                items.Add(new OrderItem(reader.GetString(0), reader.GetInt32(1), reader.GetInt32(2)));
            }
        }

        return new OrderResponse(id, status, items, total);
    }
}
