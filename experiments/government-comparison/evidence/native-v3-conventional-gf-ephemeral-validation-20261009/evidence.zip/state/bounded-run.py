import pathlib, subprocess, sys, time
cwd = pathlib.Path(sys.argv[1])
log = pathlib.Path(sys.argv[2])
limit = float(sys.argv[3])
cmd = sys.argv[4:]
started = time.time()
p = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
try:
    output, _ = p.communicate(timeout=limit)
except subprocess.TimeoutExpired:
    p.kill()
    output, _ = p.communicate()
    log.write_text(output, encoding='utf-8')
    print(output)
    raise SystemExit('TIMEOUT; process killed')
log.write_text(output, encoding='utf-8')
print(output)
print(f'EXIT={p.returncode} ELAPSED={time.time()-started:.2f}')
sys.exit(p.returncode)
