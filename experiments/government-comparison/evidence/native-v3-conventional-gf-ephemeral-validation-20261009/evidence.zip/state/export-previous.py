import pathlib, subprocess, tarfile, io, sys
root=pathlib.Path(r'C:\Users\Consiliari\Documents\Scientist-Native-v3-20261008\ephemeral-20261009')
repo=root/'repo'; target=root/'state'/'previous'; target.mkdir(parents=True,exist_ok=True)
p=subprocess.run(['git','-C',str(repo),'archive','--format=tar','baacb07fba54fcfce9244a6089ef93f037d01bc3'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=25)
if p.returncode: print(p.stderr.decode()); raise SystemExit(p.returncode)
with tarfile.open(fileobj=io.BytesIO(p.stdout),mode='r:') as tf: tf.extractall(target)
print('EXPORTED',len(p.stdout),'BYTES')
