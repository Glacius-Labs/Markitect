import datetime, json, pathlib, subprocess, sys, time, urllib.error, urllib.request
ROOT=pathlib.Path(r'C:\Users\Consiliari\Documents\Scientist-Native-v3-20261008\ephemeral-20261009')
REPO=ROOT/'repo'; STATE=ROOT/'state'; INPUT=ROOT/'inputs'; PY=r'C:\Python313\python.exe'
sys.path.insert(0,str(INPUT)); from owned_transport import Server
DEADLINE='2026-10-08T23:13:59.826698Z'
CAND='d1e271b8472cc55565696b976a87ff968a4e8c7a'
DLL=REPO/'src'/'OrderService'/'bin'/'Release'/'net10.0'/'OrderService.dll'
OLD=STATE/'previous'/'src'/'OrderService'/'bin'/'Release'/'net10.0'/'OrderService.dll'
PUBLIC=INPUT/'stage-5'/'checks.py'; HOLD=INPUT/'oracle'/'private'/'holdout_checks.py'
results=[]
def run_script(script,args,logname,timeout=60):
    remaining=(datetime.datetime.fromisoformat(DEADLINE.replace('Z','+00:00')).timestamp()-time.time())
    if remaining<=8: raise TimeoutError('deadline guard')
    p=subprocess.Popen([PY,str(script),*map(str,args)],cwd=STATE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    try: out,_=p.communicate(timeout=min(timeout,remaining-8))
    except subprocess.TimeoutExpired:
        p.kill(); out,_=p.communicate(); (STATE/logname).write_text(out,encoding='utf-8'); raise TimeoutError('check timeout '+logname)
    (STATE/logname).write_text(out,encoding='utf-8'); print('---',logname,'EXIT',p.returncode); print(out); results.append({'log':logname,'exitCode':p.returncode,'output':out})
    return p.returncode,out

def public(db,verify=False,label='public'):
    with Server(DLL,db,STATE,label,DEADLINE) as srv:
        args=['--base-url',srv.url,'--through-task','5','--condition','greenfield']
        if verify: args += ['--verify-restart',STATE/'public-checkpoint.json']
        else: args += ['--checkpoint',STATE/'public-checkpoint.json']
        return run_script(PUBLIC,args,label+'.checks.log',75)

def holdout(case,db,label,phase=None,checkpoint=None):
    with Server(DLL,db,STATE,label,DEADLINE) as srv:
        args=['--base-url',srv.url,'--candidate-sha',CAND,'--candidate-repository',REPO,'--through-task','5','--condition','greenfield','--case',case,'--candidate-frozen']
        if phase: args += ['--phase',phase,'--checkpoint',checkpoint]
        if phase!='after': args += ['--fresh-db-confirmed']
        return run_script(HOLD,args,label+'.log',75)

def req(base,method,path,payload=None,key=None):
    headers={'Content-Type':'application/json'}
    if key is not None:headers['Idempotency-Key']=key
    data=json.dumps(payload).encode() if payload is not None else None
    q=urllib.request.Request(base+path,data=data,headers=headers,method=method)
    try:r=urllib.request.urlopen(q,timeout=8)
    except urllib.error.HTTPError as e:r=e
    with r:return r.status,json.loads(r.read() or b'null')

def compatibility():
    db=STATE/'compatibility.sqlite'; key='prior-seven-accepted'; items=[{'sku':'WIDGET','quantity':7}]
    with Server(OLD,db,STATE,'compat-prior',DEADLINE) as srv:
        status,order=req(srv.url,'POST','/orders',{'items':items},key)
        ok=status==201 and order.get('status')=='accepted' and sum(x['quantity'] for x in order.get('items',[]))==7
        print('PRIOR_CREATE',status,order,'OK',ok)
        if not ok: raise AssertionError('ancestor Task4 did not accept seven-unit order')
        (STATE/'compat-order.json').write_text(json.dumps({'order':order,'items':items,'key':key}),encoding='utf-8')
    data=json.loads((STATE/'compat-order.json').read_text()); expected=data['order']; items=data['items']; key=data['key']
    with Server(DLL,db,STATE,'compat-current',DEADLINE) as srv:
        got=req(srv.url,'GET','/orders/'+str(expected['id']))
        print('CURRENT_READ',got)
        assert got[0]==200 and got[1]==expected
        for route in ['/orders','/legacy/orders']:
            status,body=req(srv.url,'POST',route,{'items':[{'sku':'WIDGET','quantity':3},{'sku':'WIDGET','quantity':4}]},key)
            print('REPLAY',route,status,body)
            assert status==200 and body.get('id')==expected['id']
            status,body=req(srv.url,'POST',route,{'items':[{'sku':'WIDGET','quantity':6}]},key)
            print('CONFLICT',route,status,body)
            assert status==409 and body.get('code')=='idempotency_conflict'
        before=req(srv.url,'GET','/inventory/WIDGET')[1]; assert before['reserved']==7
        status,cancelled=req(srv.url,'POST','/orders/'+str(expected['id'])+'/cancel',{})
        after=req(srv.url,'GET','/inventory/WIDGET')[1]
        status2,_=req(srv.url,'POST','/orders/'+str(expected['id'])+'/cancel',{})
        after2=req(srv.url,'GET','/inventory/WIDGET')[1]
        assert status==200 and cancelled.get('status')=='cancelled' and status2==200 and after['reserved']==0 and after2==after
        print('CANCEL_RELEASE',before,after,after2)
        for route in ['/orders','/legacy/orders']:
            status,body=req(srv.url,'POST',route,{'items':[{'sku':'WIDGET','quantity':7}]},'new-seven-'+route)
            print('NEW_SEVEN',route,status,body)
            assert status==400 and body.get('code')=='order_limit'
    results.append({'log':'compatibility','exitCode':0,'output':'prior seven accepted; current read/replay/conflict/cancel once/new seven rejected passed'})

# Public Task 1-5 and same-database restart.
db=STATE/'public.sqlite'; public(db,False,'public-before-restart'); public(db,True,'public-after-restart')
compatibility()
# Every case except restart gets its own new DB; restart retains only its own DB.
for case in ['order-normalization','validation-boundaries','idempotent-concurrency']:
    holdout(case,STATE/(case+'.sqlite'),case)
restartdb=STATE/'restart.sqlite'; checkpoint=STATE/'holdout-restart.json'
holdout('restart-durability',restartdb,'restart-before','before',checkpoint)
holdout('restart-durability',restartdb,'restart-after','after',checkpoint)
for case in ['terminal-transition-ordering','rule-change-entrypoint-parity']:
    holdout(case,STATE/(case+'.sqlite'),case)
(STATE/'runtime-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print('RUNTIME_DONE starts',len(json.loads((STATE/'owned-server-starts.json').read_text())))
