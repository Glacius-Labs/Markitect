import json,pathlib,sys,urllib.request,urllib.error
root=pathlib.Path(r'C:\Users\Consiliari\Documents\Scientist-Native-v3-20261008\ephemeral-20261009'); state=root/'state'; sys.path.insert(0,str(root/'inputs')); from owned_transport import Server
D='2026-10-08T23:13:59.826698Z'; db=state/'restart.sqlite'; dll=root/'repo'/'src'/'OrderService'/'bin'/'Release'/'net10.0'/'OrderService.dll'; cp=json.loads((state/'holdout-restart.json').read_text())
def req(base,path,method='GET',payload=None,key=None):
 import urllib.error
 h={'Content-Type':'application/json'}
 if key is not None:h['Idempotency-Key']=key
 d=json.dumps(payload).encode() if payload is not None else None
 q=urllib.request.Request(base+path,data=d,headers=h,method=method)
 try:r=urllib.request.urlopen(q,timeout=6)
 except urllib.error.HTTPError as e:r=e
 with r:return r.status,json.loads(r.read() or b'null')
with Server(dll,db,state,'restart-diagnostic',D) as s:
 got={'catalog':req(s.url,'/catalog'),'inventory':req(s.url,'/inventory/WIDGET'),'order':req(s.url,'/orders/'+str(cp['id'])),'retry':req(s.url,'/orders','POST',{'items':[{'sku':'WIDGET','quantity':3}]},cp['key'])}
 print('CHECKPOINT',json.dumps(cp,sort_keys=True)); print('ACTUAL',json.dumps(got,sort_keys=True))
