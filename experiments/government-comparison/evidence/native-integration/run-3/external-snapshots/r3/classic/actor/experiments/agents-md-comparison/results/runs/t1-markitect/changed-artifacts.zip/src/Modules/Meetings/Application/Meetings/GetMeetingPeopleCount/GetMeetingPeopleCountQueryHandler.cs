﻿using CompanyName.MyMeetings.Modules.Meetings.Application.Configuration.Queries;
using CompanyName.MyMeetings.Modules.Meetings.Application.Meetings.GetMeetingAttendees;
using MediatR;

namespace CompanyName.MyMeetings.Modules.Meetings.Application.Meetings.GetMeetingPeopleCount
{
    internal class GetMeetingPeopleCountQueryHandler : IQueryHandler<GetMeetingPeopleCountQuery, int>
    {
        private readonly IMediator _mediator;

        public GetMeetingPeopleCountQueryHandler(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task<int> Handle(GetMeetingPeopleCountQuery query, CancellationToken cancellationToken)
        {
            var attendees = await _mediator.Send(new GetMeetingAttendeesQuery(query.MeetingId), cancellationToken);
            return attendees.Sum(attendee => 1 + (attendee.GuestsNumber ?? 0));
        }
    }
}
