﻿using CompanyName.MyMeetings.Modules.Meetings.Application.Contracts;

namespace CompanyName.MyMeetings.Modules.Meetings.Application.Meetings.GetMeetingPeopleCount
{
    public class GetMeetingPeopleCountQuery : QueryBase<int>
    {
        public GetMeetingPeopleCountQuery(Guid meetingId)
        {
            MeetingId = meetingId;
        }

        public Guid MeetingId { get; }
    }
}
