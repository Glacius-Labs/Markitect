# Adopter engineering policy, version 2

Every Command in the selected cohort, `AddMeetingAttendee` and `CancelMeeting`, must have a corresponding FluentValidation class in Meetings Application. Each validator must reject an empty `MeetingId`. Keep the selected cohort intact.
