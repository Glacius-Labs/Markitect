"""Public behavioral checks against a fresh DB; destructive only to test orders."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import urllib.error
import urllib.request

class Checks:

    def __init__(self, base_url):
        self.url = base_url.rstrip('/')
        self.passed = []

    def http(self, method, route, payload=None, key=None):
        headers = {'Content-Type': 'application/json'}
        if key is not None:
            headers['Idempotency-Key'] = key
        body = json.dumps(payload).encode() if payload is not None else None
        request = urllib.request.Request(self.url + route, data=body, headers=headers, method=method)
        try:
            response = urllib.request.urlopen(request, timeout=10)
        except urllib.error.HTTPError as exc:
            response = exc
        with response:
            return (response.status, json.loads(response.read()))

    def expect(self, name, condition):
        if not condition:
            raise AssertionError(name)
        self.passed.append(name)

    def order(self, qty=1, sku='WIDGET'):
        return {'items': [{'sku': sku, 'quantity': qty}]}

    def inventory(self, sku='WIDGET'):
        status, value = self.http('GET', f'/inventory/{sku}')
        self.expect(f'inventory {sku} readable', status == 200)
        return value

    def unknown_inventory(self):
        status, error = self.http('GET', '/inventory/PUBLIC-UNKNOWN-SKU')
        self.expect('unknown inventory SKU', status == 404 and error.get('code') == 'unknown_sku' and isinstance(error.get('message'), str) and bool(error['message'].strip()))

    def run(self, through, condition):
        self.expect('health', self.http('GET', '/health')[0] == 200)
        status, catalog = self.http('GET', '/catalog')
        self.expect('catalog prices', status == 200 and {x['sku']: x['unitPriceCents'] for x in catalog} == {'WIDGET': 1250, 'GADGET': 775})
        for name, payload, code in (('zero', self.order(0), 'validation'), ('negative', self.order(-1), 'validation'), ('fractional', self.order(1.5), 'validation'), ('unknown', self.order(1, 'NOPE'), 'unknown_sku'), ('empty', {'items': []}, 'validation'), ('limit', self.order(11), 'order_limit')):
            status, error = self.http('POST', '/orders', payload, f'invalid-{name}')
            self.expect(f'invalid {name}', status == 400 and error.get('code') == code and bool(error.get('message')))
        self.expect('missing key', self.http('POST', '/orders', self.order())[0] == 400)
        missing_status, missing_order = self.http('GET', '/orders/public-unknown-order')
        self.expect('unknown order', missing_status == 404 and missing_order.get('code') == 'not_found')
        payload = {'items': [{'sku': 'WIDGET', 'quantity': 1}, {'sku': 'GADGET', 'quantity': 1}, {'sku': 'WIDGET', 'quantity': 1}]}
        status, order = self.http('POST', '/orders', payload, 'public-initial')
        self.expect('created exact total', status == 201 and order['totalCents'] == 3275 and (order['status'] == 'accepted'))
        self.expect('read order', self.http('GET', f"/orders/{order['id']}")[1] == order)
        canonical = {'items': [{'sku': 'GADGET', 'quantity': 1}, {'sku': 'WIDGET', 'quantity': 2}]}
        status, retry = self.http('POST', '/orders', canonical, 'public-initial')
        self.expect('semantic retry', status == 200 and retry['id'] == order['id'])
        self.expect('key conflict', self.http('POST', '/orders', self.order(3), 'public-initial')[0] == 409)
        checkpoint = {'order': order, 'inventory': None}
        if through < 2:
            return checkpoint
        self.unknown_inventory()
        inv = self.inventory()
        self.expect('reservation accounting', inv['onHand'] == 10 and inv['reserved'] == (3 if condition == 'brownfield' else 2) and (inv['available'] == inv['onHand'] - inv['reserved']))
        with ThreadPoolExecutor(max_workers=8) as pool:
            retries = list(pool.map(lambda _: self.http('POST', '/orders', canonical, 'public-initial'), range(12)))
        self.expect('concurrent duplicate same order', all((s == 200 and o['id'] == order['id'] for s, o in retries)))
        self.expect('duplicate no extra reservation', self.inventory() == inv)
        available = inv['available']
        with ThreadPoolExecutor(max_workers=8) as pool:
            attempts = list(pool.map(lambda n: self.http('POST', '/orders', self.order(), f'parallel-{n}'), range(12)))
        accepted = [o for s, o in attempts if s == 201]
        self.expect('concurrent no oversell', len(accepted) == available and all((s == 201 or (s == 409 and o['code'] == 'insufficient_stock') for s, o in attempts)))
        full = self.inventory()
        self.expect('stock exhausted', full == {'sku': 'WIDGET', 'onHand': 10, 'reserved': 10, 'available': 0})
        self.expect('rejection atomic', self.http('POST', '/orders', self.order(), 'exhausted')[0] == 409 and self.inventory() == full)
        gadget_before = self.inventory('GADGET')
        mixed = {'items': [{'sku': 'GADGET', 'quantity': 1}, {'sku': 'WIDGET', 'quantity': 1}]}
        self.expect('multi SKU all or nothing', self.http('POST', '/orders', mixed, 'mixed-insufficient')[0] == 409 and self.inventory('GADGET') == gadget_before and (self.inventory() == full))
        checkpoint['inventory'] = full
        return checkpoint

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base-url',required=True)
    parser.add_argument('--through-task',type=int,choices=range(1,3),default=2)
    parser.add_argument('--condition',choices=('greenfield',),required=True)
    args=parser.parse_args()
    checks=Checks(args.base_url)
    try:
        checks.run(args.through_task,args.condition)
        print(json.dumps({'status':'passed','checks':checks.passed},indent=2))
    except (AssertionError,OSError,KeyError,ValueError) as exc:
        print(json.dumps({'status':'failed','passed':checks.passed,'error':str(exc)},indent=2))
        raise SystemExit(1)
