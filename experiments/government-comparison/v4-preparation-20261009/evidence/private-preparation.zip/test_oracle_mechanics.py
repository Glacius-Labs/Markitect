"""Pure private oracle fixtures: no product, server, Actor or HTTP execution."""
import copy, importlib.util, json, pathlib, tempfile, unittest
spec=importlib.util.spec_from_file_location('private_v4_oracle',pathlib.Path(__file__).with_name('holdout_checks.py'));o=importlib.util.module_from_spec(spec);spec.loader.exec_module(o)
class FixtureClient:
    def __init__(self,partial_bug=False):self.state={'WIDGET':10,'GADGET':6};self.count=0;self.partial_bug=partial_bug
    def check(self,label,ok):
        if not ok:raise AssertionError(label)
        self.count+=1
    def inventory(self,sku):return {'available':self.state[sku]}
    def create(self,lines):
        if sum(x['quantity'] for x in lines)>6:return 400,{'code':'order_limit'}
        if any(x['quantity']>self.state[x['sku']] for x in lines):
            if self.partial_bug:self.state[lines[0]['sku']]-=lines[0]['quantity']
            return 409,{'code':'insufficient_stock'}
        for x in lines:self.state[x['sku']]-=x['quantity']
        return 201,{'id':'fixture-id'}
class RestartFixture:
    def __init__(self):self.count=0;self.key_prefix='fixture-';self.changed=False;self.created=False
    def check(self,label,ok):
        if not ok:raise AssertionError(label)
        self.count+=1
    def create(self,*args):
        status=200 if self.created else 201;self.created=True
        return status,{'id':'fixture-id'}
    def inventory(self,sku):return {'sku':sku,'available':7}
    def request(self,method,path):return (200,[{'sku':'WIDGET','unitPriceCents':1251 if self.changed else 1250}]) if path=='/catalog' else (200,{'id':'fixture-id'})
class OracleMechanics(unittest.TestCase):
    def test_atomic_case_reaches_stock_rule_at_current_limit(self):
        c=FixtureClient();o.atomic_case(c);self.assertGreater(c.count,0);self.assertEqual(c.state,{'WIDGET':10,'GADGET':1})
    def test_atomic_case_detects_partial_effect(self):
        with self.assertRaises(AssertionError):o.atomic_case(FixtureClient(partial_bug=True))
    def test_checkpoint_roundtrip_keeps_equivalent_http_observations(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'checkpoint.json';c=RestartFixture();o.restart_case(c,'before',p,'a'*40);o.restart_case(c,'after',p,'a'*40)
            self.assertIsInstance(json.loads(p.read_text())['catalog'],list)
    def test_checkpoint_still_detects_changed_catalog(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'checkpoint.json';c=RestartFixture();o.restart_case(c,'before',p,'a'*40);c.changed=True
            with self.assertRaises(AssertionError):o.restart_case(c,'after',p,'a'*40)
