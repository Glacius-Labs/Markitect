"""Private stdlib-only HTTP holdout. Runs one case per fresh candidate DB."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import subprocess
import threading
import urllib.error
import urllib.request
import uuid


ROOT = Path(__file__).resolve().parents[2] / "v4-preparation-20261009"
PUBLIC = ROOT / "public"
PLAN = Path(__file__).with_name("holdout-plan.json")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class Client:
    def __init__(self, base):
        self.base = base.rstrip("/")
        self.key_prefix = "ho-" + uuid.uuid4().hex
        self.count = 0

    def request(self, method, route, payload=None, key=None):
        headers = {"Content-Type": "application/json"}
        if key is not None:
            headers["Idempotency-Key"] = key
        body = json.dumps(payload).encode("utf-8") if payload is not None else None
        req = urllib.request.Request(self.base + route, data=body, headers=headers, method=method)
        try:
            response = urllib.request.urlopen(req, timeout=15)
        except urllib.error.HTTPError as exc:
            response = exc
        with response:
            raw = response.read()
            return response.status, json.loads(raw) if raw else None

    def check(self, label, ok):
        if not ok:
            raise AssertionError(label)
        self.count += 1

    def inventory(self, sku):
        status, value = self.request("GET", f"/inventory/{sku}")
        self.check("inventory-readable", status == 200)
        return value

    def create(self, items, key=None, route="/orders"):
        return self.request("POST", route, {"items": items}, key or self.key_prefix + uuid.uuid4().hex)


def order_case(c):
    # Uses values and line composition different from the public example.
    lines = [{"sku": "GADGET", "quantity": 2}, {"sku": "WIDGET", "quantity": 1},
             {"sku": "GADGET", "quantity": 1}]
    status, first = c.create(lines, c.key_prefix + "same")
    c.check("create-response", status == 201 and first.get("status") == "accepted")
    c.check("held-out-cent-total", first.get("totalCents") == 3575)
    permuted = [{"sku": "GADGET", "quantity": 3}, {"sku": "WIDGET", "quantity": 1}]
    status, retry = c.create(permuted, c.key_prefix + "same")
    c.check("normalized-retry", status == 200 and retry.get("id") == first.get("id")
            and retry.get("totalCents") == first.get("totalCents"))
    status, conflict = c.create([{"sku": "GADGET", "quantity": 2}], c.key_prefix + "same")
    c.check("semantic-key-conflict", status == 409 and conflict.get("code"))
    status, fetched = c.request("GET", "/orders/" + str(first["id"]))
    c.check("readback", status == 200 and fetched.get("id") == first.get("id"))


def validation_case(c, through):
    limit = 6 if through >= 5 else 10
    # Stay on one SKU and use both sides of the released inclusive boundary.
    status, valid = c.create([{"sku": "WIDGET", "quantity": limit}], c.key_prefix + "boundary")
    c.check("inclusive-limit", status == 201 and valid.get("id"))
    status, invalid = c.create([{"sku": "WIDGET", "quantity": limit + 1}], c.key_prefix + "over")
    c.check("over-limit-rejected", status == 400 and bool(invalid.get("code")))
    status, invalid = c.request("POST", "/orders", {"items": [{"sku": "GADGET", "quantity": 1.25}]}, c.key_prefix + "fraction")
    c.check("fraction-rejected", status == 400 and bool(invalid.get("code")))
    status, invalid = c.request("POST", "/orders", {"items": [{"sku": "GADGET", "quantity": 1}]}, "   ")
    c.check("blank-key-rejected", status == 400 and bool(invalid.get("code")))


def atomic_case(c):
    before = {sku: c.inventory(sku) for sku in ("WIDGET", "GADGET")}
    setup_status, setup_order = c.create([{"sku": "GADGET", "quantity": 5}])
    c.check("within-limit-stock-setup", setup_status == 201 and bool(setup_order.get("id")))
    before = {sku: c.inventory(sku) for sku in ("WIDGET", "GADGET")}
    status, result = c.create([{"sku": "WIDGET", "quantity": 1}, {"sku": "GADGET", "quantity": 2}])
    c.check("insufficient-stock-rejected", status == 409 and result.get("code") == "insufficient_stock")
    after = {sku: c.inventory(sku) for sku in ("WIDGET", "GADGET")}
    c.check("all-sku-state-unchanged", after == before)


def concurrency_case(c):
    payload = [{"sku": "GADGET", "quantity": 2}, {"sku": "WIDGET", "quantity": 1}]
    before = {sku: c.inventory(sku) for sku in ("WIDGET", "GADGET")}
    key = c.key_prefix + "same"
    barrier = threading.Barrier(8)
    def duplicate(_):
        barrier.wait()
        return c.create(payload, key)
    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(duplicate, range(8)))
    ids = {body.get("id") for status, body in results if body}
    c.check("concurrent-equivalent-retry", len(ids) == 1 and len(results) == 8
            and all(status in (200, 201) for status, _ in results))
    c.check("single-logical-order", len([1 for status, _ in results if status == 201]) <= 1)
    after = {sku: c.inventory(sku) for sku in ("WIDGET", "GADGET")}
    c.check("single-stock-effect", after["WIDGET"]["available"] == before["WIDGET"]["available"] - 1
            and after["GADGET"]["available"] == before["GADGET"]["available"] - 2)
    before = c.inventory("WIDGET")
    def compete(n):
        return c.create([{"sku": "WIDGET", "quantity": 1}], c.key_prefix + "race" + str(n))
    with ThreadPoolExecutor(max_workers=16) as pool:
        results = list(pool.map(compete, range(16)))
    accepted = sum(status == 201 for status, _ in results)
    rejected = sum(status == 409 for status, body in results if body and body.get("code") == "insufficient_stock")
    after = c.inventory("WIDGET")
    c.check("competing-stock-boundary", accepted <= before["available"] and accepted + rejected == 16
            and after["available"] == before["available"] - accepted)


def lifecycle_case(c):
    # Isolated fresh DB makes the two paths independent and easy to audit.
    status, cancelled = c.create([{"sku": "WIDGET", "quantity": 2}])
    c.check("cancel-order-created", status == 201)
    oid = cancelled["id"]
    before_cancel = c.inventory("WIDGET")
    status, _ = c.request("POST", f"/orders/{oid}/cancel", {})
    once = c.inventory("WIDGET")
    c.check("cancel-releases-reservation", status == 200 and once["available"] == before_cancel["available"] + 2)
    status, _ = c.request("POST", f"/orders/{oid}/cancel", {})
    c.check("repeat-cancel-stable", status == 200 and c.inventory("WIDGET") == once)
    status, conflict = c.request("POST", f"/orders/{oid}/fulfill", {})
    c.check("opposite-after-cancel-conflicts", status == 409 and bool(conflict.get("code")))
    status, fulfilled = c.create([{"sku": "GADGET", "quantity": 1}])
    c.check("fulfill-order-created", status == 201)
    gid = fulfilled["id"]
    before_fulfill = c.inventory("GADGET")
    status, _ = c.request("POST", f"/orders/{gid}/fulfill", {})
    once = c.inventory("GADGET")
    c.check("fulfill-consumes-reservation", status == 200 and once["available"] == before_fulfill["available"])
    status, _ = c.request("POST", f"/orders/{gid}/fulfill", {})
    c.check("repeat-fulfill-stable", status == 200 and c.inventory("GADGET") == once)
    status, conflict = c.request("POST", f"/orders/{gid}/cancel", {})
    c.check("opposite-after-fulfill-conflicts", status == 409 and bool(conflict.get("code")))


def changed_limit_case(c, through):
    before = c.inventory("WIDGET")
    route_values = ["/orders", "/legacy/orders"]
    codes = []
    for route in route_values:
        status, rejected = c.create([{"sku": "GADGET", "quantity": 7}], route=route)
        c.check("changed-limit-rejects-seven", status == 400 and bool(rejected.get("code")))
        codes.append(rejected.get("code"))
    c.check("limit-error-code-parity", codes[0] == codes[1] == "order_limit")
    c.check("invalid-aliases-no-stock-change", c.inventory("WIDGET") == before)
    # Six GADGETs are valid at the changed boundary but stock may already be consumed;
    # an insufficient-stock result is still a stock-rule response, not a limit failure.
    status, result = c.create([{"sku": "GADGET", "quantity": 6}], route="/legacy/orders")
    c.check("six-not-rejected-by-limit", status in (201, 409) and result.get("code") != "order_limit")


def restart_case(c, phase, checkpoint_path, candidate_sha):
    path = Path(checkpoint_path)
    if phase == "before":
        key = c.key_prefix + "restart"
        status, created = c.create([{"sku": "WIDGET", "quantity": 3}], key)
        c.check("restart-order-created", status == 201)
        snapshot = {"candidateCommit": candidate_sha, "id": created["id"], "key": key,
                    "catalog": list(c.request("GET", "/catalog")),
                    "inventory": c.inventory("WIDGET"),
                    "order": list(c.request("GET", "/orders/" + str(created["id"])))}
        path.write_text(json.dumps(snapshot, sort_keys=True), encoding="utf-8")
        return
    snapshot = json.loads(path.read_text(encoding="utf-8"))
    c.check("restart-same-frozen-candidate", snapshot["candidateCommit"] == candidate_sha)
    c.check("restart-catalog-stable", list(c.request("GET", "/catalog")) == snapshot["catalog"])
    c.check("restart-inventory-stable", c.inventory("WIDGET") == snapshot["inventory"])
    c.check("restart-order-stable", list(c.request("GET", "/orders/" + str(snapshot["id"]))) == snapshot["order"])
    status, replay = c.create([{"sku": "WIDGET", "quantity": 3}], snapshot["key"])
    c.check("restart-idempotency-stable", status == 200 and replay.get("id") == snapshot["id"])


CASES = {
    "order-normalization": order_case,
    "validation-boundaries": validation_case,
    "multi-sku-atomic-reservation": atomic_case,
    "idempotent-concurrency": concurrency_case,
    "restart-durability": restart_case,
    "terminal-transition-ordering": lifecycle_case,
    "rule-change-entrypoint-parity": changed_limit_case,
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--candidate-sha", required=True)
    parser.add_argument("--candidate-repository", required=True)
    parser.add_argument("--through-task", type=int, choices=range(1, 7), required=True)
    parser.add_argument("--condition", choices=("greenfield", "brownfield"), required=True)
    parser.add_argument("--case", choices=sorted(CASES), required=True)
    parser.add_argument("--candidate-frozen", action="store_true",
                        help="operator attests this exact candidate SHA is frozen for scoring")
    parser.add_argument("--fresh-db-confirmed", action="store_true",
                        help="operator attests this candidate run uses a newly initialized isolated DB")
    parser.add_argument("--phase", choices=("before", "after"), default="before")
    parser.add_argument("--checkpoint")
    args = parser.parse_args()
    if not re.fullmatch(r"[0-9a-f]{40,64}", args.candidate_sha.lower()):
        parser.error("candidate-sha must be a full hexadecimal Git object ID")
    if not args.candidate_frozen:
        parser.error("holdout runs only against the frozen candidate")
    repo = Path(args.candidate_repository).resolve()
    if not repo.is_absolute() or not repo.is_dir():
        parser.error("candidate-repository must be an existing absolute directory")
    actual_sha = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
    dirty = subprocess.check_output(["git", "-C", str(repo), "status", "--porcelain"], text=True).strip()
    if actual_sha.lower() != args.candidate_sha.lower() or dirty:
        parser.error("candidate repository must be clean and match candidate-sha exactly")
    if args.case == "restart-durability" and not args.checkpoint:
        parser.error("restart-durability requires a private checkpoint path")
    if args.case == "restart-durability" and args.phase == "after" and not Path(args.checkpoint).is_file():
        parser.error("after phase requires the checkpoint created before process restart")
    if args.phase == "before" and not args.fresh_db_confirmed:
        parser.error("before phase and every non-restart case require a newly initialized isolated candidate DB")
    cutoff = {
        "order-normalization": 1,
        "validation-boundaries": 1,
        "multi-sku-atomic-reservation": 2,
        "idempotent-concurrency": 2,
        "restart-durability": 3,
        "terminal-transition-ordering": 4,
        "rule-change-entrypoint-parity": 5,
    }[args.case]
    if args.through_task < cutoff:
        parser.error("case is outside the released task cutoff")
    c = Client(args.base_url)
    try:
        if args.case == "restart-durability":
            restart_case(c, args.phase, args.checkpoint, args.candidate_sha)
        elif args.case == "validation-boundaries":
            validation_case(c, args.through_task)
        elif args.case == "rule-change-entrypoint-parity":
            changed_limit_case(c, args.through_task)
        else:
            CASES[args.case](c)
        # Include exact plan and relevant public task digests; expose no case data/results.
        task_file = {1: "01-create-order.md", 2: "02-reserve-stock.md", 3: "03-persist-state.md",
                     4: "04-order-lifecycle.md", 5: "05-change-limit.md", 6: "06-repair-regression.md"}[cutoff]
        result = {"schemaVersion": 1, "status": "passed", "caseDigest": sha(PLAN),
                  "candidateCommit": args.candidate_sha, "condition": args.condition,
                  "throughTask": args.through_task, "assertionCount": c.count,
                  "sourceDigests": [sha(p) for p in [PLAN, PUBLIC / "brief.md", PUBLIC / "tasks" / task_file]]}
        print(json.dumps(result, sort_keys=True))
    except (AssertionError, OSError, KeyError, TypeError, ValueError) as exc:
        print(json.dumps({"schemaVersion": 1, "status": "failed", "caseDigest": sha(PLAN),
                          "candidateCommit": args.candidate_sha, "condition": args.condition,
                          "throughTask": args.through_task, "assertionCount": c.count,
                          "failureClass": type(exc).__name__}, sort_keys=True))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
